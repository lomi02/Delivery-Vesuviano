create definer = Heetas@localhost view cliente_view as
select `delivery vesuviano`.`locale`.`NOME_LOCALE` AS `NOME_LOCALE`,
       `delivery vesuviano`.`ordine`.`N_ORDINE`    AS `N_ORDINE`,
       `delivery vesuviano`.`ordine`.`STATO`       AS `STATO`,
       `delivery vesuviano`.`pagamento`.`IMPORTO`  AS `IMPORTO`
from ((`delivery vesuviano`.`locale` join `delivery vesuviano`.`ordine` on ((`delivery vesuviano`.`locale`.`P_IVA` =
                                                                             `delivery vesuviano`.`ordine`.`P_IVALOCALE`))) join `delivery vesuviano`.`pagamento`
      on ((`delivery vesuviano`.`ordine`.`SCONTRINO_ORDINE` = `delivery vesuviano`.`pagamento`.`SCONTRINO`)));

