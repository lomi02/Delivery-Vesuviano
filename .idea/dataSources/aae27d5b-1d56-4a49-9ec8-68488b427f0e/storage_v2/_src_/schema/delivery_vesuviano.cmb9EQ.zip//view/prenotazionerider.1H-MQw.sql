create definer = Heetas@localhost view prenotazionerider as
select `delivery vesuviano`.`rider`.`CF_RIDER`                 AS `CF_RIDER`,
       `delivery vesuviano`.`prenotazione`.`DATA_PRENOTAZIONE` AS `DATA_PRENOTAZIONE`
from ((`delivery vesuviano`.`rider` join `delivery vesuviano`.`effettuano`
       on ((`delivery vesuviano`.`rider`.`CF_RIDER` =
            `delivery vesuviano`.`effettuano`.`CODF_RIDER`))) join `delivery vesuviano`.`prenotazione`
      on ((`delivery vesuviano`.`effettuano`.`DATAPRENOTAZIONE` =
           `delivery vesuviano`.`prenotazione`.`DATA_PRENOTAZIONE`)));

