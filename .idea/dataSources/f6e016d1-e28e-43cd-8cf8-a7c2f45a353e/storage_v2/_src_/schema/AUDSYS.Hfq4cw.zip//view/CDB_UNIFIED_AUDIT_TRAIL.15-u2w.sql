create view CDB_UNIFIED_AUDIT_TRAIL as
SELECT k."AUDIT_TYPE",k."SESSIONID",k."PROXY_SESSIONID",k."OS_USERNAME",k."USERHOST",k."TERMINAL",k."INSTANCE_ID",k."DBID",k."AUTHENTICATION_TYPE",k."DBUSERNAME",k."DBPROXY_USERNAME",k."EXTERNAL_USERID",k."GLOBAL_USERID",k."CLIENT_PROGRAM_NAME",k."DBLINK_INFO",k."XS_USER_NAME",k."XS_SESSIONID",k."ENTRY_ID",k."STATEMENT_ID",k."EVENT_TIMESTAMP",k."EVENT_TIMESTAMP_UTC",k."ACTION_NAME",k."RETURN_CODE",k."OS_PROCESS",k."TRANSACTION_ID",k."SCN",k."EXECUTION_ID",k."OBJECT_SCHEMA",k."OBJECT_NAME",k."SQL_TEXT",k."SQL_BINDS",k."APPLICATION_CONTEXTS",k."CLIENT_IDENTIFIER",k."NEW_SCHEMA",k."NEW_NAME",k."OBJECT_EDITION",k."SYSTEM_PRIVILEGE_USED",k."SYSTEM_PRIVILEGE",k."AUDIT_OPTION",k."OBJECT_PRIVILEGES",k."ROLE",k."TARGET_USER",k."EXCLUDED_USER",k."EXCLUDED_SCHEMA",k."EXCLUDED_OBJECT",k."CURRENT_USER",k."ADDITIONAL_INFO",k."UNIFIED_AUDIT_POLICIES",k."FGA_POLICY_NAME",k."XS_INACTIVITY_TIMEOUT",k."XS_ENTITY_TYPE",k."XS_TARGET_PRINCIPAL_NAME",k."XS_PROXY_USER_NAME",k."XS_DATASEC_POLICY_NAME",k."XS_SCHEMA_NAME",k."XS_CALLBACK_EVENT_TYPE",k."XS_PACKAGE_NAME",k."XS_PROCEDURE_NAME",k."XS_ENABLED_ROLE",k."XS_COOKIE",k."XS_NS_NAME",k."XS_NS_ATTRIBUTE",k."XS_NS_ATTRIBUTE_OLD_VAL",k."XS_NS_ATTRIBUTE_NEW_VAL",k."DV_ACTION_CODE",k."DV_ACTION_NAME",k."DV_EXTENDED_ACTION_CODE",k."DV_GRANTEE",k."DV_RETURN_CODE",k."DV_ACTION_OBJECT_NAME",k."DV_RULE_SET_NAME",k."DV_COMMENT",k."DV_FACTOR_CONTEXT",k."DV_OBJECT_STATUS",k."OLS_POLICY_NAME",k."OLS_GRANTEE",k."OLS_MAX_READ_LABEL",k."OLS_MAX_WRITE_LABEL",k."OLS_MIN_WRITE_LABEL",k."OLS_PRIVILEGES_GRANTED",k."OLS_PROGRAM_UNIT_NAME",k."OLS_PRIVILEGES_USED",k."OLS_STRING_LABEL",k."OLS_LABEL_COMPONENT_TYPE",k."OLS_LABEL_COMPONENT_NAME",k."OLS_PARENT_GROUP_NAME",k."OLS_OLD_VALUE",k."OLS_NEW_VALUE",k."RMAN_SESSION_RECID",k."RMAN_SESSION_STAMP",k."RMAN_OPERATION",k."RMAN_OBJECT_TYPE",k."RMAN_DEVICE_TYPE",k."DP_TEXT_PARAMETERS1",k."DP_BOOLEAN_PARAMETERS1",k."DP_WARNINGS1",k."DIRECT_PATH_NUM_COLUMNS_LOADED",k."RLS_INFO",k."KSACL_USER_NAME",k."KSACL_SERVICE_NAME",k."KSACL_SOURCE_LOCATION",k."PROTOCOL_SESSION_ID",k."PROTOCOL_RETURN_CODE",k."PROTOCOL_ACTION_NAME",k."PROTOCOL_USERHOST",k."PROTOCOL_MESSAGE",k."DB_UNIQUE_NAME",k."OBJECT_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("AUDSYS"."UNIFIED_AUDIT_TRAIL") k
/

comment on table CDB_UNIFIED_AUDIT_TRAIL is 'All audit trail entries in all containers'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.AUDIT_TYPE is 'Type of the Audit Record'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SESSIONID is 'Audit Session Identifier of the User session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROXY_SESSIONID is 'Proxy Audit Session Identifier in case of Proxy User session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OS_USERNAME is 'Operating System logon user name of the user whose actions were audited'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.USERHOST is 'Client host machine name'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.TERMINAL is 'Identifier for the user''s terminal'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.INSTANCE_ID is 'Instance number as specified in the initialization parameter file ''init.ora'''
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DBID is 'Database Identifier of the audited database'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.AUTHENTICATION_TYPE is 'Type of Authentication for the session user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DBUSERNAME is 'Name of the user whose actions were audited'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DBPROXY_USERNAME is 'Name of the Proxy User in case of Proxy User sessions'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EXTERNAL_USERID is 'External Identifier for externally authenticated users'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.GLOBAL_USERID is 'Global user identifier for the user, if the user had logged in as enterprise user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.CLIENT_PROGRAM_NAME is 'Client Program Name which issued the commands in user session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DBLINK_INFO is 'Value of SYS_CONTEXT(''USERENV'', ''DBLINK_INFO'')'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_USER_NAME is 'Real Application User name'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_SESSIONID is 'Real Application User Session Identifier'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.ENTRY_ID is 'Numeric ID for each audit trail entry in the session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.STATEMENT_ID is 'Numeric ID for each statement run (a statement may cause many actions)'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EVENT_TIMESTAMP is 'Timestamp of the creation of audit trail entry in session''s time zone'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EVENT_TIMESTAMP_UTC is 'Timestamp of the creation of audit trail entry in UTC time'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.ACTION_NAME is 'Name of the action executed by the user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RETURN_CODE is 'Oracle error code generated by the action.  Zero if the action succeeded'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OS_PROCESS is 'Operating System process identifier of the Oracle server process'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.TRANSACTION_ID is 'Transaction identifier of the transaction in which the object is accessed or modified'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SCN is 'SCN (System Change Number) of the query'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EXECUTION_ID is 'Execution Context Identifier for each action'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OBJECT_SCHEMA is 'Schema name of object affected by the action'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OBJECT_NAME is 'Name of the object affected by the action'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SQL_TEXT is 'SQL text of the query'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SQL_BINDS is 'Bind variable data of the query'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.APPLICATION_CONTEXTS is 'SemiColon seperate list of Application Context Namespace, Attribute, Value information in (APPCTX_NSPACE,APPCTX_ATTRIBUTE=<value>) format'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.CLIENT_IDENTIFIER is 'Client identifier in each Oracle session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.NEW_SCHEMA is 'The schema of the object named in the NEW_NAME column'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.NEW_NAME is 'New name of object after RENAME, or name of underlying object (e.g. CREATE INDEX owner.obj_name ON new_owner.new_name)'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OBJECT_EDITION is 'The edition of the object affected by the action'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SYSTEM_PRIVILEGE_USED is 'System privilege used to execute the action'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.SYSTEM_PRIVILEGE is 'System privileges granted/revoked by a GRANT/REVOKE statement'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.AUDIT_OPTION is 'Auditing option set with the audit statement'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OBJECT_PRIVILEGES is 'Object privileges granted/revoked by a GRANT/REVOKE statement'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.ROLE is 'Role granted/revoked/set by a GRANT/REVOKE/SET ROLE statement'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.TARGET_USER is 'User on whom the GRANT/REVOKE/AUDIT/NOAUDIT statement was executed'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EXCLUDED_USER is 'User who was excluded when the AUDIT/NOAUDIT statement was executed'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EXCLUDED_SCHEMA is 'Schema of EXCLUDED_OBJECT'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.EXCLUDED_OBJECT is 'Object which was excluded when the SET ROLE/ALTER PLUGGABLE DATABASE statement was executed'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.CURRENT_USER is 'Effective user for the statement execution'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.ADDITIONAL_INFO is 'Text comment on the audit trail entry'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.UNIFIED_AUDIT_POLICIES is 'Unified Audit Policies that caused the audit trail entry'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.FGA_POLICY_NAME is 'Fine-Grained Audit Policy that caused the audit trail entry'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_INACTIVITY_TIMEOUT is 'Inactivity timeout of the Real Application Security session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_ENTITY_TYPE is 'Type of the Real Application Security entity'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_TARGET_PRINCIPAL_NAME is 'Target principal name in Real Application Security operations'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_PROXY_USER_NAME is 'Real Application Security proxy user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_DATASEC_POLICY_NAME is 'Real Application Security policy enabled or disabled'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_SCHEMA_NAME is 'Schema in enable, disable Real Application Security policy and global callback'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_CALLBACK_EVENT_TYPE is 'Real Application Security global callback event type'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_PACKAGE_NAME is 'Real Application Security callback package for global callback'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_PROCEDURE_NAME is 'Real Application Security callback procedure for global callback'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_ENABLED_ROLE is 'Enabled Real Application Security role'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_COOKIE is 'Real Application Security session cookie'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_NS_NAME is 'Real Application Security session namespace'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE is 'Real Application Security session namespace attribute'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE_OLD_VAL is 'Old value of the Real Application Security session namespace'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE_NEW_VAL is 'New value of the Real Application Security session namespace'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_ACTION_CODE is 'Numeric action type code for Database Vault'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_ACTION_NAME is 'Name of the action whose numeric code appears in the DV_ACTION_CODE column'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_EXTENDED_ACTION_CODE is 'Numeric action type code for Database Vault administration'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_GRANTEE is 'Name of the user whose Database Vault authorization was modified'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_RETURN_CODE is 'Database Vault specific error code'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_ACTION_OBJECT_NAME is 'The unique name of the Database Vault object that was modified'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_RULE_SET_NAME is 'The unique name of the rule set that was executing and caused the audit event to trigger'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_COMMENT is 'Text comment on the audit trail entry'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_FACTOR_CONTEXT is 'XML document containing Database Vault factor identifiers for the current session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DV_OBJECT_STATUS is 'Indicates whether a particular Database Vault object is enabled or disabled'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_POLICY_NAME is 'Oracle Label Security policy for which this audit record is generated'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_GRANTEE is 'User whose OLS authorization was modified'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_MAX_READ_LABEL is 'Maximum read OLS label assigned to a user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_MAX_WRITE_LABEL is 'Maximum write OLS label assigned to a user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_MIN_WRITE_LABEL is 'Minimum write OLS label assigned to a user'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_PRIVILEGES_GRANTED is 'OLS privileges assigned to a user or a trusted stored procedure'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_PROGRAM_UNIT_NAME is 'Trusted stored procedure whose authorization was modified or executed'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_PRIVILEGES_USED is 'OLS privileges used for an event'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_STRING_LABEL is 'String representation of the OLS label'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_LABEL_COMPONENT_TYPE is 'Type of the OLS label component'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_LABEL_COMPONENT_NAME is 'Name of the OLS label component'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_PARENT_GROUP_NAME is 'Name of the parent of the OLS group'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_OLD_VALUE is 'Old value for OLS ALTER events'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.OLS_NEW_VALUE is 'New value for OLS ALTER events'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RMAN_SESSION_RECID is 'RMAN Record Id'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RMAN_SESSION_STAMP is 'RMAN Session Stamp'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RMAN_OPERATION is 'RMAN Operation'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RMAN_OBJECT_TYPE is 'RMAN Object Involved'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RMAN_DEVICE_TYPE is 'Device Involved in RMAN Session'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DP_TEXT_PARAMETERS1 is 'Audited DataPump parameters that have text values'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DP_BOOLEAN_PARAMETERS1 is 'Audited DataPump parameters that have boolean values'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DP_WARNINGS1 is 'Audited warnings from DataPump operation'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DIRECT_PATH_NUM_COLUMNS_LOADED is 'Direct Path API load - number of columns loaded'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.RLS_INFO is 'RLS predicates along with the RLS policy names used for the object accessed'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.KSACL_USER_NAME is 'The connecting user name'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.KSACL_SERVICE_NAME is 'The target DB service name'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.KSACL_SOURCE_LOCATION is 'The source location of the initiating connection'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROTOCOL_SESSION_ID is 'Session id for audited protocol message'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROTOCOL_RETURN_CODE is 'Return code of audited protocol message reply'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROTOCOL_ACTION_NAME is 'Operation of audited protocol message'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROTOCOL_USERHOST is 'IP address of client system of audited protocol message'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.PROTOCOL_MESSAGE is 'Audited protocol message'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.DB_UNIQUE_NAME is 'Globally unique name for the database'
/

comment on column CDB_UNIFIED_AUDIT_TRAIL.CON_ID is 'container id'
/

