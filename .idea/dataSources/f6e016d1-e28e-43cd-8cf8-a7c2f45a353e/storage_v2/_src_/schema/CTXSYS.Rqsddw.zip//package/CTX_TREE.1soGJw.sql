create PACKAGE ctx_tree AUTHID current_user AS

/*------------------------------- TYPE DEFINITIONS ------------------------*/

/*---------------------------- register_index ----------------------*/
/*
   NAME
     register_index

   DESCRIPTION
     registers an index with the CTX_TREE package

   ARGUMENT
     index_name		- the name of the index

*/

PROCEDURE register_index(
  index_name      IN VARCHAR2
);
PRAGMA SUPPLEMENTAL_LOG_DATA(register_index, AUTO);

/*---------------------------- add_node ----------------------*/
/*
   NAME
     add_node

   DESCRIPTION
     add a new node to a tree associated with a MVDATA section and index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     path               - the new path to be added to a tree
     id_list            - return value of the corresponding node ids
     force              - complete successfully even if the path already
                          exists

*/

PROCEDURE add_node(
  index_name      IN VARCHAR2,
  section_name    IN VARCHAR2,
  path            IN CLOB,
  id_list         OUT CLOB,
  force           IN BOOLEAN DEFAULT FALSE
);
PRAGMA SUPPLEMENTAL_LOG_DATA(add_node, AUTO);

/*---------------------------- get_node_id ----------------------*/
/*
   NAME
     get_node_id

   DESCRIPTION
     looks up the node identifier of an existing path in a tree
     associated with a MVDATA section and index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     path               - an existing path in a tree
     id                 - return value of the corresponding node id

*/

PROCEDURE get_node_id(
  index_name      IN VARCHAR2,
  section_name    IN VARCHAR2,
  path            IN CLOB,
  id              OUT INTEGER
) ;

/*---------------------------- get_children ----------------------*/
/*
   NAME
     get_children

   DESCRIPTION
     looks up the children names of the node identified by a path in a tree
     associated with a MVDATA section and index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     path               - an existing path in a tree
     child_list         - return value of the children node names (comma-sep)

*/

PROCEDURE get_children(
  index_name      IN VARCHAR2,
  section_name    IN VARCHAR2,
  path            IN CLOB,
  child_list      IN OUT CLOB
);

/*---------------------------- get_nodeid_list ----------------------*/
/*
   NAME
     get_nodeid_list

   DESCRIPTION
     looks up the node identifiers of all nodes in an existing path in a tree
     associated with a MVDATA section and index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     path               - an existing path in a tree
     id_list            - return value of the corresponding node ids

*/

PROCEDURE get_nodeid_list(
  index_name      IN VARCHAR2,
  section_name    IN VARCHAR2,
  path            IN CLOB,
  id_list         IN OUT CLOB
);

/*---------------------------- get_roots ----------------------*/
/*
   NAME
     get_roots

   DESCRIPTION
     looks up the roots of all the trees associated with a MVDATA section
     and index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     roots              - list of roots (names)

*/

PROCEDURE get_roots(
  index_name      IN  VARCHAR2,
  section_name    IN  VARCHAR2,
  roots           OUT CLOB
);

/*---------------------------- remove_node ----------------------*/
/*
   NAME
     remove_node

   DESCRIPTION
     Removes specified node from the tree associated with the MVDATA section
     and Index

   ARGUMENT
     index_name		- the name for the index
     section_name       - the name of the MVDATA section
     path               - input node path to be deleted

*/

PROCEDURE remove_node(
  index_name      IN  VARCHAR2,
  section_name    IN  VARCHAR2,
  path            IN CLOB
);
PRAGMA SUPPLEMENTAL_LOG_DATA(remove_node, AUTO);

PROCEDURE DropSequences(
  idx_owner       IN VARCHAR2,
  idx_name        IN VARCHAR2,
  idx_id          IN NUMBER
);

PROCEDURE regindex(
  index_name      IN VARCHAR2,
  purge           IN BOOLEAN
);



END ctx_tree;
/

