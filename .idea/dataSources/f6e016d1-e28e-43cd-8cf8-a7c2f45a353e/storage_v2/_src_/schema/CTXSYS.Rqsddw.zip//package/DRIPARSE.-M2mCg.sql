create package driparse authid definer as

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

type createRec is record (
  populate        boolean,
  swap            boolean,
  idxmem          number,
  langcol         varchar2(256),
  fmtcol          varchar2(256),
  csetcol         varchar2(256),
  datastore       varchar2(256),
  filter          varchar2(256),
  section         varchar2(256),
  lexer           varchar2(256),
  wordlist        varchar2(256),
  stoplist        varchar2(256),
  storage         varchar2(256),
  indexset        varchar2(65),
  classifier      varchar2(65),
  txntional       varchar2(65),
  sync_type       varchar2(65),
  sync_memory     varchar2(100),
  sync_paradegree number,
  sync_interval   varchar2(4000),
  tree            boolean,
  sync_dpl        boolean,
  secname         varchar2(256),
  configcol       varchar2(256),
  async_upd       boolean,
  never_populate  boolean,
  simplesyntax    number,
  search_on       varchar2(65),
  dataguide       varchar2(65),
  opt_type        drvutl.dr_medbuf,
  opt_interval    drvutl.dr_extrabuf,
  opt_paradegree  number,
  no_r            boolean,
  no_pnd          boolean,
  tablespace      drvutl.dr_shortbuf
);

type alterRec is record (
  operation  number,
  op_subtype varchar2(30),
  string1    varchar2(255+16),
  string2    varchar2(255),
  number1    number,
  flag1      boolean,
  idx_opt    createRec,
  num1       number,
  att_val    number
);

OP_NULL                 constant number := -1;
-- Deprecated operation
--OP_SYNC               constant number :=  1;
OP_RESUME               constant number :=  2;
OP_REPLACE              constant number :=  3;
OP_ADD_STOPWORD         constant number :=  4;
-- Deprecated operation
--OP_OPTIMIZE           constant number :=  5;
OP_ADD_SECTION          constant number :=  6;
-- internal only
OP_EXCHANGE             constant number :=  7;
-- end of internal only
OP_ADD_STAGE_ITAB       constant number := 8;
OP_REMOVE_STAGE_ITAB    constant number := 9;
OP_ADD_BIG_IO           constant number := 10;
OP_REMOVE_BIG_IO        constant number := 11;
OP_ADD_SEPARATE_OFFSETS constant number := 12;
OP_ADD_SUB_LEXER        constant number := 13;
OP_REM_SUB_LEXER        constant number := 14;
OP_REM_STOPWORD         constant number := 15;
OP_REM_STOPWORDS        constant number := 16;
OP_MIGRATE_TO_MULTISTOP   constant number := 17;
OP_MIGRATE_FIELD_TO_MDATA constant number := 18;
OP_UPD_SUB_LEXER        constant number := 19;
OP_READ_TRUE            constant number := 20;
OP_READ_FALSE           constant number := 21;
OP_WRITE_TRUE           constant number := 22;
OP_WRITE_FALSE          constant number := 23;
OP_SIMPLE_SYNTAX        constant number := 24;


SIMPLE_SYNTAX_NONE      constant number := 0;
SIMPLE_SYNTAX_JSON      constant number := 1;
SIMPLE_SYNTAX_XML       constant number := 2;

/* ======================================================================= */
/* ======================================================================= */
/*                               CONTEXT                                   */
/* ======================================================================= */
/* ======================================================================= */

/*----------------------- InitCreateRec  -----------------------*/
/*
  NAME
    InitCreateRec

  DESCRIPTION
    initialize createrec

  ARGUMENTS

  NOTES

  EXCEPTIONS

  RETURNS

*/
FUNCTION InitCreateRec return createRec;

/*----------------------- ParseCreate  -----------------------*/
/*
  NAME
    ParseCreate

  DESCRIPTION
    parse create index parameters string

  ARGUMENTS
    params       paramstring
    alter_op     zero unless called from ParseAlter
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseCreate(
  params      in  varchar2,
  alter_op    in  number,
  opts        out createRec,
  metadataonly out boolean,
  isPart      in   boolean default FALSE
);

/*----------------------- ParsePartCreate  -----------------------*/
/*
  NAME
    ParsePartCreate

  DESCRIPTION
    parse create index (partition create) parameters string

  ARGUMENTS
    params       paramstring
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParsePartCreate(
  params      in  varchar2,
  alter_op    in  number,
  def_idxmem  in  number,
  def_idxsynctype in varchar2,
  opts        out createRec,
  metadataonly out boolean
);

/*----------------------- ParseAlter  -----------------------*/
/*
  NAME
    ParseAlter

  DESCRIPTION
    parse alter index parameters string

  ARGUMENTS
    idxid        index id
    params       paramstring
    opts         alter index options (OUT)
    isPart       if the index is partitioned -- only set in
                 recreate_index_online

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseAlter(
  idxid       in     number,
  params      in     varchar2,
  opts        in out alterRec,
  isPart      in     boolean default FALSE
);

/*----------------------- ParsePartAlter  -----------------------*/
/*
  NAME
    ParsePartAlter

  DESCRIPTION
    parse alter index partition parameters string

  ARGUMENTS
    idxid        index id
    params       paramstring
    opts         alter index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParsePartAlter(
  idxid       in     number,
  params      in     varchar2,
  opts        in out alterRec
);

/* ======================================================================= */
/* ======================================================================= */
/*                               CTXCAT                                    */
/* ======================================================================= */
/* ======================================================================= */

/*----------------------- ParseCreateCat  -----------------------*/
/*
  NAME
    ParseCreateCat

  DESCRIPTION
    parse create index parameters string for ctxcat indextype

  ARGUMENTS
    params       paramstring
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseCreateCat(
  params      in  varchar2,
  opts        out createRec
);

/*----------------------- ParseAlterCat  -----------------------*/
/*
  NAME
    ParseAlterCat

  DESCRIPTION
    parse alter index parameters string for ctxcat indextype

  ARGUMENTS
    params       paramstring
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseAlterCat(
  idxid       in  number,
  params      in  varchar2,
  opts        out alterRec
);

/*----------------------- normalize_column_list  -----------------------*/
/*
  NAME
    normalize_column_list

  DESCRIPTION
    normalize a column list

  ARGUMENTS
    column_list  column list

  NOTES

  EXCEPTIONS

  RETURNS
    normalized column list
*/
FUNCTION normalize_column_list(
  column_list in varchar2
) RETURN varchar2;




/* ======================================================================= */
/* ======================================================================= */
/*                               CTXRULE                                   */
/* ======================================================================= */
/* ======================================================================= */

/*----------------------- ParseCreateRule  -----------------------*/
/*
  NAME
    ParseCreateRule

  DESCRIPTION
    parse create index parameters string for ctxrule indextype

  ARGUMENTS
    params       paramstring
    alter_op     zero unless called from ParseAlter
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseCreateRule(
  params      in  varchar2,
  alter_op    in  number,
  opts        out createRec
);

/*----------------------- ParseAlterRule  -----------------------*/
/*
  NAME
    ParseAlter

  DESCRIPTION
    parse alter index parameters string for ctxrule indextype

  ARGUMENTS
    idxid        index id
    params       paramstring
    opts         alter index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseAlterRule(
  idxid       in     number,
  params      in     varchar2,
  opts        in out alterRec
);

/* ======================================================================= */
/* ======================================================================= */
/*                             CTXXPATH                                    */
/* ======================================================================= */
/* ======================================================================= */

/*----------------------- ParseCreateXPath  -----------------------*/
/*
  NAME
    ParseCreateXPath

  DESCRIPTION
    parse create index parameters string for ctxxpath indextype

  ARGUMENTS
    params       paramstring
    opts         create index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseCreateXPath(
  params      in  varchar2,
  alter_op    in  number,
  opts        out createRec
);

/*----------------------- ParseAlterXPath  -----------------------*/
/*
  NAME
    ParseAlter

  DESCRIPTION
    parse alter index parameters string

  ARGUMENTS
    idxid        index id
    params       paramstring
    opts         alter index options (OUT)

  NOTES

  EXCEPTIONS

  RETURNS

*/
PROCEDURE ParseAlterXPath(
  idxid       in     number,
  params      in     varchar2,
  opts        in out alterRec
);

PROCEDURE ParseMigrate (
  params  in out varchar2,
  opts    in out alterRec
);

end driparse;
/

