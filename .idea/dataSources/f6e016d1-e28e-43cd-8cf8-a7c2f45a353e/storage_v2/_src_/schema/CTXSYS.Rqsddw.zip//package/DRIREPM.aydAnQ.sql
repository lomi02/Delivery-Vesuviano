create package drirepm as

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

/*--------------------------- describe_index --------------------------------*/

procedure describe_index(
  idx           in dr_def.idx_rec,
  report        in out nocopy clob,
  report_format in varchar2 DEFAULT 'TEXT'
);

/*--------------------------- describe_policy -------------------------------*/

procedure describe_policy(
  idx           in dr_def.idx_rec,
  report        in out nocopy clob,
  report_format in varchar2 DEFAULT 'TEXT'
);

/*-------------------------- create_index_script ----------------------------*/

procedure create_index_script(
  idx             in dr_def.idx_rec,
  report          in out nocopy clob,
  prefname_prefix in varchar2 default null,
  isjson          in boolean default false
);

/*-------------------------- create_policy_script ---------------------------*/

procedure create_policy_script(
  idx             in dr_def.idx_rec,
  report          in out nocopy clob,
  prefname_prefix in varchar2 default null
);

end drirepm;
/

