create package drvxmd authid current_user is


/*---------------------------- GetIndexRec -------------------------------*/
POL_INDEX_ONLY      constant number := 0;
POL_POLICY_ONLY     constant number := 1;
POL_INDEX_OR_POLICY constant number := 2;

SEC_NONE            constant number := 0;
SEC_CONTAINS        constant number := 1;
SEC_OWNER           constant number := 2;
SEC_ALTER           constant number := 3;
SEC_DROP            constant number := 4;

function  GetIndexRec(
  p_idx_name  in varchar2,
  f_ispolicy  in number  	default POL_INDEX_ONLY,
  f_security  in number   default SEC_CONTAINS,
  p_view_name in varchar2 default NULL,
  f_isdefiner in boolean  default false
) return dr_def.idx_rec;

/*---------------------------- GetIndexID  -------------------------------*/
/* get index id by name */

FUNCTION GetIndexID(
  p_idx_name in varchar2
) return number;


/*---------------------------- GetIndexMD  -------------------------------*/
/* fetch selected dr$index column values into out variables */

procedure GetIndexMD(
  p_idxid           in  number,
  o_owner           out varchar2,
  o_owner#          out number,
  o_name            out varchar2,
  o_table_obj#      out number,
  o_table_dataobj#  out number,
  o_key_name        out varchar2,
  o_key_type        out binary_integer,
  o_text_name       out varchar2,
  o_text_type       out binary_integer,
  o_text_length     out binary_integer,
  o_lang_col        out varchar2,
  o_fmt_col         out varchar2,
  o_cset_col        out varchar2,
  o_idx_type        out binary_integer,
  o_idx_option      out varchar2,
  o_idx_sync_type   out varchar2,
  o_idx_sync_memory out number,
  o_idx_src_name    out varchar2,
  o_idx_src_id      out binary_integer,
  o_idx_version     out binary_integer,
  o_config_col      out varchar2
);

/*---------------------------- GetIndexPartition  -----------------------*/
/* get dr$index_partition information */

procedure GetIndexPartition(
  o_id               out number,
  o_tabpart_dataobj# out number,
  o_sync_type        out varchar2,
  o_sync_memory      out number,
  o_option           out varchar2,
  i_cid               in number,
  i_pname             in varchar2
);

/*---------------------------- OpenIndexMDScan ----------------------*/
/* open dr$index_object and value cursors */

procedure OpenIndexMDScan(
  p_idxid           in  number
);

/*---------------------------- NextIndexObject ---------------------------*/
/* get next dr$index_object cursor */

function NextIndexObject(
  o_cla_id          out binary_integer,
  o_obj_id          out binary_integer,
  o_acnt            out binary_integer
) return binary_integer;

/*---------------------------- NextIndexValue ----------------------------*/
/* get next dr$index_value cursor */

function NextIndexValue(
  o_cla_id          out binary_integer,
  o_att_id          out binary_integer,
  o_datatype        out binary_integer,
  o_sub_group       out binary_integer,
  o_sub_att_id      out binary_integer,
  o_sub_datatype    out binary_integer,
  o_value           out varchar2
) return binary_integer;

/*---------------------------- NextIndexCDI ---------------------------*/
/* get next dr$index_cdi_column cursor */

function NextIndexCDI(
  o_cdi_pos         out binary_integer,
  o_cdi_type#       out binary_integer,
  o_cdi_len         out binary_integer,
  o_cdi_name        out varchar2,
  o_cdi_sec         out varchar2,
  o_cdi_stype       out binary_integer,
  o_cdi_id          out binary_integer
) return binary_integer;

/*---------------------------- GetDocidCount -----------------------------*/
/* get docid count */

function GetDocidCount(
  p_idxid           in number,
  p_ixpid           in number default null
) return number;


/*--------------------------- GetNextId -------------------------------------*/
/* get next docid */

function GetNextId(
  p_idxid in binary_integer,
  p_ixpid in binary_integer default null
) return binary_integer;

/*-------------------------------- GetLastID --------------------------------*/
/* get last docid */

function GetLastID(
  p_idxid           in number,
  p_ixpid           in number)
return number;

/*-------------------------------- SetLastID --------------------------------*/
/* set last docid */

procedure SetLastID(
  p_idxid           in  number,
  p_ixpid           in  number,
  p_lastid          in  number);

/*---------------------------- GetIndexStats -----------------------------*/
/* get index stats from dr$stats */

procedure GetIndexStats(
  p_idxid           in number,
  p_smplsz          in out nocopy number
);

/*---------------------------- GetBaseTableName --------------------------*/
/* get base table name */

function GetBaseTableName(
  p_idxid           in number,
  p_ixpid           in number default null
) return varchar2;

/*---------------------------- IncrementDocCnt --------------------------*/
/* increment docid count */

procedure IncrementDocCnt(
  p_idxid           in number,
  p_ixpid           in number,
  p_delta           in number
);

/*--------------------------- DecrementDocCnt ------------------------------*/
/* decrement docid count */
procedure DecrementDocCnt(
  p_idxid in number,
  p_ixpid in number,
  p_delta in number
);

/*---------------------------- AllocateDocids ---------------------------*/
/* allocate docids */

procedure AllocateDocids(
  p_idxid           in  number,
  p_ixpid           in  number,
  p_allocsz         in  binary_integer,
  p_startid         out number
);

/*---------------------------- RecordIndexError -------------------------*/
/* records an error to the dr$index_error table */

procedure RecordIndexError(
  p_idxid           in number,
  p_textkey         in varchar2,
  p_stack           in varchar2
);

/*---------------------------- OptStartTimer -----------------------------*/
/* starts optimization timer */

procedure OptStartTimer;

/*---------------------------- OptGetTimer -------------------------------*/
/* gets optimization timer */

function OptGetTimer return binary_integer;

/*---------------------------- OptGetState -------------------------------*/
/* get full optimize state */

procedure OptGetState(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_ntable_name in  varchar2,
  p_itable_name in  varchar2,
  p_sntable_name in  varchar2,
  p_beg_s_opt   in  boolean,
  o_opt_token   out varchar2,
  o_opt_type    out number
);

/*---------------------------- OptGetType -------------------------------*/
/* get type optimize start token */

procedure OptGetType(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_ntable_name in  varchar2,
  p_itable_name in  varchar2,
  p_sntable_name in  varchar2,
  o_opt_token   out varchar2,
  o_opt_type    in  number,
  p_kgtable_name in  varchar2 default null
);

/*---------------------------- OptSetState -------------------------------*/
/* set full optimize state */

procedure OptSetState(
  p_idxid       in  number,
  p_ixpid       in  number,
  p_opt_token   in  varchar2,
  p_opt_type    in  number
);

/*---------------------------- GetFieldSecName -----------------------------*/
/* get field section name */

function GetFieldSecName (
  p_idxid  in number,
  p_secid  in number
) return varchar2;

/*---------------------------- GetPrefClaObj -----------------------------*/

procedure GetPrefClaObj(
  p_preid  in  number,
  o_claid  out number,
  o_objid  out number
);

/*---------------------------- GetObjDefault -----------------------------*/

procedure GetObjDefault(
  p_oatid   in  number,
  o_default out varchar2
);

/*---------------------------- OpenPrefValue ------------------------------*/

procedure OpenPrefValue(
  p_preid   in number
);

/*---------------------------- NextPrefValue ------------------------------*/

function NextPrefValue(
  o_value   out varchar2,
  o_oatid   out number
) return binary_integer;

/*---------------- set_reverse_docid_switch  -------------------*/

PROCEDURE set_reverse_docid_switch(
  owner_name     in  varchar2,
  index_name     in  varchar2,
  value          in  varchar2
);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_reverse_docid_switch, AUTO);

/*------------------- get_functional_cache_size ----------------------------*/
FUNCTION get_functional_cache_size RETURN number;

/*--------------- GetMVFlag ------------------------------------------------*/
/*
  NAME
    GetMVFlag

  DESCRIPTION
    Check whether it's index on Materialized View

  ARGUMENTs
    table_id
    owner_name
    opt              1 -- index on MView
                     0 -- not index on MView
*/

PROCEDURE GetMVFlag(
  table_id       in  number,
  owner_name     in  varchar2,
  opt            out binary_integer
);

/*---------------------------- GetSecDataType -----------------------------*/
/* get section datatype, mainly for MDATA and SDATA */

function GetSecDataType (
  p_idxid  in number,
  p_secid  in number
) return number;

/*---------------------------- ChkIndexOption -----------------------------*/
/*
  Take in index id, and an option letter (see drdmlop() for a list of
  options), return 1 if the given option is set, 0 otherwise.
*/
function ChkIndexOption (
  p_idxid  in number,
  p_opt    in varchar2
) return number;

/*---------------------------- SelectUserAnlDictLob-----------------------------*/
/*
  Take index id and dictionary language as input and return user supplied
  dictionary lob to be used by ATG auto lexer
*/
function SelectUserAnlDictLob(
  p_idxid  in number,
  p_dictlang in varchar2
) return clob;

/*--------------------------- ctx_sqe_tbl_func ------------------------------*/
/*
  Table function for creating the ctx_user_sqes view
*/
type ctx_sqe_type is record(
  sqe_owner# number,
  sqe_name varchar2(30),
  sqe_query clob);

type ctx_sqe_type_tab is table of ctx_sqe_type;

function ctx_sqe_tbl_func
  return ctx_sqe_type_tab pipelined;

/*--------------------------- autoopt_prep --------------------------------*/
/* autoopt_prep - preparation for autoopt */
procedure autoopt_prep(p_idxid in number,
                       p_ixpid in number,
                       p_wait in number,
                       p_lockret in out number
);

/*--------------------------- autoopt_clo --------------------------------*/
/* autoopt_clo - close for autoopt */
procedure autoopt_clo;

/*--------------------------- autoopt_push_token --------------------------*/
/* autoopt_push_token - push a token to autooptimize */
procedure autoopt_push_token(p_idxid in number,
                             p_message in raw);

/*--------------------------- TxnalGetKey --------------------------------*/
/* Return the key if it has been set.  Returns Null if not set            */
procedure TxnalGetKey(
  p_key in out raw
);

/*--------------------------- TxnalSetKey --------------------------------*/
/* Set the key.  Set flag                                                 */
procedure TxnalSetKey(
  p_key in raw
);

/*------------------------ GetSLXMdataSecID ------------------------------*/
/* Get section id/token type for DR$ML MDATA section, doc level lexer     */

FUNCTION GetSLXMdataSecID(
  idxid in number
) return number;

/*------------------------ RecordOptTokenError ---------------------------*/
PROCEDURE RecordOptTokenError(
  token_text in varchar2,
  token_type in number
);

/*----------------------- ProcessN -------------------------------*/
PROCEDURE ProcessN(p_idxid in number,
                   p_ixpid in number,
                   del     in number,
                   maxtime in number   default 2147483647,
                   optmode in varchar2 default null);

/* 14175174: ------------- SubstringEnabled ------------------------*/
FUNCTION SubstringEnabled(p_idxid in number) RETURN number;


/*---------------------------- IndexHasGTable ------------------------------*/
FUNCTION IndexHasGTable(
  p_idxid in number,
  p_ixpid in number default NULL)
RETURN boolean;

/*----------------------- resolve_pattern -------------------------------*/
FUNCTION resolve_pattern(
  p_policy_id        in number,
  p_regular_expr     in varchar2,
  p_index_name       in varchar2,
  p_regexpr_maxterms in number) return clob;

/*--------------------------- drop_bg_optimize ----------------------------*/
/* drop background jobs of optimize index / partition */
procedure drop_bg_optimize(p_idx_id      in number,
                           p_idx_name    in varchar2,
                           p_ixp_id      in number default null,
                           p_optlevel    in varchar2 default null
);

/*--------------------------- add_bg_optimize ----------------------------*/
/* add a background job of optimize index / partition */
procedure add_bg_optimize(p_idx_name    in varchar2,
                          p_ixp_name    in varchar2 default null,
                          p_optlevel    in varchar2,
                          p_para_degree in number default 1, -- parallel degree
                          p_repeat_interval in varchar2 default null
);

/*--------------------------- run_bg_optimize ---------------------------*/
/* actually run the background optimize job */
procedure run_bg_optimize(p_idx_name    in varchar2,
                          p_ixp_name    in varchar2,
                          p_optlevel    in varchar2, -- optmize mode
                          p_para_degree in number,   -- parallel degree
                          p_logfile     in varchar2, -- log file
                          p_events      in varchar2  -- events
);

/*------------------------ IndexHasPathHashIndex ------------------------*/
/* Checks if index already has path_hash column in the $S* index */
function IndexHasPathHashIndex(p_idx_owner   in varchar2,
                               p_stab_name   in varchar2,
                               p_sidx_name   in varchar2
) return boolean accessible by (package ctxsys.drvxtab);

/*---------------------------- add_auto_sync ---------------------------*/
/* add a background job for sync every */
procedure add_auto_sync(p_idxid      in number,
                        p_ixpid      in number,
                        p_owner      in varchar2,
                        p_index_name in varchar2,
                        p_part_name  in varchar2,
                        p_memsize    in number,
                        p_para_degree in number,
                        p_interval   in varchar2
);

/*--------------------------- drop_auto_sync ----------------------------*/
/* drop the background sync job */
procedure drop_auto_sync(p_idx_id    in number,
                         p_idx_name  in varchar2,
                         p_ixp_id    in number default null
);

/*--------------------------- IsValidTablespace ---------------------------*/
/* Check the tablespace name. Return true if the tablespace name exist */
FUNCTION IsValidTablespace(p_tablespace_name  in varchar2)
return boolean;

/*--------------------------- GetTabTablespace ---------------------------*/
/* return the tablespace name used for CONTEXT_V2 index
 * if the base table is partitioned, return null.
 */
FUNCTION GetTabTablespace(p_tab_name      in varchar2,
                          p_tab_owner     in varchar2
) return varchar2;

end drvxmd;
/

