create view CTX_AUTOSYNC_STATUS as
select l.job_name  asj_job_name,
         l.log_date  asj_timestamp,
         l.status    asj_status,
         r.additional_info asj_error
    from sys.dba_scheduler_job_run_details r,
         sys.dba_scheduler_job_log l
   where
         l.owner = r.owner and
         l.log_id = r.log_id and
         l.job_name like '%$ASJ' and
         l.owner = 'CTXSYS'
/

