create view CTX_USER_ALEXER_DICTS as
select dict_name ald_name, dict_lang ald_lang
  from DR$DICTIONARY
  where dict_owner# = userenv('SCHEMAID')
/

