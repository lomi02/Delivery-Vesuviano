create view CTX_USER_EXTRACT_TYPE as
select
  e.ert_pol_id ert_pol_id,
  e.ert_rule_id ert_rule_id,
  e.ert_type_id ert_type_id,
  e.ert_type ert_type,
  e.ert_refid ert_refid
  from dr$user_extract_type e, dr$index i
  where i.idx_owner# = userenv('SCHEMAID')
  and e.ert_pol_id = i.idx_id
/

