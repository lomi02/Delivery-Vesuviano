create view MGMT_BSLN_METRICS
            (METRIC_UID, TAIL_ESTIMATOR, THRESHOLD_METHOD_DEFAULT, NUM_OCCURRENCES_DEFAULT, WARNING_PARAM_DEFAULT,
             CRITICAL_PARAM_DEFAULT)
as
select bsln.metric_uid(bmd.metric_id)
      ,'EXPTAIL'
      ,'SIGLVL'
      ,1
      ,.999
      ,.9999
  from bsln_metric_defaults bmd
 where bmd.status = 'PREFERRED'
/

comment on table MGMT_BSLN_METRICS is 'Metrics Eligible for Baselines (10.2)'
/

