create FUNCTION     "F$DV$_CLIENT_IDENTIFIER" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'DV$_Client_Identifier'); END;
/

