create FUNCTION     "F$DV$_DBLINK_INFO" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'DV$_Dblink_Info'); END;
/

