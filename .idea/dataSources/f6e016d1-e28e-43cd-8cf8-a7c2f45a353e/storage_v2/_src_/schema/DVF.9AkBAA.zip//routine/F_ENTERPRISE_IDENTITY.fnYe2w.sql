create FUNCTION     "F$ENTERPRISE_IDENTITY" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Enterprise_Identity'); END;
/

