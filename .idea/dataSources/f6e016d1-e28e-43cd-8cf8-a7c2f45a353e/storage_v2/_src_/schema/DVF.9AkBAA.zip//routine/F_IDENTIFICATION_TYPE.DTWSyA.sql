create FUNCTION     "F$IDENTIFICATION_TYPE" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Identification_Type'); END;
/

