create FUNCTION     "F$PROXY_ENTERPRISE_IDENTITY" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Proxy_Enterprise_Identity'); END;
/

