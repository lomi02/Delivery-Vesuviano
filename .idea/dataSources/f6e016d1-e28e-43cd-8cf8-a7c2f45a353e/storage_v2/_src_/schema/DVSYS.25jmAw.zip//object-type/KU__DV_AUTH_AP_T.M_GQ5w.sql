create type       ku$_dv_auth_ap_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  oidval        raw(16),                                       /* unique id */
  owner_name    varchar2(128),                     /* name of package owner */
  package_name  varchar2(128)                            /* name of package */
)
/

