create type       ku$_dv_oradebug_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  state         varchar2(128)                             /* ORADEBUG state */
)
/

