create type       ku$_dv_policy_obj_c_t as object
(
  vers_major      char(1),                           /* UDT major version # */
  vers_minor      char(1),                           /* UDT minor version # */
  oidval          raw(16),                                     /* unique id */
  policy_name     varchar2(128),                       /* name of DV policy */
  command         varchar2(128),                                 /* command */
  object_owner    varchar2(128),                            /* object owner */
  object_name     varchar2(128),                             /* object name */
  scope           number
)
/

