create type         "SYS_YOID0000075395$"              as object( "SYS_NC00001$" RAW(16))
/

