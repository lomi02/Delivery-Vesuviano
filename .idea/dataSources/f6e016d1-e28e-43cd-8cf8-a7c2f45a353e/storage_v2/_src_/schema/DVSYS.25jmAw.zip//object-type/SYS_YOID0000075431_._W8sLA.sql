create type         "SYS_YOID0000075431$"              as object( "SYS_NC00001$" VARCHAR2(8 BYTE))
/

