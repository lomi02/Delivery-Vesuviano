create PACKAGE       dbms_macout
AS
    /**
    * Turn on tracing.
    */
    PROCEDURE enable;
    PRAGMA SUPPLEMENTAL_LOG_DATA(enable, NONE);

    /**
    * Turn off tracing.
    */
    PROCEDURE disable;
    PRAGMA SUPPLEMENTAL_LOG_DATA(disable, NONE);

    /**
    * Add text to the output (with a new line)
    * @param s String
    */
    PROCEDURE put_line( s IN VARCHAR2 );
    PRAGMA SUPPLEMENTAL_LOG_DATA(put_line, NONE);

    /**
    * Same as put_line.
    * @param s String
    */
    PROCEDURE pl( s IN VARCHAR2 );
    PRAGMA SUPPLEMENTAL_LOG_DATA(pl, NONE);

    /**
    * Retrieve a line of text from the buffer.  The line is deleted from
    * the line buffer.
    * @param n Line number
    */
    FUNCTION get_line( n IN NUMBER ) RETURN VARCHAR2;

    PRAGMA RESTRICT_REFERENCES( get_line, WNDS, RNDS );
    PRAGMA SUPPLEMENTAL_LOG_DATA(get_line, NONE);

    /**
    * Number of lines in the buffer.
    * @return Number of lines in the buffer
    */
    FUNCTION get_line_COUNT RETURN NUMBER;
    PRAGMA SUPPLEMENTAL_LOG_DATA(get_line_COUNT, NONE);

    /**
    * Is the trace facility enabled.
    * @return An indicator that the trace facility is enabled for this session
    */
    FUNCTION is_enabled RETURN BOOLEAN;
    PRAGMA SUPPLEMENTAL_LOG_DATA(is_enabled, NONE);

    PRAGMA RESTRICT_REFERENCES( get_line_COUNT, WNDS, RNDS, WNPS );

    PRAGMA RESTRICT_REFERENCES( dbms_macout, WNDS, RNDS, WNPS, RNPS );
END;
/

