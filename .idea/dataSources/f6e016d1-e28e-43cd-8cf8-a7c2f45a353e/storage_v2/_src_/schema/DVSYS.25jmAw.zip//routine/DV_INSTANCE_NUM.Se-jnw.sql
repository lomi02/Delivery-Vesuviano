create function       DV_INSTANCE_NUM return NUMBER as
begin
  -- Fix for Bug 6068504
  return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'INSTANCE_NUM');
end;
/

