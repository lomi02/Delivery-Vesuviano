create function       DV_JOB_INVOKER return VARCHAR2 as
begin
  return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'JOB_INVOKER');
end;
/

