create PROCEDURE       macols_init_session
IS
BEGIN
  dvsys.dbms_macols.init_session;
EXCEPTION
  -- Try to suppress stack trace
  WHEN OTHERS THEN
    --RAISE;
    NULL;
END;
/

