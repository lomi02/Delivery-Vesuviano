create FUNCTION       stack_varray_to_clob(va IN dvsys.plsql_stack_array)
RETURN CLOB IS
cl      CLOB;
BEGIN
  IF (va.count = 0) THEN
    RETURN NULL;
  END IF;

  FOR i in 1..va.count LOOP
    IF i = 1 THEN
      cl := cl || va(i);
    ELSE
      cl := cl || ' <= ' || va(i);
    END IF;
  END LOOP;

  RETURN cl;
END;
/

