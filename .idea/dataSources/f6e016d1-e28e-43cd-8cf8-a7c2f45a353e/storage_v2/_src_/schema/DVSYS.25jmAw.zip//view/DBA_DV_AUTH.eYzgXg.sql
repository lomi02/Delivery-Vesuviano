create view DBA_DV_AUTH as
SELECT
    grant_type
  , u1.name
  , u2.name
  , da.object_name
  , da.object_type
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u2
WHERE da.grantee_id = u1.user# and
      da.object_owner_id = u2.user#
UNION
SELECT
    grant_type
  , u1.name
  , '%'
  , object_name
  , object_type
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1
WHERE da.grantee_id = u1.user# and
      da.object_owner_id = 2147483636
UNION
SELECT
    grant_type
  , '%'
  , u2.name
  , object_name
  , object_type
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u2
WHERE da.grantee_id = 2147483636 and
      da.object_owner_id = u2.user#
UNION
SELECT
    grant_type
  , '%'
  , '%'
  , object_name
  , object_type
FROM dvsys.dv_auth$ da
WHERE da.grantee_id = 2147483636 and
      da.object_owner_id = 2147483636
/

