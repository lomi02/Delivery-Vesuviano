create view DBA_DV_POLICY (POLICY_NAME, DESCRIPTION, STATE, ID#, ORACLE_SUPPLIED, PL_SQL_STACK) as
SELECT
    pt.name
  , pt.description
  , decode(p.state, 0, 'DISABLED',
                    1, 'ENABLED',
                    2, 'SIMULATION',
                    3, 'PARTIAL')
  , p.id#
  , CASE WHEN p.id# < 5000 THEN 'YES' ELSE 'NO' END
  , decode(p.pl_sql_stack, 0, 'NO',
                           1, 'YES')
FROM dvsys.policy$ p, dvsys.policy_t$ pt
WHERE p.id# = pt.id# AND
      pt.language = DVSYS.dvlang(pt.id#, 7)
/

