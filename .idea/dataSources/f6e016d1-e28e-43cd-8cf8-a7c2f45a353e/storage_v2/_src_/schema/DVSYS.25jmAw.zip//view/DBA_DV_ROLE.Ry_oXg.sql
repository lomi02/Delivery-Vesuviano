create view DBA_DV_ROLE (ROLE, RULE_NAME, ENABLED, ID#, ORACLE_SUPPLIED) as
SELECT
      m.role
    , d.name
    , m.enabled
    , m.id#
    , CASE WHEN m.id# < 5000 THEN 'YES' ELSE 'NO' END
FROM dvsys.role$ m, dvsys.dv$rule_set d
WHERE m.rule_set_id# = d.id#
/

