create view DBA_DV_RULE_SET
            (RULE_SET_NAME, DESCRIPTION, ENABLED, EVAL_OPTIONS_MEANING, AUDIT_OPTIONS, FAIL_OPTIONS_MEANING,
             FAIL_MESSAGE, FAIL_CODE, HANDLER_OPTIONS, HANDLER, IS_STATIC, COMMON, INHERITED, ID#, ORACLE_SUPPLIED)
as
SELECT
      d.name
    , d.description
    , m.enabled
    , deval.value
    , m.audit_options
    , dfail.value
    , d.fail_message
    , m.fail_code
    , m.handler_options
    , m.handler
    , DECODE(bitand(m.eval_options, 128) , 128, 'TRUE', 'FALSE')
    , decode(m.scope, 1, 'NO',
                      2, 'YES',
                      3, 'YES') common
    , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
           THEN 'YES'
           ELSE 'NO'
      END inherited
    , m.id#
    , CASE WHEN (m.id# < 5000)
           THEN 'YES'
           ELSE 'NO'
      END
FROM dvsys.rule_set$ m
    , dvsys.rule_set_t$ d
    , dvsys.dv$code deval
    , dvsys.dv$code dfail
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 5)
    AND deval.code  = TO_CHAR(m.eval_options -
                             DECODE(bitand(m.eval_options,128) , 128, 128, 0))
    AND deval.code_group = 'RULESET_EVALUATE'
    AND dfail.code  = TO_CHAR(m.fail_options)
    AND dfail.code_group = 'RULESET_FAIL'
/

