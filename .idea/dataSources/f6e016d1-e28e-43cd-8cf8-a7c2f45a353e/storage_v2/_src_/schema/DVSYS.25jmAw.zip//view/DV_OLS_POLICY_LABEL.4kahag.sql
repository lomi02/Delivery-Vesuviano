create view DV$OLS_POLICY_LABEL as
SELECT
      d2.pol#
    , d2.pol_name
    , d3.tag#
    , d3.slabel -- or labeltochar(d3.lab#)
FROM
     lbacsys.ols$pol d2
    , lbacsys.ols$lab d3
WHERE
    d2.pol# = d3.pol#
/

