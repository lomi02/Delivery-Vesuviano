create view DV$RULE as
SELECT
      m.id#
    , d.name
    , m.rule_expr
    , m.version
    , m.created_by
    , m.create_date
    , m.updated_by
    , m.update_date
    , decode(m.scope, 1, 'NO',
                      2, 'YES',
                      3, 'YES') common
    , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
           THEN 'YES'
           ELSE 'NO'
      END inherited
FROM dvsys.rule$ m, dvsys.rule_t$ d
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 4)
/

