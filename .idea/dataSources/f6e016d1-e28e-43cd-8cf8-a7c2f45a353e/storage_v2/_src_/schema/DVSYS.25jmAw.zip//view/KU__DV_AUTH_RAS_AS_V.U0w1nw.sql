create view KU$_DV_AUTH_RAS_AS_V (VERS_MAJOR, VERS_MINOR, OIDVAL, GRANTEE_NAME, RAS_USER) as
select '0','0',sys_guid(),
          p.grantee,
          p.ras_user
  from    dvsys.dba_dv_ras_attach_session_auth p
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

