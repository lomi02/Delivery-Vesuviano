create view KU$_DV_INDEX_FUNC_V (VERS_MAJOR, VERS_MINOR, OBJECT_NAME) as
select '0','0',
          p.object_name
  from    dvsys.dba_dv_index_function p
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

