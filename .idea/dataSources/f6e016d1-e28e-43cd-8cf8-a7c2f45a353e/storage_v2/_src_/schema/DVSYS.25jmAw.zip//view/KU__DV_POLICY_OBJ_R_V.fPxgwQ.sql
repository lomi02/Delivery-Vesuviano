create view KU$_DV_POLICY_OBJ_R_V (VERS_MAJOR, VERS_MINOR, POLICY_NAME, REALM_NAME) as
select '0','0',
          p.name,
          rt.name
  from    dvsys.policy_t$      p,
          dvsys.policy_object$ po,
          dvsys.realm_t$       rt
  where   po.id# >= 5000
    and   po.object_type = 1  -- realm
    and   po.policy_id# = p.id#
    and   po.object_id# = rt.id#
    and   p.language = dvsys.dvlang(p.id#, 7)
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

