create view KU$_DV_REALM_MEMBER_VIEW (VERS_MAJOR, VERS_MINOR, OIDVAL, NAME, OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE) as
select '0','0',sys_guid(),
          rlmt.name,
          rlmo.owner,
          rlmo.object_name,
          rlmo.object_type
  from    dvsys.realm_t$        rlmt,
          dvsys.dv$realm_object rlmo
  where   rlmo.realm_id# = rlmt.id#
    and   rlmt.id# > 5000
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

