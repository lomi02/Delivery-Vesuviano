create view KU$_DV_REALM_VIEW
            (VERS_MAJOR, VERS_MINOR, NAME, DESCRIPTION, LANGUAGE, REALM_TYPE, REALM_SCOPE, ENABLED, AUDIT_OPTIONS) as
select '0','0',
          rlmt.name,
          rlmt.description,
          rlmt.language,
          rlm.realm_type,
          decode(rlm.scope, 1, 1, 2, 2, 3, 2),
          rlm.enabled,
          decode(rlm.audit_options,
                 0,'DVSYS.DBMS_MACUTL.G_REALM_AUDIT_OFF',
                 1,'DVSYS.DBMS_MACUTL.G_REALM_AUDIT_FAIL',
                 2,'DVSYS.DBMS_MACUTL.G_REALM_AUDIT_SUCCESS',
                 3,'(DVSYS.DBMS_MACUTL.G_REALM_AUDIT_SUCCESS+'||
                    'DVSYS.DBMS_MACUTL.G_REALM_AUDIT_FAIL)',
                 to_char(rlm.audit_options))
  from    dvsys.realm$        rlm,
          dvsys.realm_t$      rlmt
  where   rlm.id# = rlmt.id#
    and   rlm.id# > 5000
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

