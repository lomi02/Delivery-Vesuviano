create view POLICY_OWNER_REALM_AUTH as
SELECT
    d1.name
  , d1.common
  , d1.inherited
  , u.name
  , d2.name
  , c.value
  , decode(m.scope, 1, 'NO',
                    2, 'YES',
                    3, 'YES') common_auth
  , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
              (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
         THEN 'YES'
         ELSE 'NO'
    END inherited_auth
FROM  dvsys.realm_auth$ m
    , dvsys.dv$realm d1
    , dvsys.dv$rule_set d2
    , dvsys.dv$code c
    , (select user#, name from sys."_BASE_USER"
       union
       select id as user#, name from sys.xs$obj where type = 1) u
WHERE
    d1.id# (+)= m.realm_id#
    AND d2.id# (+)= m.auth_rule_set_id#
    AND c.code_group (+) = 'REALM_OPTION'
    AND c.code (+) = TO_CHAR(m.auth_options)
    AND m.grantee_uid# = u.user#
    AND d1.id# IN (SELECT object_id#
                   FROM dvsys.policy_object$ pb, dvsys.policy_owner$ pw
                   WHERE pb.policy_id# = pw.policy_id# AND
                         pw.owner_id# =  sys_context('userenv', 'current_userid') AND
                         pb.object_type = 1) --dvsys.dbms_macutl.G_REALM
/

