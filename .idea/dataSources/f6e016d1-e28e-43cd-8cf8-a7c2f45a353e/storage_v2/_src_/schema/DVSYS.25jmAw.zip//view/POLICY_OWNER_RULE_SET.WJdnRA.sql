create view POLICY_OWNER_RULE_SET
            (RULE_SET_NAME, DESCRIPTION, ENABLED, EVAL_OPTIONS_MEANING, AUDIT_OPTIONS, FAIL_OPTIONS_MEANING,
             FAIL_MESSAGE, FAIL_CODE, HANDLER_OPTIONS, HANDLER, IS_STATIC, ID#, ORACLE_SUPPLIED)
as
SELECT
      d.name
    , d.description
    , m.enabled
    , deval.value
    , m.audit_options
    , dfail.value
    , d.fail_message
    , m.fail_code
    , m.handler_options
    , m.handler
    , DECODE(bitand(m.eval_options, 128) , 128, 'TRUE', 'FALSE')
    , m.id#
    , CASE WHEN (m.id# < 5000)
           THEN 'YES'
           ELSE 'NO'
      END
FROM dvsys.rule_set$ m
    , dvsys.rule_set_t$ d
    , dvsys.dv$code deval
    , dvsys.dv$code dfail
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 5)
    AND deval.code  = TO_CHAR(m.eval_options -
                             DECODE(bitand(m.eval_options,128) , 128, 128, 0))
    AND deval.code_group = 'RULESET_EVALUATE'
    AND dfail.code  = TO_CHAR(m.fail_options)
    AND dfail.code_group = 'RULESET_FAIL'
    AND (d.name IN (SELECT pora.auth_rule_set_name
                    FROM dvsys.policy_owner_realm_auth pora) OR
         d.name IN (SELECT pocr.rule_set_name
                    FROM dvsys.policy_owner_command_rule pocr))
/

