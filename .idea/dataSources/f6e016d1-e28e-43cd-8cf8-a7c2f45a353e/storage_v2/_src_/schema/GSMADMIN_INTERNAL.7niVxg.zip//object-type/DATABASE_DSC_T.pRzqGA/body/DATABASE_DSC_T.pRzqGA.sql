create type BODY database_dsc_t AS
  CONSTRUCTOR FUNCTION database_dsc_t (SELF IN OUT NOCOPY database_dsc_t,
                                      dbnum NUMBER )
                                     RETURN SELF AS RESULT IS
  BEGIN
    SELF.db_number := dbnum;
    RETURN;
  END;
END;
/

