create type BODY gsm_info AS
  CONSTRUCTOR FUNCTION gsm_info (SELF IN OUT NOCOPY gsm_info )
                                     RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;
END;
/

