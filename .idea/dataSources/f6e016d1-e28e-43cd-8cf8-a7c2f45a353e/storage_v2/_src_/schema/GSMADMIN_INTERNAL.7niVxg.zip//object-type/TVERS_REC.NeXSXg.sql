create TYPE tvers_rec IS OBJECT (
   vers_str       varchar(30), -- string version
   vers_num       number       -- numeric version
);
/

