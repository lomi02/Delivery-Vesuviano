create TYPE t_shdcol_row AS OBJECT (
  key_level             number, -- 0:super key column; 1: shard key column
  col_cnt               number, -- number of columns in this level
  position              number, -- position of column in this level
  col_type              number, -- column type
  col_name              VARCHAR2(128)
)
/

