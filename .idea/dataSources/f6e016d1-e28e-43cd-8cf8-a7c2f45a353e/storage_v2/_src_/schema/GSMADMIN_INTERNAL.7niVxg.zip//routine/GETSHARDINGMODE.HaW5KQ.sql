create FUNCTION getShardingMode wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
85 c2
iXqbIi2IdS6cuNWZyzbbZH4KTBAwg2JHr54VfHSpOHIQGEuxpYniLY48V/Ezjz7n/T1qG02P
HmRbciSaqiZ6p/UBER7qLP7+m2i6P2IKtsVcBKbP4IkTbNGOoaY9LoUt4BQEpAsbBIMgA7nN
Tiy0PCjWE/Gc3KjO2G8quqUEwOAer9cWVW/TAE/LO69JCA==
/

