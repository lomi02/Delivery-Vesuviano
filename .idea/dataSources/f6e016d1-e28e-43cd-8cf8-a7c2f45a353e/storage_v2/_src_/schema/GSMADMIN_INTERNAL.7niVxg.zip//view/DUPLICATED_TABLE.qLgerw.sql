create view DUPLICATED_TABLE (OWNER, TABLE_NAME, REFRESH_INTERVAL, RGROUP_OWNER, RGROUP_NAME) as
SELECT
  obj.owner,
  obj.object_name,
  CASE
    WHEN
      max(to_number(REGEXP_SUBSTR(mv.interval, '\d+'))) =
      min(to_number(REGEXP_SUBSTR(mv.interval, '\d+')))
    THEN
      max(to_number(REGEXP_SUBSTR(mv.interval, '\d+')))
    ELSE
      NULL
    END,
  CASE WHEN max(mv.rowner) = min(mv.rowner) THEN max(mv.rowner) ELSE NULL END,
  CASE WHEN max(mv.rname) = min(mv.rname) THEN max(mv.rname) ELSE NULL END
FROM
  shards(DBA_REFRESH_CHILDREN) mv, shards(dba_objects) obj
WHERE obj.duplicated = 'Y'
  AND mv.ORA_SHARD_ID(+) = obj.ORA_SHARD_ID
  AND mv.owner(+) = obj.owner
  AND mv.name(+) = obj.object_name
GROUP BY obj.owner, obj.object_name
WITH READ ONLY
/

