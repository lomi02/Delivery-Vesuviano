create view SHARDED_TABLE_FAMILIES as
select
  tf.family_id, tf.schema_name, tf.root_name,
  gt.schema_name, gt.table_name
from gsmadmin_internal.global_table gt
  left join gsmadmin_internal.table_family tf on gt.family_id = tf.family_id
  order by tf.family_id, gt.table_obj#
with read only
/

