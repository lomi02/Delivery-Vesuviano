create FUNCTION         lbac_label_to_char wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
db e3
vEBv9G5yMY6f8P5AE3DYQolbITIwg3nwf5nWfC8C2sHqaHVnUn389bMRHQhGXQl99U2Oe+cC
JbWuXFb1pWLGmMb+h7cm4Jq2R4Z8+npf0JMillhBav2grB1EoNGmMKxwLfL+w9jqYf46yBGS
tKhk27ILMpUwN4MqdR0dQy9fGErH5AwQCTwNQadhAJIuzLlx0vjsuJbVDnjqVkotPdSJl8xM
QbwdtSo9
/

