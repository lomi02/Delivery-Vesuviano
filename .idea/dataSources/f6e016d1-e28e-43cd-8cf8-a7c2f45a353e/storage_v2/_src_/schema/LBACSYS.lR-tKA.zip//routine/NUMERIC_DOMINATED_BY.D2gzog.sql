create FUNCTION         numeric_dominated_by wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
130 fb
6DLNUW12Bn2f3F4vwHVlazGxB9Iwg41KACisfC9AkPjVSEZGL1IBJ+7dG0Nakn98KsV0dHDg
9aWaDB30RSkuuwD6+Mytxdh+vYvGIWjUbbtk61dPuYS7cnLjr9CwU2eNNxTKsed3+qr/agWI
gvA83qPjlasqWmp13aMJ44mUFq+Z61h3uLvY8tlh99tip4f1s3vvk4ILS4AaeYVv7EPugAGl
E7vq3EMlyIJv22VbDVbkFzW8EvvER4QB
/

