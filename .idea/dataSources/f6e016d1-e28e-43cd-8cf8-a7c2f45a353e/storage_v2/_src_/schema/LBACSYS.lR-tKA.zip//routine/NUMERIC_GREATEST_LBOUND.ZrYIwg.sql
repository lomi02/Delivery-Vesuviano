create FUNCTION         numeric_greatest_lbound wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
11a eb
6Ug5Hf65eRnLSHCC6bgPtAGU0Dswg41K2Z4VfC/pTMHVwn5r50XNxd7Gq+O2dRtIWyw1Njtp
BbXEDVGP8hcScr6/K/uZIHaX6J3UM8+PXv2/TDS/zzGakot15zr4k2Ov0Ro19DiMN8KdQ0OA
3EQ3KEbACk1U1atRoxFNdEo7ZH5nN1mvrljthvdZJ5WvBULpDnp3QTuf+9mRI5YTQCUhH6lD
mO6Z/xcoG9g1ig==
/

