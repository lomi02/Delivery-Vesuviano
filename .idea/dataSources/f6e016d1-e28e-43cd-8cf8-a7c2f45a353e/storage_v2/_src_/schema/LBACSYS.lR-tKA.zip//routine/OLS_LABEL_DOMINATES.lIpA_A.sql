create FUNCTION         ols_label_dominates wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
191 11f
obcxbMX2H6Ybj88N+oDD+LlbTwEwg/BKf5nWfC8C2vjVZavIJZ8yGAh3ZzSJFG9urGPLRLpb
+LXe5WFaNaWnmBLGEv4BlMDVjvG8/XGxcQX/VZLGczE0g6h0hWF71T4wzciNZzbxmes0cJKO
eYEMp6luwQJPOat+Y7P2b8BQonXKN3EOcpSIvQEVUybXGXzqk76uXD7Ik3y1W9jyUKyYCC5T
qWMKRpo2Cmjl2uxTPmPbb6kLd3TPX3M5Jd0Jel9m6EEAyyJMoYJjRSwjNBIdJXS6CA==
/

