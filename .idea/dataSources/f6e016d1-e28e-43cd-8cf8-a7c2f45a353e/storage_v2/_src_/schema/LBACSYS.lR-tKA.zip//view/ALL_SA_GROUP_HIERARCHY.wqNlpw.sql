create view ALL_SA_GROUP_HIERARCHY as
SELECT p.pol_name as policy_name, g.hierarchy_level, g.group_name
     FROM (SELECT LEVEL AS hierarchy_level,
               RPAD(' ',2*LEVEL,' ') || code || ' - ' ||  name AS group_name,
               pol#
             FROM LBACSYS.ols$groups
                  CONNECT BY PRIOR pol#=pol# AND PRIOR group#=parent#
            START WITH ((pol# in (select pol# from LBACSYS.sa$admin
                  where usr_name = SYS_CONTEXT('USERENV', 'CURRENT_USER'))
                         and parent# IS NULL)
                        or
                        (pol#,group#) in
                        (select pol#,group# from LBACSYS.ols$user_groups
                          where usr_name = lbacsys.sa_session.sa_user_name(
                                       lbacsys.lbac_cache.policy_name(pol#))))
          ) g,
          lbacsys.sa$pol p
    WHERE g.pol#=p.pol#
/

