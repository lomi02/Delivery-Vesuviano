create view ALL_SA_PROGRAMS as
SELECT schema_name, program_name, p.policy_name, program_privileges as
          prog_privileges, NULL as prog_labels
     FROM LBACSYS.sa$pol, LBACSYS.dba_sa_prog_privs p
    WHERE pol_name=p.policy_name
      AND pol# in (select pol# from LBACSYS.sa$admin
                   where usr_name = SYS_CONTEXT('USERENV', 'CURRENT_USER'))
/

