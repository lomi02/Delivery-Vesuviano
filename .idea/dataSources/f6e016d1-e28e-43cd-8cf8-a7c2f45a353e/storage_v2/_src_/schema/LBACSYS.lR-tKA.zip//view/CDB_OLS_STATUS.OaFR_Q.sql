create view CDB_OLS_STATUS as
SELECT k."NAME",k."STATUS",k."DESCRIPTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_OLS_STATUS") k
/

comment on table CDB_OLS_STATUS is ' in all containers'
/

comment on column CDB_OLS_STATUS.CON_ID is 'container id'
/

