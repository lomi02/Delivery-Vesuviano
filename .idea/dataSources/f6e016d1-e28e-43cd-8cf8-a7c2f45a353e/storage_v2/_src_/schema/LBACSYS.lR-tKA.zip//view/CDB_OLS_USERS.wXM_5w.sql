create view CDB_OLS_USERS as
SELECT k."USER_NAME",k."POLICY_NAME",k."USER_PRIVILEGES",k."LABEL1",k."LABEL2",k."LABEL3",k."LABEL4",k."LABEL5",k."LABEL6",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_OLS_USERS") k
/

comment on table CDB_OLS_USERS is ' in all containers'
/

comment on column CDB_OLS_USERS.CON_ID is 'container id'
/

