create view CDB_SA_GROUPS as
SELECT k."POLICY_NAME",k."GROUP_NUM",k."SHORT_NAME",k."LONG_NAME",k."PARENT_NUM",k."PARENT_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_GROUPS") k
/

comment on table CDB_SA_GROUPS is ' in all containers'
/

comment on column CDB_SA_GROUPS.CON_ID is 'container id'
/

