create view CDB_SA_PROG_PRIVS as
SELECT k."SCHEMA_NAME",k."PROGRAM_NAME",k."POLICY_NAME",k."PROGRAM_PRIVILEGES",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_PROG_PRIVS") k
/

comment on table CDB_SA_PROG_PRIVS is ' in all containers'
/

comment on column CDB_SA_PROG_PRIVS.CON_ID is 'container id'
/

