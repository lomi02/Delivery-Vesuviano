create view CDB_SA_USER_LEVELS as
SELECT k."POLICY_NAME",k."USER_NAME",k."MAX_LEVEL",k."MIN_LEVEL",k."DEF_LEVEL",k."ROW_LEVEL",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_USER_LEVELS") k
/

comment on table CDB_SA_USER_LEVELS is ' in all containers'
/

comment on column CDB_SA_USER_LEVELS.CON_ID is 'container id'
/

