create view CDB_SA_USER_PRIVS as
SELECT k."USER_NAME",k."POLICY_NAME",k."USER_PRIVILEGES",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_USER_PRIVS") k
/

comment on table CDB_SA_USER_PRIVS is ' in all containers'
/

comment on column CDB_SA_USER_PRIVS.CON_ID is 'container id'
/

