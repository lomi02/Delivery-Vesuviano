create view DBA_LBAC_SCHEMA_POLICIES as
SELECT pol_name AS policy_name, owner AS schema_name,
  DECODE(bitand(s.flags,1),0,'DISABLED',1,'ENABLED','ERROR') AS status,
  LBACSYS.lbac_cache.option_string(s.options) AS schema_options
  FROM LBACSYS.ols$pol p, LBACSYS.ols$pols s
  WHERE p.pol# = s.pol#
/

