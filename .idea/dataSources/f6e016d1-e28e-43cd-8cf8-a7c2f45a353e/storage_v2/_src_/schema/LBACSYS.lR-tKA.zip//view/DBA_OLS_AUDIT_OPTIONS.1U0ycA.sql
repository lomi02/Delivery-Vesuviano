create view DBA_OLS_AUDIT_OPTIONS (POLICY_NAME, USER_NAME, APY, REM, SET_, PRV) as
SELECT pol_name,
         usr_name,
decode(bitand(success,1), 0, '-', 1, decode(bitand(suc_type,1),0,'S',1,'A'), '-')
 || '/' ||
decode(bitand(failure,1), 0, '-',1,decode(bitand(fail_type,1),0,'S',1,'A'), '-'),
decode(bitand(success,2), 0, '-', 2, decode(bitand(suc_type,2),0,'S',2,'A'), '-')
 || '/' ||
decode(bitand(failure,2), 0, '-',2,decode(bitand(fail_type,2),0,'S',2,'A'), '-'),
decode(bitand(success,4), 0, '-', 4, decode(bitand(suc_type,4),0,'S',4,'A'), '-')
 || '/' ||
decode(bitand(failure,4), 0, '-', 4, decode(bitand(fail_type,4),0,'S',4,'A'), '-'),
decode(option_priv#, 0, '-', decode(success_priv, 0, '-',
                                                decode(suc_priv_type,0,'S','A')))
 || '/' ||
decode(option_priv#, 0, '-', decode(failure_priv, 0, '-',
                                               decode(fail_priv_type,0,'S','A')))
  FROM LBACSYS.ols$pol p, LBACSYS.ols$audit a
  WHERE p.pol# = a.pol#
/

