create view DBA_OLS_USERS as
SELECT usr_name AS user_name,
         pol_name AS policy_name,
         LBACSYS.privs_to_char_n(pf.privs) AS user_privileges,
         lbacsys.lbac$sa_labels.from_label(pf.max_read) AS LABEL1,
         lbacsys.lbac$sa_labels.from_label(pf.max_write) AS LABEL2,
         lbacsys.lbac$sa_labels.from_label(pf.min_write) AS LABEL3,
         lbacsys.lbac$sa_labels.from_label(pf.def_read) AS LABEL4,
         lbacsys.lbac$sa_labels.from_label(pf.def_write) AS LABEL5,
         lbacsys.lbac$sa_labels.from_label(pf.def_row) AS LABEL6
  FROM LBACSYS.ols$pol p, LBACSYS.ols$user u, LBACSYS.ols$profile pf
  WHERE p.pol# = u.pol# AND p.pol# = pf.pol#
    AND u.pol# = pf.pol# AND u.profid = pf.profid
/

