create view DBA_SA_POLICIES as
SELECT policy_name, column_name, status, policy_options, policy_subscribed
   FROM LBACSYS.dba_lbac_policies
   WHERE package = 'LBAC$SA'
/

