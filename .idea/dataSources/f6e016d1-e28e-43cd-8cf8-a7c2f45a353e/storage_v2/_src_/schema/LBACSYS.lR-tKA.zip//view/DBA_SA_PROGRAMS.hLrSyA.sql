create view DBA_SA_PROGRAMS as
SELECT owner as schema_name, pgm_name AS program_name,
         pol_name AS policy_name,
         LBACSYS.privs_to_char_n(privs) AS prog_privileges,
         '             ' as prog_labels
  FROM LBACSYS.ols$pol p, LBACSYS.ols$prog g
  WHERE p.pol# = g.pol#
/

