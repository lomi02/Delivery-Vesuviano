create TYPE RtreeJoin_Imp_t wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
635 1f6
dIBs4WYeDxv3uxemWtSCdXe6CvUwgzu3JCAVfC+V2sFeaHVaTQnMxNzUvOeE4IC/weG3SUDL
c4wYu2R7NeUWnqg3yfJ27cGwmJq3TNZnB7tzP4E6M/PN+Op6qZ7CoDn1yuZJf3zTFjmdVGun
VnKmPFMdCRPkvnVjlm9sK4SIbm8epDCMO03pAilbof+jYY/Wpr2o4jQyszwuiSsjQ6Hzqb92
vdnSl0HJuEyRPbZUsfwcBRQ8iGij6pJSg0KdM0V3eN5ZoR7m7d3MNfaV9t4fyMNkGNIJs8/b
6UBswNaSwzk5DJTFocTqPefQIVC0L6sKjY8AYN5yTvPclVJ2RtN9kaIpS9Qz7VtB0+mWx9Tl
fkz4zvuAP2rryUHPBGMDCi6Yyd8iG/32JVJ/Pg7ieoYg3QO4wSuTrq5FI0tGlfCUWINK/W1S
ukkbPTgjtiMMfFa+R+RLSKYIDFT+cOvuz3EztagQJNek26rgstZulJYoJPVaK48=
 alter type RtreeJoin_Imp_t drop
 STATIC FUNCTION ODCITableStart(sctx OUT RtreeJoin_Imp_t,
                                 cur SYS_REFCURSOR,
                                 ia1 IN SYS.ODCIIndexInfo,
                                 ia2 IN SYS.ODCIIndexInfo,
                                 oper IN number,
                                 masktype IN varchar2,
                                 dst_spec IN varchar2 default null,
                                 ref_predicate in varchar2 default null,
                                 tab2_predicate in varchar2 default null)
    RETURN NUMBER
 alter type RtreeJoin_Imp_t drop
 STATIC FUNCTION StartStub(sctx OUT RtreeJoin_Imp_t,
                            cur SYS_REFCURSOR,
                            ia1 IN SYS.ODCIIndexInfo,
                            ia2 IN SYS.ODCIIndexInfo,
                            oper IN number,
                            masktype IN varchar2,
                            dst_spec IN varchar2 ,
                            ref_predicate in varchar2 ,
                            tab2_predicate in varchar2 )
    RETURN NUMBER
 alter type RtreeJoin_Imp_t add
 STATIC FUNCTION ODCITableStart(sctx OUT RtreeJoin_Imp_t,
                                 cur SYS_REFCURSOR,
                                 ia1 IN SYS.ODCIIndexInfo,
                                 ia2 IN SYS.ODCIIndexInfo,
                                 oper IN number,
                                 masktype IN varchar2,
                                 dst_spec IN varchar2 default null,
                                 self_join IN number default null,
                                 ref_predicate in varchar2 default null,
                                 tab2_predicate in varchar2 default null)
    RETURN NUMBER
 alter type RtreeJoin_Imp_t add
 STATIC FUNCTION StartStub(sctx OUT RtreeJoin_Imp_t,
                            cur SYS_REFCURSOR,
                            ia1 IN SYS.ODCIIndexInfo,
                            ia2 IN SYS.ODCIIndexInfo,
                            oper IN number,
                            masktype IN varchar2,
                            dst_spec IN varchar2 ,
                            self_join IN number,
                            ref_predicate in varchar2 ,
                            tab2_predicate in varchar2 )
    RETURN NUMBER
/

