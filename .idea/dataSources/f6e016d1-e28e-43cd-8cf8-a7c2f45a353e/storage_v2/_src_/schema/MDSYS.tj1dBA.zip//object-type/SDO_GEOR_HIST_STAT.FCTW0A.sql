create TYPE       sdo_geor_hist_stat AS OBJECT(
    m_id           NUMBER,
    m_value        NUMBER
  )
/

