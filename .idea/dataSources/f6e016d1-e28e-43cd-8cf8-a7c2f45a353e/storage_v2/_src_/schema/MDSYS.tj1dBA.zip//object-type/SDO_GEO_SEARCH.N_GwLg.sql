create type       sdo_geo_search as object (
  name varchar2(200),
  Key  varchar2(2000),
  lang_code varchar2(3),
  center_lang number,
  center_lat number,
  rank  number);
/

