create TYPE BODY       SDO_INTERACT_POINT_FEAT AS
  MAP MEMBER FUNCTION get_id RETURN VARCHAR2 IS
  BEGIN
    return feature_layer_id || ''-'' || feature_id || ''-'' || node_id;
  END;
END;
/

