create type sem_goal_node wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
6c a6
y499pqobWXj5qdzTOKgS6/O05v0wg5n0dLhcFtzX8K5yrkf0ctmuoVzngcdSsgnnn4Hw/k6/
UlxQjwlpaefn58AyzKnhyI7juymKBAblHfHLx5/1CCibTjKBmfvAdtZuAHbWXyF0siG+IZTk
5ISOaHpzdhAEpupN/SY=
/

