create TYPE sem_indextype_im authid current_user AS OBJECT
    (
      ---------- Variables --------------------
      curnum                NUMBER, -- cursor number
      dist_cur_num          NUMBER, -- ancillary cursor
      path_cur_num          NUMBER, -- ancillary cursor
      curr_rules_index      VARCHAR2(128), -- current rules index name
      models_in             MDSYS.RDF_Models,
      rulebases_in          MDSYS.RDF_Rulebases,

      bt_handle         MDSYS.SDO_BT_HANDLE, -- pointer to btree for sem_distance anc op
      using_bt          INTEGER, -- set to 1 if we are using temp bt for sem_distance
      keysz                     INTEGER, -- btree keysize in bytes
      datasz            INTEGER, -- btree datasize in bytes

      topk_opt          INTEGER, -- set to 1 if we are optimizing for top-k query
                                       -- else set to 0
      last_cutoff               INTEGER, -- last cutoff during evaluation of top-k query
      rows_covered              NUMBER,  -- number of rows covered so far according to stats
      direction         INTEGER, -- direction of top-k query 1 = asc, 0 = desc
      base_query                VARCHAR2(4000), -- base query for top-k optimization
      pred_id           INTEGER, -- predicate id for this query
      stats_table               VARCHAR2(270), -- name of stats table for index stats

      distances         VARCHAR2(32000), -- cache for passing distances to anc op
      invalid_cache             INTEGER, -- set to 1 if cache is invalid, 0 otherwise

      ---------- Functions --------------------
      STATIC FUNCTION ODCIGetInterfaces (ifclist OUT SYS.ODCIObjectList) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexCreate (ia    SYS.ODCIindexinfo,
                                       parms VARCHAR2,
                                       env   SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexDrop (ia  SYS.ODCIindexinfo,
                                     env SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexTruncate (ia  SYS.ODCIIndexInfo,
                                         env SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexAlter (ia           SYS.ODCIIndexInfo,
                                      parms IN OUT VARCHAR2,
                                      alter_option NUMBER,
                                      env          SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexInsert (ia     SYS.ODCIindexinfo,
                                       rid    varchar2,
                                       newval varchar2,
                                       env    SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexDelete (ia     SYS.ODCIindexinfo,
                                       rid    varchar2,
                                       oldval varchar2,
                                       env    SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexUpdate (ia     SYS.ODCIindexinfo,
                                       rid    varchar2,
                                       oldval varchar2,
                                       newval varchar2,
                                       env    SYS.ODCIEnv) RETURN NUMBER,

      -- index ststaus optional parameter only --
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      env          SYS.ODCIEnv) RETURN NUMBER,

      -- upper and lower bound optional parameters only --
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER,

      -- index status and upper and lower bound optional parameters --
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER,
      -- no optional parameters --
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2  character set any_cs,
                                      obj          VARCHAR2  character set any_cs,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      env          SYS.ODCIEnv) RETURN NUMBER,


      MEMBER FUNCTION ODCIIndexFetch (self IN OUT nocopy sem_indextype_im,
                                      nrows    NUMBER,
                                      rids OUT SYS.ODCIridlist,
                                      env      SYS.ODCIEnv) RETURN NUMBER,

      MEMBER FUNCTION ODCIIndexClose (env SYS.ODCIEnv) RETURN NUMBER,

      STATIC FUNCTION ODCIIndexGetMetadata (ia           SYS.ODCIindexinfo,
                                            expversion   VARCHAR2,
                                            newblock OUT PLS_INTEGER,
                                            env          SYS.ODCIEnv) RETURN VARCHAR2

    )
 alter type sem_indextype_im
      add
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2  character set any_cs,
                                      obj          VARCHAR2  character set any_cs,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      env          SYS.ODCIEnv) RETURN NUMBER
 alter type sem_indextype_im
      add
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2  character set any_cs,
                                      obj          VARCHAR2  character set any_cs,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER
 alter type sem_indextype_im
      add
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2  character set any_cs,
                                      obj          VARCHAR2  character set any_cs,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER
 alter type sem_indextype_im
      add
      MEMBER FUNCTION ODCIIndexClose (self IN OUT nocopy sem_indextype_im,
                                      env SYS.ODCIEnv) RETURN NUMBER
 alter type sem_indextype_im
      drop
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      env          SYS.ODCIEnv) RETURN NUMBER
        cascade
 alter type sem_indextype_im
      drop
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER
        cascade
 alter type sem_indextype_im
      drop
      STATIC FUNCTION ODCIIndexStart (sctx IN OUT  sem_indextype_im,
                                      ia           SYS.ODCIindexinfo,
                                      op           SYS.ODCIPredInfo,
                                      qi           SYS.ODCIQueryInfo,
                                      strt         NUMBER,
                                      stop         NUMBER,
                                      pred_expr    VARCHAR2,
                                      obj          VARCHAR2,
                                      models       MDSYS.RDF_Models,
                                      rulebases    MDSYS.RDF_Rulebases,
                                      idxStatus_in VARCHAR2,
                                      dist_lower   INTEGER,
                                      dist_upper   INTEGER,
                                      env          SYS.ODCIEnv) RETURN NUMBER
        cascade
 alter type sem_indextype_im
      drop
      MEMBER FUNCTION ODCIIndexClose (env SYS.ODCIEnv) RETURN NUMBER
/

