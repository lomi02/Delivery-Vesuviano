create type sem_node wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
92 ba
Awdw4ocGNnA6wXfsTqdbmeWfny8wg5n0dLhcFtzX8HLZrqFcuHQrpb+bwDLLzFCPCWmlx/Uy
Ur+yK6n7rp3IMMYOysZapA4aF3UXSxfjCpnxFFpXRzFys7GU4umoR3+FMWp/hVpqtN1nttiW
tCp8dz1yMZRr0G0MXq9yJKKv1+tyswf7pv48yqA=
/

