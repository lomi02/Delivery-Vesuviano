create TYPE sem_predicate wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
1e8 14c
Wp7xvEoOFJzZL1Eh+fjnvpN+p+0wg5DInUjbynQH2sE+ehsJQJi8+6j/pFyphXVakFFeE+5A
t+Vhu2ThOgqgXu03qotOW52f5w+GC87Odpq7IMS780Yduu0OkYWoHamHq2vz6PxE+goOweTP
e5QB/ANNBKGYd79NB/WrFTJtAXQWSsi+ie7eWYziyA7v1S0zRmd9fgWGL95D0bMw75OTHX6k
t2WcyJGuyVVDcqVErdJV8fASlU5IYt4uMHIMYZgtdR7n9mxECyIKZA7XgX1YiW89j1R+j2H0
D6uBz9m1G/5mKXZ6G3Bh5IqW/DbXGLAsDTgQIg==
/

