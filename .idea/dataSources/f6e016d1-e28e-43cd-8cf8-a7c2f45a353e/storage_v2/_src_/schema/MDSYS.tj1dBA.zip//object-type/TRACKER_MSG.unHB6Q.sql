create Type tracker_msg as object (
        object_id   INTEGER,
        region_id   INTEGER,
        operation   VARCHAR2(2))
/

