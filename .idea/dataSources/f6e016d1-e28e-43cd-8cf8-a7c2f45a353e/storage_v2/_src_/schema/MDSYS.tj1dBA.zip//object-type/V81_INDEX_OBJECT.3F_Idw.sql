create type V81_INDEX_OBJECT as OBJECT ( sdo_code RAW(255), sdo_maxcode RAW(255), sdo_status varchar2(1))
/

