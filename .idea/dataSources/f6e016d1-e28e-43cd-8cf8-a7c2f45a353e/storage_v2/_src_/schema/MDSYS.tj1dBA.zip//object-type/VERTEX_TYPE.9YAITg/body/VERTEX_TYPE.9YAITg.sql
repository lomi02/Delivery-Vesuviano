create type body  vertex_type IS
 Constructor
 Function vertex_type(x  In number,
                     y  In number,
                     id In number)
 Return Self As Result IS
 BEGIN
   SELF.X := x;
   SELF.Y := Y;
   SELF.ID := id;
   SELF.Z := NULL;
   SELF.W := NULL;
   SELF.V5 := NULL;
   SELF.V6 := NULL;
   SELF.V7 := NULL;
   SELF.V8 := NULL;
   SELF.V9 := NULL;
   SELF.V10 := NULL;
   SELF.V11 := NULL;
   SELF.V12 := null;
   SELF.V13 := null;
   SELF.V14 := null;
   SELF.V15 := null;
   SELF.V16 := null;
   SELF.V17 := null;
   SELF.V18 := null;
   SELF.V19 := null;
   SELF.V20 := null;
   SELF.V21 := null;
   SELF.V22 := null;
   SELF.V23 := null;
   SELF.V24 := null;
   SELF.V25 := null;
   SELF.V26 := null;
   SELF.V27 := null;
   SELF.V28 := null;
   SELF.V29 := null;
   SELF.V30 := null;
   SELF.V31 := null;
   SELF.V32 := null;
   SELF.V33 := null;
   SELF.V34 := null;
   RETURN;
  END;
 Constructor
 Function vertex_type(x  In number,
                     y  In number,
                     z  In number,
                     w  In number)
 Return Self As Result IS
 BEGIN
   SELF.X := x;
   SELF.Y := Y;
   SELF.Z := z;
   SELF.W := w;
   SELF.ID := NULL;
   SELF.V5 := NULL;
   SELF.V6 := NULL;
   SELF.V7 := NULL;
   SELF.V8 := NULL;
   SELF.V9 := NULL;
   SELF.V10 := NULL;
   SELF.V11 := NULL;
   SELF.V12 := null;
   SELF.V13 := null;
   SELF.V14 := null;
   SELF.V15 := null;
   SELF.V16 := null;
   SELF.V17 := null;
   SELF.V18 := null;
   SELF.V19 := null;
   SELF.V20 := null;
   SELF.V21 := null;
   SELF.V22 := null;
   SELF.V23 := null;
   SELF.V24 := null;
   SELF.V25 := null;
   SELF.V26 := null;
   SELF.V27 := null;
   SELF.V28 := null;
   SELF.V29 := null;
   SELF.V30 := null;
   SELF.V31 := null;
   SELF.V32 := null;
   SELF.V33 := null;
   SELF.V34 := null;
   RETURN;
  END;
 Constructor
 Function vertex_type(x  In number,
                     y  In number,
                     z  In number,
                     w  In number,
                     id In number)
 Return Self As Result IS
 BEGIN
   SELF.X := x;
   SELF.Y := Y;
   SELF.ID := id;
   SELF.Z := z;
   SELF.W := w;
   SELF.V5 := NULL;
   SELF.V6 := NULL;
   SELF.V7 := NULL;
   SELF.V8 := NULL;
   SELF.V9 := NULL;
   SELF.V10 := NULL;
   SELF.V11 := NULL;
   SELF.V12 := null;
   SELF.V13 := null;
   SELF.V14 := null;
   SELF.V15 := null;
   SELF.V16 := null;
   SELF.V17 := null;
   SELF.V18 := null;
   SELF.V19 := null;
   SELF.V20 := null;
   SELF.V21 := null;
   SELF.V22 := null;
   SELF.V23 := null;
   SELF.V24 := null;
   SELF.V25 := null;
   SELF.V26 := null;
   SELF.V27 := null;
   SELF.V28 := null;
   SELF.V29 := null;
   SELF.V30 := null;
   SELF.V31 := null;
   SELF.V32 := null;
   SELF.V33 := null;
   SELF.V34 := null;
   RETURN;
  END;
 Constructor
 Function vertex_type(x  In number,
                     y  In number,
                     z  In number,
                     w  In number,
                     v5 in number,
                     v6 in number,
                     v7 in number,
                     v8 in number,
                     v9 in number,
                     v10 in number,
                     v11 in number,
                     id In number)
 Return Self As Result IS
 BEGIN
   SELF.X   := x;
   SELF.Y   := Y;
   SELF.ID  := id;
   SELF.Z   := z;
   SELF.W   := w;
   SELF.V5  := v5;
   SELF.V6  := v6;
   SELF.V7  := v7;
   SELF.V8  := v8;
   SELF.V9  := v9;
   SELF.V10 := v10;
   SELF.V11 := v11;
   SELF.V12 := null;
   SELF.V13 := null;
   SELF.V14 := null;
   SELF.V15 := null;
   SELF.V16 := null;
   SELF.V17 := null;
   SELF.V18 := null;
   SELF.V19 := null;
   SELF.V20 := null;
   SELF.V21 := null;
   SELF.V22 := null;
   SELF.V23 := null;
   SELF.V24 := null;
   SELF.V25 := null;
   SELF.V26 := null;
   SELF.V27 := null;
   SELF.V28 := null;
   SELF.V29 := null;
   SELF.V30 := null;
   SELF.V31 := null;
   SELF.V32 := null;
   SELF.V33 := null;
   SELF.V34 := null;
   RETURN;
  END;
 END;
/

