create PACKAGE       mdprvt_srid AS

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE sdo_invalidate_srid_metadata(srid IN NUMBER,
                                         srid_type IN VARCHAR2 DEFAULT NULL);
  PRAGMA restrict_references(sdo_invalidate_srid_metadata, wnds, rnps, wnps, trust);

  FUNCTION get_unit(srid IN NUMBER,
                    srid_type IN VARCHAR2 DEFAULT NULL,
                    unit_id OUT NUMBER,
                    unit_factor OUT NUMBER,
                    unit_name OUT VARCHAR2) -- MUST BE VARCHAR2(80)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
  FUNCTION get_unit(srid IN NUMBER,
                    srid_type IN VARCHAR2 DEFAULT NULL,
                    x_unit_id OUT NUMBER,
                    x_unit_factor OUT NUMBER,
                    x_unit_name OUT VARCHAR2, -- MUST BE VARCHAR2(80)
                    y_unit_id OUT NUMBER,
                    y_unit_factor OUT NUMBER,
                    y_unit_name OUT VARCHAR2) -- MUST BE VARCHAR2(80)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
  FUNCTION get_unit(srid IN NUMBER,
                    srid_type IN VARCHAR2 DEFAULT NULL,
                    x_unit_id OUT NUMBER,
                    x_unit_factor OUT NUMBER,
                    x_unit_name OUT VARCHAR2, -- MUST BE VARCHAR2(80)
                    y_unit_id OUT NUMBER,
                    y_unit_factor OUT NUMBER,
                    y_unit_name OUT VARCHAR2, -- MUST BE VARCHAR2(80)
                    z_unit_id OUT NUMBER,
                    z_unit_factor OUT NUMBER,
                    z_unit_name OUT VARCHAR2) -- MUST BE VARCHAR2(80)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION get_tolerance(srid IN NUMBER,
                         srid_type IN VARCHAR2 DEFAULT NULL)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
  PRAGMA restrict_references(get_tolerance, wnds, rnps, wnps, trust);

  FUNCTION is_geodetic(srid IN NUMBER,
                       srid_type IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
  PRAGMA restrict_references(is_geodetic, wnds, rnps, wnps, trust);

  FUNCTION get_dims(srid IN NUMBER)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
  PRAGMA restrict_references(get_dims, wnds, rnps, wnps, trust);

  FUNCTION get_ref_kind(srid IN NUMBER)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
  PRAGMA restrict_references(get_ref_kind, wnds, rnps, wnps, trust);

  FUNCTION det_srid_wkt(srid1 IN NUMBER)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION get_3d_wkt(
    srid IN number)
          RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  PROCEDURE populate_datum_3params(
       datum_id IN NUMBER,
       op_id    IN NUMBER);

  PROCEDURE populate_datum_7params(
       datum_id IN NUMBER,
       op_id    IN NUMBER);

  PROCEDURE create_pref_concatenated_op(
    op_id     IN NUMBER,
    op_name   IN VARCHAR2,
    use_plan  IN TFM_PLAN,
    use_case  IN VARCHAR2);

  PROCEDURE create_concatenated_op(
      op_id    IN NUMBER,
      op_name  IN VARCHAR2,
      use_plan IN TFM_PLAN);

  PROCEDURE add_preference_for_op(
     op_id       IN NUMBER,
     source_crs  IN NUMBER DEFAULT NULL,
     target_crs  IN NUMBER DEFAULT NULL,
     use_case    IN VARCHAR2 DEFAULT NULL);

END mdprvt_srid;
/

