create PACKAGE prvtpc authid current_user AS
END prvtpc;
/

