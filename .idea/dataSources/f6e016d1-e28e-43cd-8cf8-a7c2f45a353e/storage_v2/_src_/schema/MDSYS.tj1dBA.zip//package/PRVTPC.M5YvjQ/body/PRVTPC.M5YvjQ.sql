create PACKAGE BODY prvtpc AS

END prvtpc;
/

