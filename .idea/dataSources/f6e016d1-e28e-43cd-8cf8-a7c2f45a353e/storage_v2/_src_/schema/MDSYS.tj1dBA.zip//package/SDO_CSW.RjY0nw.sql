create PACKAGE       SDO_CSW AUTHID current_user AS

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

--------------------------------------------------------------------------------
-- Description:
-- With all parameters it is aimed to create user tables, indexes and
-- to fill in the CSW 202+ metadata.
-- User can query the MDSYS.SDO_XSD_TABLE to see the available XSDs.
-- owner: database schema name for the user.
-- csw_version: the version of CSW ie, 202+ inclusive.
-- csw_xsd_id: ID of the XSD in MDSYS.SDO_XSD_TABLE.
-- csw_table_name: user's "preferred" table name for user CSW202+ data.
-- srid:   SRID for the user CSW202+ data.
-- generate_index: is index desired to build- if > 0 build all indexes,
--                 otherwise no indexes are built.
--
--
-- With only mandatory parameters (default functionality) where optional parameters are set as:
-- -- SRID parameter is NULL (default)
-- -- GENERATE_INDEX parameter is 0 (default)
-- -- OWNER.CSW_TABLE_NAME table exists
-- User creates tables and all indexes (ie, XQFT, Spatial indexes).
-- The CSW 202+ metadata is filled in here only and in this case it is equivalent to SDO_CSW.REGISTER_CSW procedure.
-- owner: database schema name
-- csw_version: the version of CSW ie, 202+ inclusive.
-- csw_xsd_id: ID of the XSD in MDSYS.SDO_XSD_TABLE.
-- csw_table_name: User CSW202+ table name for the data.
--
-- The csw_xsd_id parameter maps to the xsd_id column in MDSYS.SDO_XSD_TABLE table and also the csw_xsd_id column in MDSYS.CSW_SERVICE_INFO table.
--------------------------------------------------------------------------------

    procedure initialize_csw
    (
        owner          IN VARCHAR2,
        csw_version    IN VARCHAR2,
        csw_xsd_id     IN NUMBER,
        csw_table_name IN VARCHAR2,
        srid           IN NUMBER DEFAULT NULL,
        generate_index IN NUMBER DEFAULT 0
    );


--------------------------------------------------------------------------------
-- Description:
-- Only does the population of ALL_SDO_CSW_SERVICE_INFO view.
-- The SDO_CSW.INITIALIZE_CSW procedure is equivalent to SDO_CSW.REGISTER_CSW procedure when:
-- -- SRID parameter is NULL (default)
-- -- GENERATE_INDEX parameter is 0 (default)
-- -- OWNER.CSW_TABLE_NAME table exists
-- and this procedure can be used in case User creates tables and all indexes
-- (ie, XQFT, Spatial indexes).
-- The CSW 202+ metadata is filled in here only.
-- owner: database schema name
-- csw_version: the version of CSW ie, 202+ inclusive.
-- csw_xsd_id: ID of the XSD in MDSYS.SDO_XSD_TABLE.
-- csw_table_name: User CSW202+ table name for the data.
--------------------------------------------------------------------------------

    procedure register_csw
    (
        owner          IN VARCHAR2,
        csw_version    IN VARCHAR2,
        csw_xsd_id     IN NUMBER,
        csw_table_name IN VARCHAR2
    );


--------------------------------------------------------------------------------
-- Description:
-- Executes as the Invoker and creates XQFT (XML Search-XPath Query Full Text) Index.
--------------------------------------------------------------------------------

    procedure create_xqft_idx
    (
        owner          IN VARCHAR2,
        csw_table_name IN VARCHAR2
    );


--------------------------------------------------------------------------------
-- Description:
-- Create Spatial index named as: CSW User Table Name appended by "IDX".
-- This procedure also extracts SDO_GEOMETRY from XMLType column of CSW User Table
-- and then creates Spatial Index if it does not exist.
--------------------------------------------------------------------------------

    procedure create_spatial_idx
    (
        owner          IN VARCHAR2,
        csw_table_name IN VARCHAR2,
        srid           IN NUMBER
    );


--------------------------------------------------------------------------------
-- Description:
-- Publishes the RecordType.
-- xsd_type could be DCMI, ISO19139 or INSPIRE.
-- This API is not publicly documented yet as of database version 12.2.0.1
-- as it is planned for some future public uses such as this: It is ok for now (12.2.0.1) but
-- for some future reason when the request can not be validated, this API may be needed
-- for GetRecords ResultType "validate" option.
--------------------------------------------------------------------------------

/*
    procedure publish_recordtype
    (
        record_type_name      IN VARCHAR2,
        record_type_namespace IN VARCHAR2,
        xsd_type              IN VARCHAR2

    );
*/


--------------------------------------------------------------------------------
-- Description:
-- Reads the DCMI identifier and the ISO19139 fileIdentifier (or MD_Identifier if fileIdentifier does not exist) element
-- from the Record_Instance_Xml XML column and inserts into Metadata_Id column of CSW user table; and
-- if fileIdentifier does not exist in the Record_Instance_Xml XML column doc or Record_Instance_Xml is NULL,
-- then we use sequence generator for Metadata_Id column.
-- Users will use this procedure while populating their data.
--
-- This procedure assumes USER/ALL_SDO_CSW_SERVICE_INFO view is already populated.
-- The SDO_CSW.REGISTER_CSW procedure only does the population of that view.
-- The SDO_CSW.INITIALIZE_CSW procedure is equivalent to SDO_CSW.REGISTER_CSW procedure when:
-- -- SRID parameter is NULL (default)
-- -- GENERATE_INDEX parameter is 0 (default)
-- -- OWNER.CSW_TABLE_NAME exists
--
-- This signature is for all rows of user table.
--------------------------------------------------------------------------------

procedure generate_metadata_id
(
    owner          IN VARCHAR2,
    csw_table_name IN VARCHAR2
);


/*
--------------------------------------------------------------------------------
-- Description:
-- Reads the fileIdentifier element from the Record_Instance_Xml XML column and
-- inserts into Metadata_Id column of user table and if fileIdentifier does not
-- exist in the Record_Instance_Xml XML column doc or Record_Instance_Xml is NULL,
-- then we use sequence generator for Metadata_Id column. Users will use this
-- procedure while populating their data.
--
-- This signature is for a specific row of user table.
--------------------------------------------------------------------------------

procedure generate_metadata_id
(
    owner          IN VARCHAR2,
    csw_table_name IN VARCHAR2,
    rowId          IN ROWID

);
*/


--------------------------------------------------------------------------------
-- Description:
-- This procedure sync's XML Query Full Text Index.
--------------------------------------------------------------------------------

procedure sync_index
(
    owner VARCHAR2,
    csw_table_name VARCHAR2
);


--------------------------------------------------------------------------------
-- Description:
-- This procedure first extracts the SDO_GEOMETRY object from a CSW Record and
-- then CS Transforms the SDO_GEOMETRY object if its SRID is different than the
-- to_srid parameter. This is called as MDSYS.SDO_CSW as SDO_CSW_INT is not public.
--------------------------------------------------------------------------------

function record_extract
(
    record XMLType,
    to_srid NUMBER,
    csw_xsd_id NUMBER
)
RETURN MDSYS.SDO_GEOMETRY;


--------------------------------------------------------------------------------
-- Description:
-- This function prepares a String if it has any multi_wildcard (by default "%" character)
-- for the PropertyIsLike Operator of GetRecords Request.
-- Algorithm:
-- 1.  Take out all the non-alphabetic(except escape and underscore) and non-wildcard characters, replacing them by spaces.
-- 2.  Any multi-char wildcards surrounded by alphanumerics get replaced by "% ftAND %"
-- 3.  Any other multi-char wildcards get replaced by %
-- 4.  Each remaining word gets replaced with " ftAND "
-- This is called as MDSYS.SDO_CSW as SDO_CSW_INT is not public.
--------------------------------------------------------------------------------
function parse_search
(
   input_string VARCHAR2,
   multi_wildcard VARCHAR2 default '%'
)
RETURN VARCHAR2;

END SDO_CSW;
/

