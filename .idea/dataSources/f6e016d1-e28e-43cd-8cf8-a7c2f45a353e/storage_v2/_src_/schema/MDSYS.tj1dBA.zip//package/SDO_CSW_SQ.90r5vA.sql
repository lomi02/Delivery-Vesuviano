create PACKAGE       SDO_CSW_SQ AUTHID definer AS

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

--------------------------------------------------------------------------------
-- Description:
-- Private function to get next value from MDSYS.MD_identifier_sq$ sequence.
--
--------------------------------------------------------------------------------

function generate_md_identifier_sq
RETURN VARCHAR2;


END SDO_CSW_SQ;
/

