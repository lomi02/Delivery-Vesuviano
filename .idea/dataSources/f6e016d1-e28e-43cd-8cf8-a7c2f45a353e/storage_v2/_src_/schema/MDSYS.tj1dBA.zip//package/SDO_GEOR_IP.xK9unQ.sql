create PACKAGE       SDO_GEOR_IP AUTHID CURRENT_USER AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE stretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    minValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    maxValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE stretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    minValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    maxValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE stretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    minValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    maxValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE stretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    minValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    maxValues           IN        MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE piecewiseStretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    inValues            IN        MDSYS.SDO_NUMBER_ARRAYSET,
    outValues           IN        MDSYS.SDO_NUMBER_ARRAYSET,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE piecewiseStretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    inValues            IN        MDSYS.SDO_NUMBER_ARRAYSET,
    outValues           IN        MDSYS.SDO_NUMBER_ARRAYSET,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE piecewiseStretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    inValues            IN        MDSYS.SDO_NUMBER_ARRAYSET,
    outValues           IN        MDSYS.SDO_NUMBER_ARRAYSET,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE piecewiseStretch(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    inValues            IN        MDSYS.SDO_NUMBER_ARRAYSET,
    outValues           IN        MDSYS.SDO_NUMBER_ARRAYSET,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE equalize(
    inGeoRaster        IN        MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN        VARCHAR2,
    storageParam       IN        VARCHAR2,
    outGeoRaster       IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE equalize(
    inGeoRaster        IN        MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN        MDSYS.SDO_GEOMETRY,
    layerNumbers       IN        VARCHAR2,
    storageParam       IN        VARCHAR2,
    outGeoRaster       IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE equalize(
    inGeoRaster        IN        MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN        VARCHAR2,
    storageParam       IN        VARCHAR2,
    rasterBlob         IN OUT    BLOB,
    outArea            OUT       MDSYS.SDO_GEOMETRY,
    outWindow          OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE equalize(
    inGeoRaster        IN        MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN        MDSYS.SDO_GEOMETRY,
    layerNumbers       IN        VARCHAR2,
    storageParam       IN        VARCHAR2,
    rasterBlob         IN OUT    BLOB,
    outArea            OUT       MDSYS.SDO_GEOMETRY,
    outWindow          OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE normalize(
    inGeoRaster        IN    MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN    MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN    VARCHAR2,
    means              IN    MDSYS.SDO_NUMBER_ARRAY,
    standardDeviations IN    MDSYS.SDO_NUMBER_ARRAY,
    storageParam       IN    VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE normalize(
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN     MDSYS.SDO_GEOMETRY,
    layerNumbers       IN     VARCHAR2,
    means              IN     MDSYS.SDO_NUMBER_ARRAY,
    standardDeviations IN     MDSYS.SDO_NUMBER_ARRAY,
    storageParam       IN     VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE normalize(
    inGeoRaster        IN    MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN    MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN    VARCHAR2,
    means              IN    MDSYS.SDO_NUMBER_ARRAY,
    standardDeviations IN    MDSYS.SDO_NUMBER_ARRAY,
    storageParam       IN    VARCHAR2,
    rasterBlob         IN OUT    BLOB,
    outArea            OUT       MDSYS.SDO_GEOMETRY,
    outWindow          OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE normalize(
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN     MDSYS.SDO_GEOMETRY,
    layerNumbers       IN     VARCHAR2,
    means              IN     MDSYS.SDO_NUMBER_ARRAY,
    standardDeviations IN     MDSYS.SDO_NUMBER_ARRAY,
    storageParam       IN     VARCHAR2,
    rasterBlob         IN OUT    BLOB,
    outArea            OUT       MDSYS.SDO_GEOMETRY,
    outWindow          OUT       MDSYS.SDO_NUMBER_ARRAY
  );

  PROCEDURE normalize(
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN     MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN     VARCHAR2,
    refGeoRaster       IN     MDSYS.SDO_GEORASTER,
    storageParam       IN     VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE normalize(
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN        NUMBER,
    cropArea           IN     MDSYS.SDO_GEOMETRY,
    layerNumbers       IN     VARCHAR2,
    refGeoRaster       IN     MDSYS.SDO_GEORASTER,
    storageParam       IN     VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE histogramMatch (
    inGeoRaster        IN      MDSYS.SDO_GEORASTER,
    pyramidLevel       IN      NUMBER,
    cropArea           IN      MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN      VARCHAR2,
    refGeoRaster       IN      MDSYS.SDO_GEORASTER,
    storageParam       IN      VARCHAR2,
    outGeoRaster       IN OUT  MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE histogramMatch (
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN     NUMBER,
    cropArea           IN     MDSYS.SDO_GEOMETRY,
    layerNumbers       IN     VARCHAR2,
    refGeoRaster       IN     MDSYS.SDO_GEORASTER,
    storageParam       IN     VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE histogramMatch (
    inGeoRaster        IN      MDSYS.SDO_GEORASTER,
    pyramidLevel       IN      NUMBER,
    cropArea           IN      MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers        IN      VARCHAR2,
    refHistograms      IN      MDSYS.SDO_GEOR_HISTOGRAM_ARRAY,
    storageParam       IN      VARCHAR2,
    outGeoRaster       IN OUT  MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE histogramMatch (
    inGeoRaster        IN     MDSYS.SDO_GEORASTER,
    pyramidLevel       IN     NUMBER,
    cropArea           IN     MDSYS.SDO_GEOMETRY,
    layerNumbers       IN     VARCHAR2,
    refHistograms      IN     MDSYS.SDO_GEOR_HISTOGRAM_ARRAY,
    storageParam       IN     VARCHAR2,
    outGeoRaster       IN OUT MDSYS.SDO_GEORASTER,
    parallelParam      IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE dodge(
    inGeoRaster         IN          MDSYS.SDO_GEORASTER,
    gridsize            IN          MDSYS.SDO_NUMBER_ARRAY,
    samplingFactor      IN          VARCHAR2 DEFAULT NULL,
    means               IN          MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    standardDeviations  IN          MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL,
    storageParam        IN          VARCHAR2 DEFAULT NULL,
    outGeoRaster        IN OUT      MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
   );

  PROCEDURE dodge(
    inGeoRaster         IN          MDSYS.SDO_GEORASTER,
    gridsize            IN          MDSYS.SDO_NUMBER_ARRAY,
    samplingFactor      IN          VARCHAR2 DEFAULT NULL,
    refGeoRaster        IN          MDSYS.SDO_GEORASTER,
    storageParam        IN          VARCHAR2 DEFAULT NULL,
    outGeoRaster        IN OUT      MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
   );

  PROCEDURE filter(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    filterParam         IN        VARCHAR2,
    filterKernel        IN        MDSYS.SDO_NUMBER_ARRAY,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
    );

  PROCEDURE filter(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    filterParam         IN        VARCHAR2,
    filterKernel        IN        MDSYS.SDO_NUMBER_ARRAY,
    storageParam        IN        VARCHAR2,
    outGeoRaster        IN OUT    MDSYS.SDO_GEORASTER,
    parallelParam       IN VARCHAR2 DEFAULT NULL
    );

  PROCEDURE filter(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_NUMBER_ARRAY,
    bandNumbers         IN        VARCHAR2,
    filterParam         IN        VARCHAR2,
    filterKernel        IN        MDSYS.SDO_NUMBER_ARRAY,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
    );

  PROCEDURE filter(
    inGeoRaster         IN        MDSYS.SDO_GEORASTER,
    pyramidLevel        IN        NUMBER,
    cropArea            IN        MDSYS.SDO_GEOMETRY,
    layerNumbers        IN        VARCHAR2,
    filterParam         IN        VARCHAR2,
    filterKernel        IN        MDSYS.SDO_NUMBER_ARRAY,
    storageParam        IN        VARCHAR2,
    rasterBlob          IN OUT    BLOB,
    outArea             OUT       MDSYS.SDO_GEOMETRY,
    outWindow           OUT       MDSYS.SDO_NUMBER_ARRAY
    );

END SDO_GEOR_IP;
/

