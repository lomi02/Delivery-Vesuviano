create PACKAGE       sdo_nfe AUTHID current_user AS

  -------------------
  -- Constants
  -------------------
  -- Model Edition Modes
  FROM_SCRATCH        CONSTANT INTEGER := 1;
  OVER_EXIST_NETWORK  CONSTANT INTEGER := 2;

  -- Model tables' types
  FT_CLASS           CONSTANT VARCHAR2(35) := 'FT_CLASS';            -- Feature Class
  FT_CLASS_REL       CONSTANT VARCHAR2(35) := 'FT_CLASS_REL';        -- Feature Class Relation with features
  FT_CLASS_ATTR_CON  CONSTANT VARCHAR2(35) := 'FT_CLASS_ATTR_CSTR';  -- Feature Class Attribute Constraints
  FT_USR_DATA        CONSTANT VARCHAR2(35) := 'FT_USR_DATA';         -- Feature User Data
  FT_USR_DATA_CAT    CONSTANT VARCHAR2(35) := 'FT_USR_DATA_CATLG';   -- Feature User Data Catalogs
  FT_USR_DATA_CVAL   CONSTANT VARCHAR2(35) := 'FT_USR_DATA_CVAL';    -- Feature user Data Catalogs' values
  FT_CLASS_DEF_PTS   CONSTANT VARCHAR2(35) := 'FT_CLASS_DEF_CON_PT'; -- Feature Class Default connected Point in a Line Feature
  LINE_LINE_RULES    CONSTANT VARCHAR2(35) := 'LINE_LINE_RULE';      -- Line Line Rules
  LINE_POINT_RULES   CONSTANT VARCHAR2(35) := 'LINE_POINT_RULE';     -- Line Point Rules
  RULE_INSTANCE      CONSTANT VARCHAR2(35) := 'RULE_INSTANCE';       -- Rule instances
  FT_RULE_REL        CONSTANT VARCHAR2(35) := 'FT_RULE_REL';         -- Feature Rule relations with rules
  RULE_DEC_HANDLER   CONSTANT VARCHAR2(35) := 'RULE_DEC_HANDLER';    -- Rule Decision Handlers
  POINT_CARD_RULES   CONSTANT VARCHAR2(35) := 'POINT_CARD_RULE';     -- Point Cardinality Rules
  POINT_ATTR_DEF     CONSTANT VARCHAR2(35) := 'POINT_ATTR_DEF';      -- Point Default Attributes


  ---------------------------
  -- Constants for Rules
  ---------------------------
  -- Line Intersection Locations
  INTERSECT_LOC_FIRST_PT  CONSTANT NUMBER := 1;
  INTERSECT_LOC_LAST_PT   CONSTANT NUMBER := 2;
  INTERSECT_LOC_MID_PT    CONSTANT NUMBER := 3;

  -- Connectivity Rules Types
  RULE_TYPE_LINE_LINE     CONSTANT VARCHAR2(1) := 'L';
  RULE_TYPE_LINE_POINT    CONSTANT VARCHAR2(1) := 'P';

  -- Interaction types among features
  INTERACT_TYPE_CROSS     CONSTANT INTEGER := 1;  --Crosses
  INTERACT_TYPE_TEP       CONSTANT INTEGER := 2;  --Touches End Points
  INTERACT_TYPE_TMP       CONSTANT INTEGER := 3;  --Touches Middle Points
  INTERACT_TYPE_TAP       CONSTANT INTEGER := 4;  --Touches Any Point
  INTERACT_TYPE_ANY       CONSTANT INTEGER := 5;  --Any Interact

  -- Feature Classes types
  FT_CLASS_POINT              CONSTANT INTEGER := 1;
  FT_CLASS_SIMPLE_LINE        CONSTANT INTEGER := 2;
  FT_CLASS_COMPLEX_LINE       CONSTANT INTEGER := 3;
  FT_CLASS_PATH               CONSTANT INTEGER := 4;


  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -------------------
  -- Subprograms
  -------------------

  -------------------------------------------------------------------------------
  -- Creates the NFE Model's tables and its metadata.
  -- Parameters:
  --    model_name    - Name to be given to the model
  --    edition_mode  - FROM_SCRATCH or OVER_EXIST_NETWORK.
  --    versionable   - 'Y' if the model will be versionable, 'N' otherwise.
  -- Returns the new model's id.
  -------------------------------------------------------------------------------
  FUNCTION create_model_structure( model_name IN VARCHAR2,
                             edition_mode IN NUMBER,
                             versionable IN VARCHAR2 )
  RETURN NUMBER;


  -------------------------------------------------------------------
  -- Drops all the model's tables and delete its metadata records.
  -------------------------------------------------------------------
  PROCEDURE delete_model_structure(model_id IN NUMBER);


  -----------------------------------------------------------------------------
  -- Gets the name of a specific table from a NFE model, for example the
  -- Feature-Classes table identified with the type FT_CLASS.
  -- Parameters:
  --    model_id - model's identifier
  --    model_table_type - Type of the table whose name is going to be returned.
  -----------------------------------------------------------------------------
  FUNCTION get_model_table_name( model_id IN NUMBER,
                                 model_table_type IN VARCHAR2 )
  RETURN VARCHAR2;


  --------------------------------------------------------------
  -- Creates and register a sequence into a model.
  -- All the sequences for the base tables are created by the
  -- create_model_structure function, but the user may need to
  -- create other sequences (e.g. for features).
  -- Parameters:
  --    model_id      - model's identifier
  --    owner_table   - sequence's related table
  --    sequence_name - sequence name to be created
  --------------------------------------------------------------
  PROCEDURE create_model_sequence( model_id IN NUMBER,
                                   owner_table IN VARCHAR2,
                                   sequence_name IN VARCHAR2);


  -----------------------------------------------------------
  -- Drops a sequence (previously added to a model)
  -- and its registry from a model.
  -- Parameters:
  --    model_id - model's identifier
  --    seq_name - sequence name to be deleted
  -----------------------------------------------------------
  PROCEDURE drop_model_sequence( model_id IN NUMBER,
                                   seq_name IN VARCHAR2 );


  --------------------------------------------------------------------------------------
  -- Gets the sequence's name of the table specified previosly registered in the model
  -- Parameters:
  --    model_id - Model's identifier
  --    tab_name - Table's name.
  --------------------------------------------------------------------------------------
  FUNCTION get_model_sequence_name( model_id IN NUMBER, tab_name IN VARCHAR2 )
  RETURN VARCHAR2;


  ---------------------------------------------------------------------------
  -- Creates a spatial network and associates it to the specified NFE Model.
  -- It also creates sequences for its nodes, links and paths, and registers
  -- them in the model metadata.
  ---------------------------------------------------------------------------
  PROCEDURE create_model_underlying_net( model_id IN NUMBER,
                                network_name          IN VARCHAR2,
                                num_hierarchy_levels  IN NUMBER DEFAULT 1,
                                is_directed           IN VARCHAR2 DEFAULT 'TRUE',
                                node_with_costs       IN VARCHAR2 DEFAULT 'TRUE' );


  ---------------------------------------------------------------------
  -- Drops the network and removes its relation with any NFE Model.
  ---------------------------------------------------------------------
  PROCEDURE drop_model_underlying_network(network_name IN VARCHAR2);


  ---------------------------------------------------------------------------
  -- Gets the name of the network that is associated to the specified model
  ---------------------------------------------------------------------------
  FUNCTION get_model_underlying_network( model_id IN NUMBER ) RETURN VARCHAR2 PARALLEL_ENABLE;
  pragma restrict_references(get_model_underlying_network, WNDS, WNPS, RNPS);


  -------------------------------------------------------------------
  -- Relates a Network with a NFE Model. It is allowed to
  -- relate Networks in this way just for Models from the
  -- OVER_EXIST_NETWORK.
  -------------------------------------------------------------------
  PROCEDURE set_model_underlying_network( model_id IN NUMBER,
                                     network_name IN VARCHAR2 );


  -------------------------------------------------------------
  -- Creates a new workspace and relates it to a NFE Model.
  -------------------------------------------------------------
        PROCEDURE create_model_workspace( model_id  IN NUMBER,
                                    parent_workspace_name IN VARCHAR2,
                                    workspace_name IN VARCHAR2,
                                    is_mbr IN VARCHAR2,
                                    is_locked IN VARCHAR2,
                                    lower_x IN NUMBER,
                                    lower_y     IN NUMBER,
                                    upper_x IN NUMBER,
                                    upper_y IN NUMBER );

  ----------------------------------------------------------------------------
  -- Drops a workspace along with its record from the specified NFE Model.
  ----------------------------------------------------------------------------
  PROCEDURE delete_model_workspace( model_id IN NUMBER, workspace_name IN VARCHAR2 );


  ---------------------------------------------------------------------------------------
  -- Drops all the workspaces related to a NFE Model along with their model relation.
  ---------------------------------------------------------------------------------------
  PROCEDURE delete_all_workspaces( model_id IN NUMBER );

  -----------------------------------------------------------------------------------
  -- Drops (deletes) all the feature layers related with the model specified,
  -- including its features, feature classes, attributes, styles, connectivity and
  -- cardinality rules, and records of them in the NFE Model.
  -- If the model is in From-Sratch mode, underlying network elements related to
  -- the feature layers are also deleted.
  -----------------------------------------------------------------------------------
  PROCEDURE delete_all_ft_layers( model_id IN NUMBER );

  --------------------------------------------------------------
  -- Copies the network elements from an existing network
  -- to a NFE model, translating every link in features from
  -- the line-feature-class indicated, and the nodes in the
  -- point-feature-class.
  --------------------------------------------------------------
  PROCEDURE import_network( model_id          IN NUMBER,
                            network_from      IN VARCHAR2,
                            line_ft_layer_id  IN NUMBER,
                            line_ft_class_id  IN NUMBER,
                            point_ft_layer_id IN NUMBER,
                            point_ft_class_id IN NUMBER);

  --------------------------------------------------------------
  -- Retrieves the next value for the specified sequence and
  -- increments the count sequence <seq_value_increment> numbers.
  --------------------------------------------------------------
  FUNCTION get_next_sequence_value( sequence_name IN VARCHAR2,
                                    seq_value_increment IN NUMBER ) RETURN NUMBER;


  -- Checks if a table is version-enabled and if so, performs the disable versioning
  PROCEDURE disable_versioning_table( table_name IN VARCHAR2 );



  -------------------------------
  -- SUBPROGRAMS FOR RULES
  -------------------------------

  --------------------------------------------------------------------------------------------------------------
  -- Calculates and returns a set of features interaction groups which meet the specified Connectivity Rule
  -- Parameters:
  --    model_id  NFE Model identifier
  --    rule_type Connectivity Rule type. Possible values: RULE_TYPE_LINE_LINE | RULE_TYPE_LINE_POINT
  --    rule_id   Rule identifier. From LINE_LINE_RULE or LINE_POINT_RULE table.
  --------------------------------------------------------------------------------------------------------------
  FUNCTION get_interaction_groups( model_id IN NUMBER, rule_type IN VARCHAR2, rule_id IN NUMBER ) RETURN MDSYS.SDO_INTERACTION_ARRAY;


  ---------------------------------------------------------------------------------------------------------------
  -- Given a set of line features that match a Connectivity Line-Line Rule, this procedure clasifies which lines
  -- lie on the left hand side of the rule and which ones on the right hand side.
  -- Parameters:
  --    model_id      NFE Model identifier
  --    ll_rule_id    Connectivity Line-Line Rule identifier
  --    lines         Set of line features that meet the rule
  --    lhs_indexes   Associative array where the indexes of the lines lying on the LEFT hand side of the rule will be stored (in the form (index, index)).
  --    rhs_indexes   Associative array where the indexes of the lines lying on the RIGHT hand side of the rule will be stored.
  ---------------------------------------------------------------------------------------------------------------
  PROCEDURE classify_lines_by_side( model_id IN NUMBER,
                                    ll_rule_id IN NUMBER,
                                    lines IN MDSYS.SDO_INTERACT_LINE_FEAT_ARRAY,
                                    lhs_indexes OUT dbms_sql.NUMBER_TABLE,
                                    rhs_indexes OUT dbms_sql.NUMBER_TABLE );


  -------------------------------------------------------------------------------------------------------------------
  -- Given an arbitraty set of line features, this function calculates the group of them that match a Connectivity
  -- Line-Point Rule.
  -- Parameters:
  --    model_id    NFE Model identifier
  --    lp_rule_id  Connectivity Line-Point Rule identifier
  --    lines       Array of line features where the search will take place.
  -- Return
  --    It returns an Associative array (dbms_sql.NUMBER_TABLE) containing the indexes of the lines in the search
  --    array that meet the rule.
  -------------------------------------------------------------------------------------------------------------------
  FUNCTION get_lines_match_lp_rule( model_id IN NUMBER,
                                    lp_rule_id IN NUMBER,
                                    lines IN MDSYS.SDO_INTERACT_LINE_FEAT_ARRAY )
  RETURN dbms_sql.NUMBER_TABLE;


  --------------------------------------------------------------------------------------------------------------
  -- Given an arbitrary set of point features, calculates the group of them that match the point definition of
  -- a Connectivity Line-Point Rule.
  -- Parameters:
  --    model_id    NFE Model identifier
  --    lp_rule_id  Connectivity Line-Point Rule identifier
  --    points      Array of point features where the search will take place.
  -- Return
  --    It returns an Associative array (dbms_sql.NUMBER_TABLE) containing the indexes of the points in the search
  --    array that meet the rule.
  --------------------------------------------------------------------------------------------------------------
  FUNCTION get_points_match_lp_rule( model_id IN NUMBER,
                                        lp_rule_id IN NUMBER,
                                        points IN MDSYS.SDO_INTERACT_POINT_FEAT_ARRAY )
  RETURN dbms_sql.NUMBER_TABLE;

  -------------------------------------------------------------------------------------------------
  -- Given a group of interacting features (lines and points), this function calculates subgroups
  -- of them which can be connected according to the given Connectivity Line-Point Rule.
  -- Parameters:
  --    model_id        NFE Model identifier
  --    lp_rule_id      Connectivity Line-Point rule identifier
  --    interaction_grp Group of interacting features.
  --    rule_lines_indexes Among the line features in the interacting group, indexes of the lines
  --                    that specifically match the Line-Point rule. These lines will be considered
  --                    in the connectable groups comformation.
  --    rule_points_indexes Among the point features in the interacting group, indexes of the points
  --                    that specifically match the point feature specification in the Line-Point rule.
  --                    These points are the ones to be considered in the connectable groups comformation.
  -- Return
  --    Set of connectable feature groups.
  -------------------------------------------------------------------------------------------------
  FUNCTION get_lp_conn_intersections( model_id IN NUMBER,
                                      lp_rule_id IN NUMBER,
                                      interaction_grp IN OUT MDSYS.SDO_INTERACTION,
                                      rule_lines_indexes IN dbms_sql.NUMBER_TABLE,
                                      rule_points_indexes IN dbms_sql.NUMBER_TABLE )
  RETURN MDSYS.SDO_INTERACTION_ARRAY;

  ----------------------------------------------------------------------------------------------------
  -- Given a group of interacting features (lines and points), this function calculates subgroups
  -- of these features which can be connected according to the Connectivity Line-Line Rule specified.
  -- Parameters:
  --    model_id          NFE Model identifier
  --    ll_rule_id        Connectivity Line-Line Rule identifier
  --    interaction_grp   Group of interacting features
  --    rule_lhs_lines_indexes Among the line features in the interacting group, indexes of the lines
  --                      that specifically match the left hand side of the Line-Line rule.
  --    rule_rhs_lines_indexes Among the line features in the interacting group, indexes of the lines
  --                      that specifically match the right hand side of the Line-Line rule.
  --    rule_points_indexes Among the point features in the interacting group, indexes of the points
  --                    that specifically match the point feature specification in the Line-Line rule.
  --                    These points are the ones to be considered in the connectable groups conformation.
  -- Return
  --    Set of connectable feature groups.
  ----------------------------------------------------------------------------------------------------
  FUNCTION get_ll_conn_intersections( model_id IN NUMBER,
                                      ll_rule_id IN NUMBER,
                                      interaction_grp IN OUT MDSYS.SDO_INTERACTION,
                                      rule_lhs_lines_indexes IN dbms_sql.NUMBER_TABLE,
                                      rule_rhs_lines_indexes IN dbms_sql.NUMBER_TABLE,
                                      rule_points_indexes IN dbms_sql.NUMBER_TABLE )
  RETURN MDSYS.SDO_INTERACTION_ARRAY;


  ------------------------------------------------------------------------------------------
  -- Given a group of interacting features (lines and/or points), calculates the geometry
  -- of the point that must connect them.
  ------------------------------------------------------------------------------------------
  FUNCTION get_connection_point_geom( conn_intersection IN MDSYS.SDO_INTERACTION )
  RETURN MDSYS.SDO_GEOMETRY PARALLEL_ENABLE;
  pragma restrict_references(get_connection_point_geom, WNDS, WNPS, RNDS, RNPS);


  ---------------------------------------------------------------------------
  -- Applies a Connectivity Rules over all the features contained in a
  -- specified NFE Model.
  -- Parameters:
  --    model_id    NFE Model identifier
  --    rule_type   Type of the Connectivity Rule to apply. Possibe values:
  --                RULE_TYPE_LINE_LINE|RULE_TYPE_LINE_POINT
  --    rule_id     Connectivity Rule identifier
  ---------------------------------------------------------------------------
  PROCEDURE apply_rule( model_id IN NUMBER, rule_type IN VARCHAR2, rule_id IN NUMBER );


  ------------------------------------------------------------------------------
  -- Validates if all the tokens contained in sql_names are valid sql names.
  -- Returns and String Array (SDO_STRING_ARRAY) containing 'TRUE' or 'FALSE'
  -- for each token in the input array (sql_names).
  -- Parameters:
  --    sql_names   String Array containing all the names to be checked.
  ------------------------------------------------------------------------------
  FUNCTION validate_sql_names( sql_names IN MDSYS.SDO_STRING2_ARRAY ) RETURN MDSYS.SDO_STRING_ARRAY;


END sdo_nfe;
/

