create PACKAGE sdo_rdf_rel2rdf_internal authid current_user AS

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

PROCEDURE copy_network_info_to_pkg_vars;

FUNCTION replace_rdf_prefix (
  string                       VARCHAR2
) RETURN                       VARCHAR2 deterministic;

-- replace reserved chars in string with escape sequence (%two-digit-hexcode)
FUNCTION url_escape (str varchar2) return varchar2 deterministic;

-- generate uri prefix
FUNCTION gen_uriprefix (
  top             varchar2
, owner           varchar2
, obj_name        varchar2 -- obj could be a table
) RETURN varchar2 deterministic;
/*
PROCEDURE store_stats (
  stats_table_name          VARCHAR2
, staging_table_name        VARCHAR2
, owner                     VARCHAR2   default NULL --quoted owner unsupported
);
*/
PROCEDURE rel2rdf (
  tableName                 VARCHAR2
, user_name                 VARCHAR2 -- default table-owner if 'owner' param is NULL
, staging_table_owner       VARCHAR2
, staging_table_name        VARCHAR2
, schema_table_owner        VARCHAR2
, schema_table_name         VARCHAR2
, prefix                    VARCHAR2
, owner                     VARCHAR2   default NULL --quoted owner unsupported
, instURIstr_r2rml          VARCHAR2
, flags                     VARCHAR2   default NULL
);

PROCEDURE r2rml2Schema_FromRRTable (
  rr_table_owner            VARCHAR2
, rr_table_name             VARCHAR2
, staging_table_owner       VARCHAR2
, staging_table_name        VARCHAR2
, flags                     VARCHAR2   default NULL
);

END sdo_rdf_rel2rdf_internal;
/

