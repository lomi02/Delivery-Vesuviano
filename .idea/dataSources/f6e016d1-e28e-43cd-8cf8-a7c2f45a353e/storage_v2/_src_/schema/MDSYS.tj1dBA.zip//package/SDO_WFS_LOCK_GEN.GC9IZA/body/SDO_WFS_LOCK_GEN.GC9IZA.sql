create PACKAGE BODY       SDO_WFS_LOCK_GEN wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
fe 11b
QdI7X9o/UV/rY2aXM85lDYu63DwwgwBK2igVfHRGWE7VesqUp8vYkCXbiU071puPf+nnjQIl
nk0vJE/DZ+1Uwru5mGIfbJYvwGLQcGPL+A2yjW8BFsgExF87AL2wITV6Du7LkNH3iTbW//2s
pHjgateeUVOetUk6e4C3LXaZ6XQ/1luOGahNRWAm4G8Ucuh5/x1ftGud30wwGcHesTQHsSYC
2YydNwCDwyOHbA6F3nUEMY749mU8/txcKR8cMjh+YXV22V9/GhGRmgD4pk9JotY=
/

