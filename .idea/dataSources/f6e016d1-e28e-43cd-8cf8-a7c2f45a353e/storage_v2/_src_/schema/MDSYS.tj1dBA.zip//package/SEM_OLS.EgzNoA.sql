create package sem_ols authid current_user is

  MIN_QUERY_LABEL             CONSTANT VARCHAR2(100) := 'MIN_QUERY_LABEL';

  INTERIM_BREAK_UP_FCN_NAME  CONSTANT varchar2(32767)
      := 'ORACLE_ORARDF_BREAK_UP_TRIPLE';

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE copy_network_info_to_pkg_vars;

  procedure remove_policy_from_app_tab(
    policy_name varchar2,
    schema_name varchar2,
    table_name  varchar2,
    check_model boolean default true,
    network_owner varchar2 default null,
    network_name varchar2 default null);

  procedure apply_policy_to_app_tab(
    policy_name varchar2,
    schema_name varchar2,
    table_name  varchar2,
    predicate   varchar2 default null,
    network_owner varchar2 default null,
    network_name varchar2 default null);

   -- Note: this functionality is exposed in the SEM_MATCH query itself
   procedure set_min_label_for_query(label_name varchar2);
   function  get_min_label_for_query return varchar2;

   --- Additional options for OLS enable RDF data --
   --
   --
   --- APPLY_OLS_POLICY : Apply OLS policy for RDF data.
   --- See SA_POLICY_ADMIN.APPLY_TABLE_POLICY for details.
   --
   procedure apply_ols_policy (
              policy_name      VARCHAR2,
              rdfsa_options    NUMBER,
              table_options    VARCHAR2 default 'ALL_CONTROL',
              predicate        VARCHAR2 default null);

   --
   --- REMOVE_OLS_POLICY : Remove the OLS policy for RDF data
   --- Only a security administrator can execute this command.
   --
   procedure remove_ols_policy;

   --
   --- DISABLE_OLS_POLICY : Disable OLS policy for RDF data.
   --- set_resource_label/set_predicate_label can still be used to set labels
   --- for specific tags.
   --- Only a security administrator can execute this command.
   --
   procedure disable_ols_policy;

   --
   --- ENABLE_OLS_POLICY : Enable OLS policy after disabling.
   --- Only a security administrator can execute this command.
   --
   procedure enable_ols_policy;

end;
/

