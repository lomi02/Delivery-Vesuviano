create package sem_rdfctx authid current_user as

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- helper function
  FUNCTION get_policy_key (policy_owner varchar2, policy_name varchar2, options varchar2 default null)
  RETURN varchar2;

  PROCEDURE copy_network_info_to_pkg_vars;

  procedure create_policy (
              policy_name        VARCHAR2,
              extractor          mdsys.rdfctx_extractor,
              preferences        sys.XMLType default null
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy, AUTO_WITH_COMMIT);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy, AUTO_WITH_COMMIT);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2,
              user_models        mdsys.rdf_models,
              rulebases          mdsys.rdf_rulebases default null
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy, AUTO_WITH_COMMIT);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2,
              user_models        mdsys.rdf_models,
              user_entailments   mdsys.rdf_models,
              rulebases          mdsys.rdf_rulebases default null
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy, AUTO_WITH_COMMIT);

  procedure drop_policy (
              policy_name        VARCHAR2
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_policy, AUTO_WITH_COMMIT);

  procedure set_default_policy (
              index_name         VARCHAR2,
              policy_name        VARCHAR2
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );

  procedure add_dependent_policy (
              index_name           VARCHAR2,
              policy_name          VARCHAR2,
              partition_name       VARCHAR2 default NULL
            , network_owner        dbms_id default NULL
            , network_name         varchar2 default NULL
            );

  function extract_rdfxml (
              doc                CLOB,
              ext_type           mdsys.rdfctx_extractor) return CLOB;

  procedure maintain_triples (
              index_name         VARCHAR2,
              where_clause       VARCHAR2,
              rdfxml_content     sys.XMLType,
              policy_name        VARCHAR2 default NULL,
              action             VARCHAR2 default 'ADD'
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );
  PRAGMA SUPPLEMENTAL_LOG_DATA(maintain_triples, AUTO_WITH_COMMIT);

  procedure set_extractor_param (
              param_key         VARCHAR2,
              param_value       VARCHAR2,
              param_desc        VARCHAR2
            , network_owner      dbms_id default NULL
            , network_name       varchar2 default NULL
            );

end sem_rdfctx;
/

