create package sem_rdfsa authid current_user is


   --
   --- secure options passed to APPLY_OLS_POLICY API --
   --
   SECURE_SUBJECT            CONSTANT SIMPLE_INTEGER := sem_rdfsa_const.SECURE_SUBJECT;

   SECURE_PREDICATE          CONSTANT SIMPLE_INTEGER := sem_rdfsa_const.SECURE_PREDICATE;
   SECURE_OBJECT             CONSTANT SIMPLE_INTEGER := sem_rdfsa_const.SECURE_OBJECT;

   --
   --- Additional options for OLS enable RDF data --
   --
   -- DEFINE_BEFORE_USE: subject or predicate, when secured should be
   -- pre-defined with a label (set_resource_label/set_predicate_label)
   -- before they can be used in a triple -
   OPT_DEFINE_BEFORE_USE     CONSTANT SIMPLE_INTEGER :=
                                sem_rdfsa_const.OPT_DEFINE_BEFORE_USE;
   -- RELAX_TRIPLE_LABEL: The default behavior is that the Triple's label
   -- dominates the labels associated with each of its components.
   -- With this option, a triple label is set to user's initial row
   -- label and the only check performed at the time of triple insertion
   -- is that the user has READ access to its components.
   OPT_RELAX_TRIPLE_LABEL    CONSTANT SIMPLE_INTEGER :=
                                sem_rdfsa_const.OPT_RELAX_TRIPLE_LABEL;

   --Added by Vlad
   TRIPLE_LEVEL_ONLY         CONSTANT SIMPLE_INTEGER := sem_rdfsa_const.TRIPLE_LEVEL_ONLY;

   --
   --- Resource options for Inference Label Generators
   --
   USE_SUBJECT_LABEL          CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_SUBJECT_LABEL;
   USE_PREDICATE_LABEL        CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_PREDICATE_LABEL;
   USE_OBJECT_LABEL           CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_OBJECT_LABEL;
   USE_RULE_LABEL             CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_RULE_LABEL;
   USE_DOMINATING_LABEL       CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_DOMINATING_LABEL;
   USE_ANTECED_LABELS         CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.USE_ANTECED_LABELS;
   CUSTOM_LABELGEN            CONSTANT SIMPLE_INTEGER :=
                                 sem_rdfsa_const.CUSTOM_LABELGEN;

   --
   ---  Predefined label generators for inference. To be used with
   ---  create_entailment API.
   --
   LABELGEN_SUBJECT           CONSTANT mdsys.rdfsa_labelgen :=
                                 sem_rdfsa_const.LABELGEN_SUBJECT;
   LABELGEN_PREDICATE         CONSTANT mdsys.rdfsa_labelgen :=
                                 sem_rdfsa_const.LABELGEN_PREDICATE;
   LABELGEN_OBJECT            CONSTANT mdsys.rdfsa_labelgen :=
                                 sem_rdfsa_const.LABELGEN_OBJECT;
   LABELGEN_RULE              CONSTANT mdsys.rdfsa_labelgen :=
                                 sem_rdfsa_const.LABELGEN_RULE;
   LABELGEN_DOMINATING        CONSTANT mdsys.rdfsa_labelgen :=
                                 sem_rdfsa_const.LABELGEN_DOMINATING;

   VPD_FULL_ACCESS            CONSTANT VARCHAR2(32) := sem_rdfsa_const.VPD_FULL_ACCESS;


   -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
   PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

   function local_sa_session_privs(POLICY_NAME in varchar2) return varchar2;

   /*************************************************************************/
   /*** Wrapper methods needed for rdf_apis_internal change to invoker's  ***/
   /*** right. Current user cannot call DR packages with dynamic SQL.     ***/
   /*************************************************************************/
   procedure maintain_for_ddl (
               p_ddl_type          VARCHAR2,
               p_model_id          NUMBER,
               p_tbs_name          VARCHAR2 default null,
               p_model_tabid       NUMBER default null,
               p_triple_col        VARCHAR2 default null,
               network_owner       varchar2 default null,
               network_name        varchar2 default null);

   function get_ols_policy_name(
     p_network_owner varchar2 default null,
     p_network_name varchar2 default null) return varchar2;

   function has_triple_level_ols(
     p_network_owner varchar2 default null,
     p_network_name varchar2 default null) return number;

   --
   --- APPLY_OLS_POLICY : Apply OLS policy for RDF data.
   --- See SA_POLICY_ADMIN.APPLY_TABLE_POLICY for details.
   --
   procedure apply_ols_policy (
              policy_name      VARCHAR2,
              rdfsa_options    NUMBER   default sem_rdfsa_const.SECURE_SUBJECT,
              table_options    VARCHAR2 default 'ALL_CONTROL',
              label_function   VARCHAR2 default null,
              predicate        VARCHAR2 default null,
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- REMOVE_OLS_POLICY : Remove the OLS policy for RDF data
   --- Only a security administrator can execute this command.
   --
   procedure remove_ols_policy(
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- DISABLE_OLS_POLICY : Disable OLS policy for RDF data.
   --- set_resource_label/set_predicate_label can still be used to set labels
   --- for specific tags.
   --- Only a security administrator can execute this command.
   --
   procedure disable_ols_policy(
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- ENABLE_OLS_POLICY : Enable OLS policy after disabling.
   --- Only a security administrator can execute this command.
   --
   procedure enable_ols_policy(
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- RESET_MODEL_LABELS : Reset the labels for all triples in a model.
   --- Only the user with FULL access on the OLS policy can execute this
   --- command. The model must be empty (of triples) for this operation
   --- to succeed.
   --
   procedure reset_model_labels (
              model_name       VARCHAR2,
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- SET_RESOURCE_LABEL : Set a label for a resource (URI) which may
   --- be used as a Subject or an Object. The resource position is
   --- defaulted to 'S' (Subject) and 'S,O' may be specified to secure
   --- the resource in the Object position as well.
   --- Model Name RDF$GLOBAL can be used to set the label for a resource
   --- across models.
   --
   procedure set_resource_label (
              model_name       VARCHAR2,
              resource_uri     VARCHAR2,
              label_string     VARCHAR2,
              resource_pos     VARCHAR2 default 'S',
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- SET_PREDICATE_LABEL : Set a label for predicate in a specific
   --- model or across all models (RDF$GLOBAL) in the instance.
   ---
   procedure set_predicate_label (
              model_name       VARCHAR2,
              predicate        VARCHAR2,
              label_string     VARCHAR2,
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --- SET_RDFS_LABEL : The RDFS Vocabulary elements such as Class,
   --- subPropertyOf, may be assigned a specfic label to restrict
   --- the users from creating new classes and properties. The
   --- inference override label is used by the label generator to
   --- determine the appropriate labels for the inferred triples.
   ---
   procedure set_rdfs_label (
              label_string     VARCHAR2,
              inf_override     VARCHAR2 default null,
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);

   --
   --- SET_RULE_LABEL : Set label for rule. The rule's label
   --- can be used as the default label for the triples inferred
   --- by this rule. (PARTIAL SUPPORT with RDFs rules and no
   --- support for User defined rules)
   --
   procedure set_rule_label (
              rule_base        VARCHAR2,
              rule_name        VARCHAR2,
              label_string     VARCHAR2,
              network_owner    VARCHAR2 default null,
              network_name     VARCHAR2 default null);


   -- VPD interfaces ---
   -- The VPD policy will be implicitly created in the current
   -- schema. An RDF VPD policy may be used to enforce constraints
   -- on one or more RDF models.
   procedure create_vpd_policy (
              policy_name      VARCHAR2,
              namespace_map    RDF_ALIASES default null,
              policy_context   VARCHAR2 default null,
              flag          in NUMBER   default null);

   -- Drop the VPD policy defined in the current schema. --
   procedure drop_vpd_policy (
              policy_name      VARCHAR2);

   -- Apply a VPD policy to a model --
   procedure apply_vpd_policy (
              policy_name      VARCHAR2,
              model_name       VARCHAR2,
              oper_type        VARCHAR2 default 'ALL',
              flag          in NUMBER   default null);

   -- Remove the VPD policy from a model --
   procedure remove_vpd_policy (
              policy_name      VARCHAR2,
              model_name       VARCHAR2);

   -- Maintain the VPD metadata in the form of RDF scehma statements
   -- associated with policy. Only a fixed set of predicate types are
   -- recognized and accepted by the VPD metadata.
   procedure maint_vpd_metadata (
              policy_name      VARCHAR2,
              t_subject        VARCHAR2,
              t_predicate      VARCHAR2,
              t_object         VARCHAR2,
              action           VARCHAR2 default 'ADD');

   -- Add a constraint to the VPD policy --
   procedure add_vpd_constraint (
              policy_name      VARCHAR2,
              constr_name      VARCHAR2,
              match_pattern    VARCHAR2,
              apply_pattern    VARCHAR2,
              constr_group     VARCHAR2 default null,
              flag          in NUMBER   default null);

   -- Delete a constraint from the VPD policy --
   procedure delete_vpd_constraint (
              policy_name      VARCHAR2,
              constr_name      VARCHAR2);

end;
/

