create package S_sem_rdfctx_dr as

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  procedure set_extractor_param (
              param_key         VARCHAR2,
              param_value       VARCHAR2,
              param_desc        VARCHAR2,
              is_net_host       BOOLEAN);

  procedure setup_for_rdfctx(work_done OUT number, import_mode  BOOLEAN default false);

  procedure cleanup_rdfctx (network_drop     BOOLEAN default false);

  procedure create_policy (
              p_owner          VARCHAR2,
              p_name           VARCHAR2,
              extractor        mdsys.rdfctx_extractor,
              preferences      sys.xmltype
  );

  procedure create_depend_policy (
              p_owner          VARCHAR2,
              p_name           VARCHAR2,
              p_bpolicy        VARCHAR2,
              p_umodels        mdsys.rdf_models,
              p_rulebases      mdsys.rdf_rulebases
  );

  procedure split_policy_list (
              p_powner         VARCHAR2,
              p_inlist         sys.ODCIVarchar2List,
              p_baselist IN OUT sys.ODCIVarchar2List,
              p_deplist  IN OUT sys.ODCIVarchar2List
  );

  procedure drop_policy (
              p_owner          VARCHAR2,
              p_name           VARCHAR2
  );

  procedure drop_index_policy (
              roles_and_privs  VARCHAR2,
              idx_owner        VARCHAR2,
              idx_name         VARCHAR2,
              idxpart_name     VARCHAR2,
              pol_name         VARCHAR2,
              status        IN OUT NUMBER
  );

  procedure set_default_policy (
              i_owner          VARCHAR2,
              i_name           VARCHAR2,
              i_partname       VARCHAR2,
              p_name           VARCHAR2
  );

  procedure add_dependent_policy (
              roles_and_privs  VARCHAR2,
              i_owner          VARCHAR2,
              i_name           VARCHAR2,
              ip_name          VARCHAR2,
              p_name           VARCHAR2
  );

  procedure get_policy_info (
              p_owner          VARCHAR2,
              p_name           VARCHAR2,
              p_polrid  IN OUT VARCHAR2,
              p_extrctr IN OUT mdsys.rdfctx_extractor,
              p_pref    IN OUT sys.xmltype
  );

  procedure get_index_policies (
              p_owner          VARCHAR2,
              p_name           VARCHAR2,
              p_partname       VARCHAR2,
              p_polrids IN OUT sys.ODCIVarchar2List,
              p_modidx  IN OUT sys.ODCINumberList,
              p_extrlst IN OUT mdsys.t_extarr,
              p_pref    IN OUT sys.xmltype,
              p_polnames IN OUT sys.ODCIVarchar2List,
              p_extrparams IN OUT sys.ODCIVarchar2List,
              p_flags    IN OUT sys.ODCINumberList
  );

  procedure get_dep_index_policies (
              idx_owner          VARCHAR2,
              idx_name           VARCHAR2,
              idx_partname       VARCHAR2,
              p_polnames IN OUT sys.ODCIVarchar2List
  );

  function is_index_policy (
              idx_owner          VARCHAR2,
              idx_name           VARCHAR2,
              idx_partname       VARCHAR2,
              idx_polname          VARCHAR2
  ) return boolean;

  procedure exchange_index_policies (
              p_pidxowner         VARCHAR2,
              p_pidxname          VARCHAR2,
              p_partname          VARCHAR2,
              p_pidxmodel         NUMBER,
              p_owner             VARCHAR2,
              p_name              VARCHAR2,
              p_model             NUMBER
  );

  function get_model_id (
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_polnm          VARCHAR2 default null
  ) return number;

  function get_base_model_id (
              p_virmod_id      NUMBER
  ) return number;

  function create_rdfctx_index (
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_rid            VARCHAR2,
              p_flags          NUMBER,
              p_tbsnm          VARCHAR2,
              p_extrparam      VARCHAR2
  ) return number;

  procedure create_virtual_rdfctx_index (
              roles_and_privs  VARCHAR2,
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_depplcnm       VARCHAR2
  );

  procedure set_rdfctx_index_status (
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_polmodid       VARCHAR2,
              p_flags          NUMBER
  );

  procedure set_rdfctx_index_status_valid (
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_polmodid       VARCHAR2
  );

  procedure drop_rdfctx_index (
              roles_and_privs  VARCHAR2,
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_polrid         VARCHAR2 default null
  );

  procedure truncate_rdfctx_index (
              p_idxowner       VARCHAR2,
              p_idxname        VARCHAR2,
              p_idxpartname    VARCHAR2,
              p_polrid         VARCHAR2 default null
  );

  function load_triples (
              rdfreptype        VARCHAR2,
              rdfdata           CLOB,
              doc_ident         VARCHAR2,
              model_id          NUMBER,
              policy_rid        VARCHAR2,
              oper_type         VARCHAR2,
              stagtab           VARCHAR2,
              stagtab_suffix    VARCHAR2,
              part_name         VARCHAR2,
              doc_rid           VARCHAR2 default NULL
  ) return number;

  procedure bulk_load_into_model(
    model_id         NUMBER
  , usedOpts         sys.ODCIVarchar2list
  , stagtab_owner    VARCHAR2
  , stagtab_name     VARCHAR2
  , part_name        VARCHAR2
  , docUri2Rid_name  VARCHAR2
  , docVid2Rid_name  VARCHAR2
  , stagtab_part_view_name     VARCHAR2
  , user_name        VARCHAR2
  , roles_and_privs  VARCHAR2
  );

  procedure delete_triples (
              doc_rid        VARCHAR2,
              model_id         NUMBER,
              docVid           NUMBER
  );

  procedure load_triples_from_transient (
              doc_ident         VARCHAR2,
              model_id          NUMBER,
              stagtab           VARCHAR2,
              part_name         VARCHAR2,
              doc_rid           VARCHAR2 default NULL
  );

  procedure record_rdfctx_exception (
              model_id         NUMBER,
              doc_ident        VARCHAR2,
              excep_type       NUMBER,
              excep_code       NUMBER,
              excep_text       CLOB
  );

  FUNCTION is_entailment_compat (
    model_name      VARCHAR2,
    reqIdxStatus    VARCHAR2
  ) RETURN BOOLEAN;

  FUNCTION get_exceptions_count RETURN NUMBER;

end S_sem_rdfctx_dr;
/

