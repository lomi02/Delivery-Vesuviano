create PROCEDURE load_predefined_rulebases (
  user_name varchar2
) AUTHID CURRENT_USER IS
  predefined_RB_list mdsys.rdf_rulebases :=
    mdsys.rdf_rulebases('RDF','RDFS','RDFS++','OWLSIF','OWLPRIME','SKOSCORE','OWL2RL','OWL2EL');
BEGIN
  --rdf_apis_internal.ksdwrf('ENTERED: load_predefined_rulebases', true);

  mdsys.rdf_apis_internal.create_predefined_RBs(
    user_name, predefined_RB_list);
  --rdf_apis_internal.ksdwrf('load_predefined_rulebases: 1', true);

  mdsys.rdf_apis_internal.grants_for_predefined_RBs(predefined_RB_list);
  --rdf_apis_internal.ksdwrf('load_predefined_rulebases: 2', true);

  mdsys.rdf_apis_internal.populate_RDF_and_RDFS_RBs;
  --rdf_apis_internal.ksdwrf('load_predefined_rulebases: 3', true);

  commit;

   EXCEPTION
        WHEN OTHERS THEN
                MDERR.RAISE_MD_ERROR('MD', 'SDO', -13199,
             'RDF: Error in load_predefined_rulebases(): '
          || chr(10) || dbms_utility.format_error_stack
          || chr(10) || '['
          || chr(10) || dbms_utility.format_error_backtrace
          || chr(10) || ']');
END load_predefined_rulebases;
/

