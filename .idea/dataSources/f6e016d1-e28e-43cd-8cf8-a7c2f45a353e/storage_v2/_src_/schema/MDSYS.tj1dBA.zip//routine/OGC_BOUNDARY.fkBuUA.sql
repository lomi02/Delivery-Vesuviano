create FUNCTION OGC_Boundary(
  g ST_Geometry)
    RETURN ST_Geometry IS
BEGIN
  RETURN g.ST_Boundary();
END OGC_Boundary;
/

