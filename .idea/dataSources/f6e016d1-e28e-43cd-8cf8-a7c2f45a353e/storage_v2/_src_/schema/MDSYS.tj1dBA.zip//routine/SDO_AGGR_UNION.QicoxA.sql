create function       SDO_Aggr_Union wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
82 ae
CBW9mu2LtSquwsOzqrUUQy83Eccwg+nw2stGfHRExIuO0WsxmX6U8wu+49bkPgljoiHYoP6W
b6sWT8khIL1YkAqpQ4PrYXMjdvj+BLb3ZmyAFaNQDTX6PIoQJx+bYQYhphYjTXrYmiNggGJW
fv9OuMHKXwKPg6jBu8GBW5cPbL0=
/

