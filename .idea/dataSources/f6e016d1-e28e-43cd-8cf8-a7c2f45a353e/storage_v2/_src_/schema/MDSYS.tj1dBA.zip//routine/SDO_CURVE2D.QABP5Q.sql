create FUNCTION sdo_curve2d return NUMBER is
 BEGIN
 return 2002;
 END sdo_curve2d;
/

