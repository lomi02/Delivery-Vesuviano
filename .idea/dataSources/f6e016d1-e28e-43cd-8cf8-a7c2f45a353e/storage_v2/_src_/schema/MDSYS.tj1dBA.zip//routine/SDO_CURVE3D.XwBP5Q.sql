create FUNCTION sdo_curve3d return NUMBER is
 BEGIN
 return 3002;
 END sdo_curve3d;
/

