create FUNCTION sdo_linestring3d return NUMBER is
 BEGIN
 return 3002;
 END sdo_linestring3d;
/

