create FUNCTION sdo_lonlat return NUMBER is
 BEGIN
 return 4326;
 END sdo_lonlat;
/

