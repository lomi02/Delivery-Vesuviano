create FUNCTION sdo_multipoint3d return NUMBER is
 BEGIN
 return 3005;
 END sdo_multipoint3d;
/

