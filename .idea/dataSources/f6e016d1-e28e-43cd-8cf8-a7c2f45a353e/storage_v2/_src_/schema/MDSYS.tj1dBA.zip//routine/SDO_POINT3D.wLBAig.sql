create FUNCTION sdo_point3d return NUMBER is
  BEGIN
  return 3001;
  END sdo_point3d;
/

