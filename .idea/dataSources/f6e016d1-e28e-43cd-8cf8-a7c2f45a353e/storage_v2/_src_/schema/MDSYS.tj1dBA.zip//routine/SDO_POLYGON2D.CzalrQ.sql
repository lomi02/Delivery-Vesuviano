create FUNCTION sdo_polygon2d return NUMBER is
 BEGIN
 return 2003;
 END sdo_polygon2d;
/

