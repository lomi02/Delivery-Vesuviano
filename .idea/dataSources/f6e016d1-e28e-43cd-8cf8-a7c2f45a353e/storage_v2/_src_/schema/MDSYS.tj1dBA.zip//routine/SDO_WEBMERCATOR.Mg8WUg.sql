create FUNCTION sdo_webmercator return NUMBER is
 BEGIN
 return 3857;
 END sdo_webmercator;
/

