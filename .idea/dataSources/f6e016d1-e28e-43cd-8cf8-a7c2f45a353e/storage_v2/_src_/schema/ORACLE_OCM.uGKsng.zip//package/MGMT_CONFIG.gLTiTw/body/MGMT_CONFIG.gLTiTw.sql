create PACKAGE body            MGMT_CONFIG AS

JOB_NAME CONSTANT VARCHAR(40) := 'MGMT_CONFIG_JOB';
STATS_JOB_NAME CONSTANT VARCHAR(40) := 'MGMT_STATS_CONFIG_JOB';

/*
 Checks to see if the job already exists
*/
FUNCTION job_exists (job_name_in VARCHAR) RETURN BOOLEAN IS
  l_job_cnt NUMBER;
BEGIN
   select count(*) into l_job_cnt from
	sys.dba_scheduler_jobs WHERE job_name = job_name_in and owner ='ORACLE_OCM';
  if l_job_cnt = 0
  THEN
    return FALSE;
  ELSE
    return TRUE;
  END IF;
END job_exists;

/*
Submit a job to collect the configuration.
Basically, a job with what->collect_config
*/
procedure submit_job IS
  l_is_cdb         VARCHAR2(4) := 'NO';
  l_con_id         NUMBER;
BEGIN
   -- Check first to see if connected to a PDB.
   BEGIN
     execute immediate 'SELECT UPPER(CDB), SYS_CONTEXT(''USERENV'', ''CON_ID'') FROM sys.V_$DATABASE' into l_is_cdb, l_con_id;
   EXCEPTION
     WHEN OTHERS THEN
       null;
   END;
  -- Pseudo logic is do nothing if connected to a PDB, all other scenarios submit the job.
  -- YES and con_id = 1, means connected to root container.
  -- YES and con_id > 1, means connected to a PDB.
  -- NO or NULL means connected to a normal (non-container/PDB) database.
  IF l_is_cdb = 'YES' and l_con_id > 1  THEN
    NULL;
  ELSE
    IF not job_exists(JOB_NAME) THEN
      sys.dbms_scheduler.create_job(
        job_name => JOB_NAME,
        job_type => 'STORED_PROCEDURE',
        job_action => 'ORACLE_OCM.MGMT_CONFIG.collect_config',
        start_date=> SYSTIMESTAMP+1,
        repeat_interval => 'freq=daily;byhour=01;byminute=01;bysecond=01',
        end_date => NULL,
        enabled => TRUE,
        auto_drop => FALSE,
        comments => 'Configuration collection job.');
     COMMIT;
    ELSE
      RAISE_APPLICATION_ERROR(-20000,'Cannot resubmit. A job '''|| JOB_NAME
                       || '''already exists.');
    END IF;
    IF not job_exists(STATS_JOB_NAME) THEN
      sys.dbms_scheduler.create_job(
        job_name => STATS_JOB_NAME,
        job_type => 'STORED_PROCEDURE',
        job_action => 'ORACLE_OCM.MGMT_CONFIG.collect_stats',
 	start_date=> SYSTIMESTAMP+1,
        repeat_interval => 'freq=monthly;interval=1;bymonthday=1;byhour=01;byminute=01;bysecond=01',
        end_date => NULL,
        enabled => TRUE,
        auto_drop => FALSE,
        comments => 'OCM Statistics collection job.');
     COMMIT;
    ELSE
      RAISE_APPLICATION_ERROR(-20001,'Cannot resubmit. A job '''|| STATS_JOB_NAME
                       || '''already exists.');
    END IF;
  END IF; -- Is PDB?
END submit_job;

/*
Submit a job to collect the configuration.
Basically, a job with what->collect_config_metrics(<collection directory>
*/
procedure submit_job_for_inst(inst_id IN BINARY_INTEGER, p_inst_num IN BINARY_INTEGER,
                              p_job_name IN VARCHAR2,
                              p_job_action IN VARCHAR2, p_job_action2 in VARCHAR2) IS
  l_job NUMBER;
  l_par sys.V_$INSTANCE.PARALLEL%TYPE;
  l_instNum sys.V_$INSTANCE.INSTANCE_NUMBER%TYPE;
BEGIN
  BEGIN
    IF not job_exists(p_job_name || '_' || inst_id) THEN
      sys.dbms_scheduler.create_job(
        job_name => p_job_name || '_' || inst_id,
        job_type => 'PLSQL_BLOCK',
        job_action => p_job_action ,
        start_date => NULL,
        repeat_interval => NULL,
        enabled => FALSE,
        auto_drop => TRUE,
        comments => 'OCM collection job run for an instance.');
      BEGIN
        -- Use the instance_id attribute.
        -- This may throw exception if not implemented in the version of
        -- the database. We would be ignoring the exception it that case.
        sys.DBMS_SCHEDULER.SET_ATTRIBUTE (p_job_name || '_' || inst_id,'instance_id',inst_id);
        EXCEPTION
          WHEN OTHERS THEN NULL;
      END;
      sys.DBMS_SCHEDULER.ENABLE (p_job_name || '_' || inst_id);
      -- Run the job synchronously
      -- sys.DBMS_SCHEDULER.RUN_JOB(p_job_name || '_' || inst_id,FALSE);
      COMMIT;
    END IF;
    EXCEPTION
      WHEN OTHERS THEN
      -- Don't raise an exception otherwise it fills the alert/trace
      sys.DBMS_OUTPUT.put_line('Do not raise an exception');
       -- RAISE_APPLICATION_ERROR(-20000,'SQLERRM: ' || SQLERRM || ' SQLCODE: '|| SQLCODE);
  END;

  -- create 2nd job if specified
  IF p_job_action2 is NOT NULL THEN
    select PARALLEL into l_par  from sys.V_$INSTANCE;
    IF l_par = 'YES' THEN
      select instance_number into l_instNum from sys.V_$INSTANCE;
      IF l_instNum <> p_inst_num THEN
      BEGIN
        IF not job_exists(p_job_name || '_2_' || inst_id) THEN
          sys.dbms_scheduler.create_job(
            job_name => p_job_name || '_2_' || inst_id,
            job_type => 'PLSQL_BLOCK',
            job_action => p_job_action2 ,
            start_date => NULL,
            repeat_interval => NULL,
            enabled => FALSE,
            auto_drop => TRUE,
            comments => 'OCM 2nd job run for RAC instance.');
          BEGIN
            -- Use the instance_id attribute.
            -- This may throw exception if not implemented in the version of
            -- the database. We would be ignoring the exception it that case.
            sys.DBMS_SCHEDULER.SET_ATTRIBUTE (p_job_name || '_2_' || inst_id,'instance_id',inst_id);
            EXCEPTION
              WHEN OTHERS THEN NULL;
          END;
          sys.DBMS_SCHEDULER.ENABLE (p_job_name || '_2_' || inst_id);
          COMMIT;
        END IF;
        EXCEPTION
          WHEN OTHERS THEN
          -- Don't raise an exception otherwise it fills the alert/trace
          sys.DBMS_OUTPUT.put_line('Do not raise an exception');
      END;
      END IF;
    END IF;
  END IF;
END submit_job_for_inst ;

/*
Runs the configuration collection job now.
*/
procedure run_now IS
BEGIN
   	sys.DBMS_SCHEDULER.RUN_JOB(JOB_NAME);
   	sys.DBMS_SCHEDULER.RUN_JOB(STATS_JOB_NAME);
  	COMMIT;
END run_now;

/*
Print the job details.
*/
procedure print_job_details IS
BEGIN
        sys.dbms_output.put_line('Configuration collection job name: ' || JOB_NAME);
        sys.dbms_output.put_line('Statistics collection job name: ' || STATS_JOB_NAME);
        sys.dbms_output.put_line('Job Schedule: DAILY');
END print_job_details;

/*
Stop (and drop) the job.
*/
procedure stop_job IS
BEGIN

  BEGIN
    sys.DBMS_SCHEDULER.disable(job_name, TRUE);
    BEGIN
      sys.DBMS_SCHEDULER.stop_job(job_name, TRUE);
    EXCEPTION WHEN others THEN
      IF sqlcode = -27366 THEN NULL; --Suppress job not running error
      ELSE raise;
      END IF;
    END;
    sys.DBMS_SCHEDULER.drop_job(job_name, TRUE);
  EXCEPTION WHEN others THEN
    IF sqlcode = -27475 THEN NULL; --Suppress job not existing error
    ELSE raise;
    END IF;
  END;

  BEGIN
    sys.DBMS_SCHEDULER.disable(stats_job_name, TRUE);
    BEGIN
      sys.DBMS_SCHEDULER.stop_job(stats_job_name, TRUE);
    EXCEPTION WHEN others THEN
      IF sqlcode = -27366 THEN NULL; --Suppress job not running error
      ELSE raise;
      END IF;
    END;
    sys.DBMS_SCHEDULER.drop_job(stats_job_name, TRUE);
  EXCEPTION WHEN others THEN
    IF sqlcode = -27475 THEN NULL; --Suppress job not existing error
    ELSE raise;
    END IF;
  END;

  COMMIT;
END stop_job;

/*
Config collection job
*/
procedure collect_config IS
  CURSOR l_res_cur IS select inst_id,instance_number from sys.GV_$INSTANCE;
BEGIN
	FOR inst_id_row in l_res_cur LOOP
		submit_job_for_inst(inst_id_row.inst_id, inst_id_row.instance_number, JOB_NAME,
                 'BEGIN ORACLE_OCM.MGMT_DB_LL_METRICS.COLLECT_CONFIG_METRICS(''ORACLE_OCM_CONFIG_DIR''); END;',
                 'BEGIN ORACLE_OCM.MGMT_DB_LL_METRICS.WRITE_DB_CCR_FILE(''ORACLE_OCM_CONFIG_DIR2'', TRUE); END;');
	END LOOP;
END collect_config;

/*
Statistics collection job
*/
procedure collect_stats IS
  CURSOR l_res_cur IS select inst_id, instance_number from sys.GV_$INSTANCE;
BEGIN
	FOR inst_id_row in l_res_cur LOOP
		submit_job_for_inst(inst_id_row.inst_id, inst_id_row.instance_number, STATS_JOB_NAME,
                'BEGIN ORACLE_OCM.MGMT_DB_LL_METRICS.collect_stats_metrics(''ORACLE_OCM_CONFIG_DIR''); END;',
                 NULL);
	END LOOP;
END collect_stats;

END MGMT_CONFIG;
/

