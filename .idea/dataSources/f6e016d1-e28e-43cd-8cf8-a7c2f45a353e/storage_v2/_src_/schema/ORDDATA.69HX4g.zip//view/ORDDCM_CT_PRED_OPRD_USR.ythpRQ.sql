create view ORDDCM_CT_PRED_OPRD_USR as
select PID, POS, OPERAND
  from ORDDATA.ORDDCM_CT_PRED_OPRD_TMP
  with read only
/

