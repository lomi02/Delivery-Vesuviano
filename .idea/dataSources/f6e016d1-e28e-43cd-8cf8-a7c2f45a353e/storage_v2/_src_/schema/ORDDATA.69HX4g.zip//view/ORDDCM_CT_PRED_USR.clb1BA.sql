create view ORDDCM_CT_PRED_USR as
select PID, FPID, POS, REF_PID, OP, DESCRIPTION
  from ORDDATA.ORDDCM_CT_PRED_TMP
  with read only
/

