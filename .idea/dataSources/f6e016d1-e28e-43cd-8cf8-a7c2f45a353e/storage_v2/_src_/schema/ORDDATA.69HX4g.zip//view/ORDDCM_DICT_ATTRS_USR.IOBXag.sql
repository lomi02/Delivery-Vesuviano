create view ORDDCM_DICT_ATTRS_USR as
select DA_ID ,SA_ID ,PA_ID
from ORDDATA.ORDDCM_DICT_ATTRS_TMP
with read only
/

