create TYPE          "TM_ATTR_ORD_DCM_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SYS_XDBBODY$" TIMESTAMP,"tag" RAW(4),"definer" VARCHAR2(64 CHAR),"name" VARCHAR2(128 CHAR),"number" NUMBER(20),"offset" NUMBER(20),"length" NUMBER(20),"truncated" RAW(1),"rawValue" RAW(2000),"byteOrderLE" RAW(1))NOT FINAL INSTANTIABLE
/

