create PACKAGE BODY        CARTRIDGE wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
3eb 1be
XC/eDENeSi2BpEoezVImAHPpstkwg+1er9xqfHRDaGR8sHnT5m4mn7i2IKIUUo1XrJCbtao3
6yUuC6lAL6InFPjtIgAere/sF2i2dH4ocHyhwCvZ/0PiHQS2/cJs87SoXUXvjmInFodxyh5p
rfZz0la03Yq976Yf++NsdIm5yZ6nsSdTojf+x6GTw3FoCPTgeigYIGeWKjySCxUQZ42OSnZT
XcW9C2DvSgskzM8NFlRDfNO4wioM5RkBN8bNk+0ZVs/HoDy4Kp/UD/xYJFAZlbkD+o35fNVB
OUEjUExfTXNUNLuYvUXkKdaftwB/YkLTrEwGUHSLhLwgIgw8Z/Zmt+5D9CHaajhdWswn22e4
mAKNKjgqEsN8V1h0aaAPQ2iqA7I8JtS10RXQM2cVtKyQQ7UWRdXx+DJI6sbfRFFpHUquRZ1C
Hcb3CAQ=
/

