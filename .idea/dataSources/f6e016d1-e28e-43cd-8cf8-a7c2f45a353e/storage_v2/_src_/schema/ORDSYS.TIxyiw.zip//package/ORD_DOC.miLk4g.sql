create PACKAGE        ORD_DOC AUTHID CURRENT_USER AS

-------------------------------------
--FUNCTIONS AND PROCEDURES
-------------------------------------

--Description: Copies multimedia data from BLOBs within the database to an external
--data source.
--Input:
--src: The BLOB location of the data to be exported (or copied) to the destination
--location
--dest_location: The location to which the source data is to be exported.
--(File directory object)
--dest_name: The name of the destination file.
--Exceptions: ORDSourceExceptions.INCOMPLETE_SOURCE_INFORMATION
--            ORDSourceExceptions.IO_ERROR

  PROCEDURE  export (
      src IN BLOB,
      dest_location IN VARCHAR2,
      dest_name IN VARCHAR2
      );

-- Description: Import data from the specified external data source to the BLOB
-- specified by the dest parameter.
-- Input:
-- dest: The BLOB location to receive the data
-- source_type: The type of the source data.  (FILE or URL)
-- source_location: The location from which the source data is to be imported.
-- source_name: The name of the source data.
-- Exceptions:ORDSourceExceptions.NULL_SOURCE

  PROCEDURE  importFrom (
      dest IN OUT NOCOPY BLOB,
      source_type IN VARCHAR2,
      source_location IN VARCHAR2,
      source_name IN VARCHAR2
      );

-- Description: Import data from the specified external data source to the BLOB
-- specified by the dest parameter.
-- Input:
-- dest: The BLOB location to receive the data
-- source_type: The type of the source data.  (FILE or URL)
-- source_location: The location from which the source data is to be imported.
-- source_name: The name of the source data.
-- format: The format of the data.
-- mime_type: The MIME type of the data.
-- Exceptions:ORDSourceExceptions.NULL_SOURCE

PROCEDURE  importFrom (
    dest IN OUT NOCOPY BLOB,
    source_type IN VARCHAR2,
    source_location IN VARCHAR2,
    source_name IN VARCHAR2,
    format OUT VARCHAR2,
    mime_type OUT VARCHAR2
    );


-- Description: Reads the document BFILE data to get the values of the media
-- attributes for supported formats and then stores them in the input CLOB.
-- This procedure populates the CLOB with a set of format and application
-- properties in XML form.
-- Input:
-- docBfile: The document data represented as BFILE.
-- attributes: The CLOB to hold the XML attribute information extracted by
-- the getProperties procedure.
-- This CLOB is populated with a set of format and application
-- properties of the document
-- BFILE data in XML form.
-- Exceptions: ORDSourceExceptions.EMPTY_SOURCE

PROCEDURE  getProperties (
    docBfile IN OUT NOCOPY BFILE,
    attributes IN OUT NOCOPY CLOB
    );

-- Description: Reads the document BFILE data to get the values of the media
-- attributes for supported formats and then
-- returns them as explicit parameters.  This procedure gets the properties for
-- these attributes of the document data: MIME types, content length,and format.
-- It also populates the CLOB with a set of format and application properties
-- in XML form.
-- Input:
-- docBfile: The document data represented as BFILE.
-- mimeType: The MIME type of the document data.
-- format: The format of the document data.
-- contentLength: The length of the content, in bytes.
-- Exceptions: ORDSourceExceptions.EMPTY_SOURCE

PROCEDURE  getProperties (
    docBfile IN OUT NOCOPY BFILE,
    mimeType OUT VARCHAR2,
    format OUT VARCHAR2,
    contentLength OUT INTEGER
    );

-- Description: Reads the document BLOB data to get the values of the media
-- attributes for supported formats and then stores them in the input CLOB.
-- This procedure populates the CLOB with a set of format and application
-- properties in XML form.
-- Input:
-- docBlob: The document data represented as BLOB.
-- attributes: The CLOB to hold the XML attribute information extracted by
-- the getProperties procedure.
-- This CLOB is populated with a set of format and application properties
-- of the document BFILE data in XML form.
-- Exceptions: ORDSourceExceptions.EMPTY_SOURCE

PROCEDURE  getProperties (
    docBlob IN BLOB,
    attributes IN OUT NOCOPY CLOB
    );

-- Description: Reads the document BLOB data to get the values of the media
-- attributes for supported formats and then
-- returns them as explicit parameters.  This procedure gets the properties
-- for these attributes of the document data: MIME types, content length, and
-- format.
-- Input:
-- docBLOB: The document data represented as BLOB.
-- mimeType: The MIME type of the document data.
-- format: The format of the document data.
-- contentLength: The length of the content, in bytes.
-- Exceptions: ORDSourceExceptions.EMPTY_SOURCE

PROCEDURE  getProperties (
    docBlob IN BLOB,
    mimeType OUT VARCHAR2,
    format OUT VARCHAR2,
    contentLength OUT INTEGER
    );

END;
/

