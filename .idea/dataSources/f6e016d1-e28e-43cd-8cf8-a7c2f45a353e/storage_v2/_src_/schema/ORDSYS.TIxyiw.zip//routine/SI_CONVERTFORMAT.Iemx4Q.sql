create PROCEDURE
  SI_convertFormat wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
182 16d
L6xe2M6IM7nVVtEO2i0EIi075ykwgwHQNfZqfHQCv7lkUGK9RkuNkG+fuLaV89ufyEOfAI1/
n2ieY4r+rkhltHWW5nKaEvHJy6Qz9PNmkBn/Tw+7nB64vM80hwzA1GbIB8g2z30Vz0dpjuzo
BQ/tN7WudLqJqEuCUTuD/kCYs6VhCWgUiCYH0X+MnF4YheUJcfEhpA9FUIYz+e7z3UnEhDkw
I0BWoBOko5uIY/s/PG0YLl5EZVEP/r1oxgt+oMiEi92tZd9+FlGLhlaO5DeR9bOnRK26d6qA
sWmOXJjof/LgnfVX6XFDBc5geSMTxFN2cfm8vCeU2SGSh3hIeL7JhKUSXZQnu7z7OZ2HkA==

/

