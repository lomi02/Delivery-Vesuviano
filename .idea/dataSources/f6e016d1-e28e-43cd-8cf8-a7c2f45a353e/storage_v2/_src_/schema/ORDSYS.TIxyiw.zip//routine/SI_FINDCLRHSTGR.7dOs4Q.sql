create FUNCTION
  SI_findClrHstgr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
c5 db
pDkG1dXTvK0E64JUfgC7Sv4dPlMwgwFKNZ4VZ3TpTP6Ok4OC9VyCKVlw7DcU1tlIovPb6R5z
UlbnrAX+ItAkXDXBZnA0cbtymSI8oO1IHrPyXBRBxlrdmN/Bbr9Qv6byhzLBVMCz24ts/Fd4
KiuudqYKxfSWPVr9sl0aggz9ZeG6v1GFJdt4RObBtRm79z99WhUXgi02R+xHjMsHeA2A37g=

/

