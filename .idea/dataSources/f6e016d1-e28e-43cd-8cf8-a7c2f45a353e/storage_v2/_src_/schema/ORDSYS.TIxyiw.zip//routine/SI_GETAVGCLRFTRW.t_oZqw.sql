create FUNCTION
  SI_getAvgClrFtrW wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
10f fb
FPErZHql54yIFwc+ZTuc0ykvFdUwg1zc2svWfHTNRz56p2MfcJ70tlZja8BuZWVcVpAv/Dr2
ZaBLAJ1kEKErEVnI3oeHEzpWM+2SeZDiHPCO1FqTqeU/cIM5qcxkNkhWEKIwfKOXgxoYPmXI
Hbp1f/pxZcLCy0Q63KGGkTfA6wsOVctd7nqcqI0Eusj7Cvs/9tqaXJ4L1AOfTVMpmIuIfpGW
egI1Jzm36zueE6QKPg7kEFVDmfl4YK4=
/

