create FUNCTION
  SI_getContentLngth wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f3 ef
SUzCHfOsq4/AS/YiCHvdKkaECCQwg1xKf8vWfHTp2see0AEpRHURfK/xfwkGR1nj3PX6cwIt
omPcpxn4tdkL9w6g55Gj/jtAu8zEjJstsXK3iyJmyJjY24oOeabTJ6Hg8n/gZVAfkBGpaQnm
sw2RsB3F6FhG2KSpwE7UWuDhEUYSItaOi2/15uqlE50wweethp1Om9kcmW0AqJcWzEmujHRh
miqxDWei7YIcQm5xlyQ2
/

