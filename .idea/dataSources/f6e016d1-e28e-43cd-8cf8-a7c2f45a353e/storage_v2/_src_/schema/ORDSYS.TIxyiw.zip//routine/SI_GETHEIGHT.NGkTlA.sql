create FUNCTION
  SI_getHeight wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
e0 e3
LFq4o2mNSMUNuGDo7f9hbs9urDkwg1xKLcvWfHSi2k6UHNklLHBR7lpWROrybli9s7nknSfY
YQlJDLtVkHp4vZcoa5cevKTeEs1yhpfZBDWKoMXBig67456glH9j4xY51Oj0SZ47juPiO3uQ
DhaZmbraL7G5SoXgrDDou89s3q3+Gr3ifXiqm6/zwJWdTpvXHAyPdXcLyPpAB7k0yWbS75Yg
tbFXrA==
/

