create PROCEDURE
  SI_setTextureFtr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
19f 11f
hkDIIyspH1TJ7cZ49ayc0ZeD1Hgwg/Cu18usfHQzR17S5/QIRFf71SWRKYU86QBSBkQvtiya
soDhs6ISJ51PM/YgLtaXujaAahBuAc//0N5+wT4gLfFnEcDhJuOvMPvf8Ckgsy2zdoLOVq/2
Xbd+VfNf9M5q9a2/0y6XzqPv0m/9wJFT5zyXDICeqyBiwnQZa7IWvtjUglJoLmKKHKhbig3R
Z3td9WjgDr5xG3fLtjQtkObgB/HIzyylHigkHMWn9oXFNnGDVjO71QqjfkIw+2+y4LU=
/

