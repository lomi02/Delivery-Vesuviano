create FUNCTION                        restrict_access wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
202 154
XsN9swyBhTPY24gk97XhhnbPbBswgwL3r9xqfHRArf4+z9kbzSFKAAGQ2Wayv5ej4syxAtMh
nhQpMBAl5Q4mS/8fuvnNcmFub4ldZu9Lg0L2xWSX5SX/6aYDkEfTcR/TlAiARknRt7Kc2a1a
R5mhS5fCYsDhLdArzsoW0qbjjmAQrHDUcRIwgoftvCzDdXdBNAuZcCux1EJ5XJMe1APprs6a
P+dyixqd8g/tccFWsDWcRnLfblX39ceKZ6qxNPv2EwiyVWWXOiXLCAIwJNeSfC7NoAD22RuX
i+2nIMg/bUCqXcLdU64Gn9ALKkOorYWgy6oYjI+GmCAllkCj
/

