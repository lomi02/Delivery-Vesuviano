create trigger TRG_INCREMENTARIDERID
    before insert
    on RIDER
    for each row
BEGIN
  SELECT SEQ_RIDER_ID.NEXTVAL INTO :NEW.RIDER_ID FROM DUAL;
END;
/

