create TYPE adr_incident_file_t FORCE AS OBJECT
(
  dirpath               VARCHAR2(512),         /* directory path of the file */
  filename              VARCHAR2(64)                            /* file name */
);
/

