create TYPE adr_incident_t AS OBJECT
(
  home                   adr_home_t,           /* adr home for this incident */
  id                     INTEGER,                             /* incident id */
  staged                 VARCHAR2(1),                  /* is staged incident */
  in_update              VARCHAR2(1),         /* is in the process of update */
  pending                adr_incident_info_t,            /* for internal use */


  -- **********************************************************************
  -- Gets the id of this incident
  -- **********************************************************************

  MEMBER FUNCTION get_id RETURN INTEGER,


  -- **********************************************************************
  -- Gets the path to the directory where incident diagnostic files reside
  -- Value is <ADR_HOME>/incident/incdir_<ID>
  -- **********************************************************************

  MEMBER FUNCTION get_incident_location RETURN VARCHAR2,


  -- **********************************************************************
  -- Writes diagnostics to the default incident file
  -- **********************************************************************

  MEMBER PROCEDURE dump_incident
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    data     IN VARCHAR2                    /* data to dump in incident file */
  ),


  -- **********************************************************************
  -- Writes RAW diagnostics to the default incident file
  -- **********************************************************************

  MEMBER PROCEDURE dump_incident_raw
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    data     IN RAW                     /* RAW data to dump in incident file */
  ),


  -- **********************************************************************
  -- Writes diagnostics to a specified incident file in the incident
  -- directory
  -- **********************************************************************

  MEMBER PROCEDURE dump_incfile
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    filename IN VARCHAR2,          /* additional incident file to be created */
    data     IN VARCHAR2                       /* data to dump in above file */
  ),


  -- **********************************************************************
  -- Writes raw diagnostic data to the specified incident file in the
  -- incident directory
  -- **********************************************************************

  MEMBER PROCEDURE dump_incfile_raw
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    filename IN VARCHAR2,          /* additional incident file to be created */
    data     IN RAW                        /* RAW data to dump in above file */
  ),


  -- **********************************************************************
  -- Adds correlation key to this incident
  -- **********************************************************************

  MEMBER PROCEDURE add_correlation_key
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    name     IN VARCHAR2,                            /* correlation key name */
    value    IN VARCHAR2,                           /* correlation key value */
    flags    IN INTEGER DEFAULT NULL                /* correlation key flags */
  ),


  -- **********************************************************************
  -- Registers a file with this incident.
  -- The file can be anywhere in ADR home.
  -- **********************************************************************

  MEMBER PROCEDURE register_file
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    dirpath  IN VARCHAR2,                      /* directory path of the file */
    filename IN VARCHAR2                                        /* file name */
  ),


  -- **********************************************************************
  -- Registers a file in incident directory with this incident
  -- **********************************************************************

  MEMBER PROCEDURE register_file
  (
    SELF     IN OUT NOCOPY adr_incident_t,
    filename IN VARCHAR2                                        /* file name */
  ),


  -- **********************************************************************
  -- Marks the beginning of post-create updates to this incident
  --  This should be used to add correlation keys, adding additional
  --  incident files and other incident metadata changes after
  --  the incident has already been created
  -- **********************************************************************

  MEMBER PROCEDURE begin_update(SELF IN OUT NOCOPY adr_incident_t),


  -- **********************************************************************
  -- Marks the end of post-create updates to this incident
  --  begin_update and end_update must always be used together
  -- **********************************************************************

  MEMBER PROCEDURE end_update(SELF IN OUT NOCOPY adr_incident_t)
);
/

