create TYPE aq$_bnd FORCE AS OBJECT (
   dtype        PLS_INTEGER,        /* data type of bind variable
                                       0 - VARCHAR2
                                       1 - NUMBER
                                       2 - RAW
                                       3 - TIMESTAMP WITH TIMEZONE
                                       4 - UROWID
                                                                  */
   bmode         PLS_INTEGER,               /* bind mode (IN|OUT)
                                               0 - IN, 1 - OUT    */

   sz            PLS_INTEGER,       /* Maximum size of data buffer
                                      in case of OUT bind         */

   /* Depending the datatype set in dtype, only one of the following
    * fields is used at any given point.
    */
   str_val      VARCHAR2(32767),
   num_val      NUMBER,
   raw_val      RAW(2000),
   tm_val       TIMESTAMP WITH TIME ZONE,
   urowid_val   UROWID,
   lraw_val     LONG RAW(32767),

   /* Constructors overloaded for different data types
    *
    * PARAMETERS  TO CONSTRUCTOR METHODS:
    *
    *   xxx_val   - Data value of the bind variable
    *   bmode     - Bind mode (IN|OUT)
    *                 0 - IN, 1 - OUT
    *   size      - Maximum size of data buffer in case of out bind
    *               Used oly for constructor methods of VARCHAR2, RAW, LONG RAW types
    */

   CONSTRUCTOR FUNCTION aq$_bnd(str_val VARCHAR2, bmode PLS_INTEGER DEFAULT 0, sz PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION aq$_bnd(num_val NUMBER, bmode PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION aq$_bnd(raw_val RAW, bmode PLS_INTEGER DEFAULT 0, sz PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION aq$_bnd(tm_val TIMESTAMP WITH TIME ZONE, bmode PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION aq$_bnd(urowid_val UROWID, bmode PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION aq$_bnd(lraw_val LONG RAW, bmode PLS_INTEGER DEFAULT 0, sz PLS_INTEGER DEFAULT 0) RETURN SELF AS RESULT

) NOT PERSISTABLE;
/

