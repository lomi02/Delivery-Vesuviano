create TYPE BODY aq$_bnd AS

CONSTRUCTOR FUNCTION aq$_bnd(str_val VARCHAR2, bmode PLS_INTEGER DEFAULT 0,
                             sz PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 0;
  SELF.bmode := bmode;
  SELF.sz := sz;
  SELF.str_val := str_val;
  RETURN;
END;

CONSTRUCTOR FUNCTION aq$_bnd(num_val NUMBER, bmode PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 1;
  SELF.bmode := bmode;
  SELF.sz := 0;
  SELF.num_val := num_val;
  RETURN;
END;

CONSTRUCTOR FUNCTION aq$_bnd(raw_val RAW, bmode PLS_INTEGER DEFAULT 0,
                             sz PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 2;
  SELF.bmode := bmode;
  SELF.sz := sz;
  SELF.raw_val := raw_val;
  RETURN;
END;

CONSTRUCTOR FUNCTION aq$_bnd(tm_val TIMESTAMP WITH TIME ZONE,
                             bmode PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 3;
  SELF.bmode := bmode;
  SELF.sz := 0;
  SELF.tm_val := tm_val;
  RETURN;
END;

CONSTRUCTOR FUNCTION aq$_bnd(urowid_val UROWID, bmode PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 4;
  SELF.bmode := bmode;
  SELF.sz := 0;
  SELF.urowid_val := urowid_val;
  RETURN;
END;

CONSTRUCTOR FUNCTION aq$_bnd(lraw_val LONG RAW, bmode PLS_INTEGER DEFAULT 0,
                             sz PLS_INTEGER DEFAULT 0)
                     RETURN SELF AS RESULT IS
BEGIN
  SELF.dtype := 5;
  SELF.bmode := bmode;
  SELF.sz := sz;
  SELF.lraw_val := lraw_val;
  RETURN;
END;

END;
/

