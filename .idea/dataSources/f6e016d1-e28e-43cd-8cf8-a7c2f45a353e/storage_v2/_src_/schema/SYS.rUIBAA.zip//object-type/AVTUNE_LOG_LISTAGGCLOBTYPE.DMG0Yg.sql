create TYPE AVTUNE_LOG_LISTAGGCLOBTYPE AS OBJECT (
  val CLOB,

  static function ODCIAggregateInitialize(
    actx IN OUT avtune_log_listaggclobtype) return number,

  member function ODCIAggregateIterate(
    self IN OUT avtune_log_listaggclobtype,
    nxtval CLOB) return number,

  member function ODCIAggregateMerge(
    self IN OUT avtune_log_listaggclobtype,
    ctx2 IN avtune_log_listaggclobtype) return number,

  member function ODCIAggregateTerminate(
    self IN avtune_log_listaggclobtype,
    ReturnValue OUT CLOB,
    flags IN number) return number
);
/

