create TYPE     BC_VOTE_T AS OBJECT
(
  TRANSACTION_ID       RAW(16),
  CHAIN#               NUMBER,
  CHAIN_GUID           RAW(16),
  PROMOTION_TS         TIMESTAMP,
  ERROR#               NUMBER,
  ERROR_MESSAGE        VARCHAR2(4000)
)
/

