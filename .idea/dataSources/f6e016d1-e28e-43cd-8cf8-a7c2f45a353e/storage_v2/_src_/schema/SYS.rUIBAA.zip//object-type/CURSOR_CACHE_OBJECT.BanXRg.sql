create type cursor_cache_object authid current_user
  under generic_plan_object
(sql_id       varchar2(13),
 child_number number,
 constructor function cursor_cache_object(sql_id varchar2,
                                          child_number number default null)
   return self as result,
 overriding member function get_plan_rows return sql_plan_table_type)
/

