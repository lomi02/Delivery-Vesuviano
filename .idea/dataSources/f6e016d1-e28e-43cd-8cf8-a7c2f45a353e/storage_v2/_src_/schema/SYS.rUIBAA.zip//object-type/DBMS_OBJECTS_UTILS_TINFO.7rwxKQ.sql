create type dbms_objects_utils_tinfo as object (
name       dbms_id,
objid      number,
toid       raw(16),
hashcode   raw(17),
version    number,
stime      date
);
/

