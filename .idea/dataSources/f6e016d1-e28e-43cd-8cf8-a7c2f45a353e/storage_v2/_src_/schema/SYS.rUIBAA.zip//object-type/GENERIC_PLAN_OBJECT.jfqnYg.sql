create type generic_plan_object authid current_user as object
(plan_source number,
 member function get_plan_rows return sql_plan_table_type) not final
/

