create TYPE JOBATTR FORCE AS OBJECT
(
  job_name              VARCHAR2(100),  /* 3*M_IDEN + 10 */
  attr_name             VARCHAR2(30),
  char_value            VARCHAR2(4000),
  char_value2           VARCHAR2(4000),
  args_value            SYS.JOBARG_ARRAY,
  num_value             NUMBER,
  timestamp_value       TIMESTAMP WITH TIME ZONE,
  interval_value        INTERVAL DAY TO SECOND,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     VARCHAR2,
    attr_value2         IN     VARCHAR2 DEFAULT NULL
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     NUMBER
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     BOOLEAN
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     TIMESTAMP WITH TIME ZONE
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     INTERVAL DAY TO SECOND
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2,
    attr_value          IN     SYS.JOBARG_ARRAY
  )
  RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION jobattr
  (
    job_name            IN     VARCHAR2,
    attr_name           IN     VARCHAR2
  )
  RETURN SELF AS RESULT
);
/

