create TYPE JSON_Array_T FORCE AUTHID CURRENT_USER
                       UNDER JSON_Element_T(
   dummy NUMBER,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn VARCHAR2)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn JDOM_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn CLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn BLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn JSON)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn BLOB,
                        format IN VARCHAR2) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, e JSON_ELEMENT_T)
                        RETURN SELF AS RESULT,

   -- override the 'parse' functions to directly RETURN Json_Array_T
   STATIC      FUNCTION  parse(jsn VARCHAR2 character set any_cs)
                         RETURN Json_Array_T,
   STATIC      FUNCTION  parse(jsn CLOB) RETURN Json_Array_T,
   STATIC      FUNCTION  parse(jsn BLOB) RETURN Json_Array_T,
   STATIC      FUNCTION  parse(jsn BLOB,format IN VARCHAR2) RETURN Json_Array_T,
   STATIC      FUNCTION  load(jsn JSON) RETURN Json_Array_T,

   MEMBER      FUNCTION  clone(self IN JSON_ARRAY_T) RETURN JSON_ARRAY_T,

   MEMBER      FUNCTION  get(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN JSON_Element_T,
   MEMBER      FUNCTION  get_String(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN VARCHAR2,
   MEMBER      FUNCTION  get_NString(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN NVARCHAR2,
   MEMBER      FUNCTION  get_Raw(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN RAW,
   MEMBER      FUNCTION  get_Number(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN NUMBER,
   MEMBER      FUNCTION  get_Double(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN BINARY_DOUBLE,
   MEMBER      FUNCTION  get_Float(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN BINARY_FLOAT,
   MEMBER      FUNCTION  get_Boolean(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN BOOLEAN,
   MEMBER      FUNCTION  get_Date(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN DATE,
   MEMBER      FUNCTION  get_Timestamp(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN TIMESTAMP,
   MEMBER      FUNCTION  get_TimestampTZ(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN TIMESTAMP WITH TIME ZONE,

   MEMBER      FUNCTION  get_Clob(self IN JSON_ARRAY_T, pos NUMBER) RETURN CLOB,
   MEMBER      PROCEDURE get_Clob(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  c IN OUT NOCOPY CLOB),
   MEMBER      FUNCTION  get_Blob(self IN JSON_ARRAY_T, pos NUMBER) RETURN BLOB,
   MEMBER      PROCEDURE get_Blob(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  b IN OUT NOCOPY BLOB),
   MEMBER      FUNCTION  get_NClob(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN NCLOB,
   MEMBER      PROCEDURE get_NClob(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                   n IN OUT NOCOPY NCLOB),
   MEMBER      FUNCTION  get_Json(self IN JSON_ARRAY_T, pos NUMBER) RETURN JSON,
   MEMBER      PROCEDURE get_Json(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  j IN OUT NOCOPY JSON),

 -- append at the end of array (no position needed)
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val VARCHAR2 character set any_cs),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val NUMBER),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val BOOLEAN),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val DATE),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val TIMESTAMP),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val BINARY_FLOAT),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val BINARY_DOUBLE),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val TIMESTAMP WITH TIME ZONE),
   MEMBER      PROCEDURE append(val CLOB),
   MEMBER      PROCEDURE append(val BLOB),
   MEMBER      PROCEDURE append(val JSON),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val JSON_Element_T),

   MEMBER      PROCEDURE append_Null(self IN OUT NOCOPY JSON_ARRAY_T),
   MEMBER      PROCEDURE append_NCLOB(self IN OUT NOCOPY JSON_ARRAY_T,
                                      val NCLOB),
   MEMBER      PROCEDURE append_Raw(self IN OUT NOCOPY JSON_ARRAY_T,
                                    val RAW),

   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val VARCHAR2 character set any_cs,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val NUMBER, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val BOOLEAN, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val DATE, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val TIMESTAMP, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val BINARY_FLOAT,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val TIMESTAMP WITH TIME ZONE,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val BINARY_DOUBLE,
                             overwrite BOOLEAN DEFAULT FALSE),

   -- ### Why don't these have "self' as a first argument?
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val CLOB,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val BLOB,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val JSON,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val JSON_Element_T,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put_Null(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put_Raw(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val RAW,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put_NCLOB(self IN OUT NOCOPY JSON_ARRAY_T,
                             pos NUMBER, val NCLOB,
                             overwrite BOOLEAN DEFAULT FALSE),

   MEMBER      PROCEDURE remove(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER),
   MEMBER      FUNCTION  get_Type(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN VARCHAR2
) FINAL
/

