create TYPE kupc$_api_ack FORCE UNDER kupc$_master_msg (
        errnum                   NUMBER,
        error                    kupc$_JobInfo,
        flags                    NUMBER,
        CONSTRUCTOR FUNCTION kupc$_api_ack(
                                en NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_api_ack(
                                en  NUMBER,
                                err kupc$_JobInfo
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_api_ack(
                                en  NUMBER,
                                flg NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_api_ack(
                                en  NUMBER,
                                err kupc$_JobInfo,
                                flg NUMBER
                                ) RETURN SELF AS RESULT
        )
/

