create TYPE kupc$_disk_file FORCE UNDER kupc$_master_msg (
                                file_number     NUMBER,
                                block_size      NUMBER,
                                flags           NUMBER,
                                allocated_size  NUMBER,
                                file_position   NUMBER,
                                file_max_size   NUMBER,
                                file_name       VARCHAR2(4000),
                                file_type       NUMBER,
                                user_directory  VARCHAR2(4000),
        CONSTRUCTOR FUNCTION kupc$_disk_file(
                                fno  NUMBER,
                                bsz  NUMBER,
                                flg  NUMBER,
                                asz  NUMBER,
                                fpo  NUMBER,
                                msz  NUMBER,
                                fnm  VARCHAR2,
                                typ  NUMBER,
                                dir  VARCHAR2
                                ) RETURN SELF AS RESULT
        )
/

