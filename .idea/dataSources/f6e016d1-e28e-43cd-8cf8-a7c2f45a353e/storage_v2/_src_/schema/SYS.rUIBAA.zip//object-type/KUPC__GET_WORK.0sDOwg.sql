create TYPE kupc$_get_work FORCE UNDER kupc$_worker_msg (
                                dummy         NUMBER,
        CONSTRUCTOR FUNCTION kupc$_get_work RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_get_work(
                                wid  NUMBER
                               ) RETURN SELF AS RESULT
        )
/

