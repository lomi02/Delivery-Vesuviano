create TYPE BODY kupc$_get_work wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
194 103
K9F7mXSCfDVllyqYXpid+TKyM3Awgw3QLcusfC9AkEIY/QT1f//fywnL5qnV3mSoWaTjUnBQ
BPBkILr1gvwGsu32u7W5uwhQqJHFLHBFkMZ3pCjqvyRMG7QTNmfFZdg7kWNrSxS+CTYNzZH8
8pGx1UzWYGHs3XBeMIUP8Hkw1IJW1ZuIDipsW7DN0QbAcxVVA+9R2JfW4O/mpCyL7mv0iW1d
xJZi75I+IyA2kQV0gerN/Cj9I6oIn5240RyYzUwm
/

