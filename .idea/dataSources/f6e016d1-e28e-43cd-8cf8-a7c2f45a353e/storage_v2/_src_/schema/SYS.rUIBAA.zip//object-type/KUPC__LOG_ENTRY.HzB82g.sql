create TYPE kupc$_log_entry FORCE UNDER kupc$_shadow_msg (
        log_entry_text          VARCHAR2(2000),
        logfile_only            NUMBER,
        CONSTRUCTOR FUNCTION kupc$_log_entry(
                                let  VARCHAR2,
                                lon  NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_log_entry(
                                qh   NUMBER,
                                let  VARCHAR2,
                                lon  NUMBER
                                ) RETURN SELF AS RESULT
        )
/

