create TYPE BODY kupc$_log_entry wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
2fb 158
UBHxdUM6OJJtBxBqv7eRlkY2y3kwg1X3AK5qfC9AWE7VSH1Q8vOepLp/tP9sSrhyOxDR111r
5nTKZ+dA+RKKRhVgH0V31kPQxjPHZL4P71q6/qXSOmFP28Gxxs6lmwg/pu6ZpgH6A5kYO9Yb
yAb/02gCDeyiCwXj2+JPG7m7ycj7YRU+Ymg0evCweKkV8lHa+v/dqFuAj7Mh+q0uEHx6gwx+
2qviVDqnx2NtBa+HTBJiJxK1uqLkG6eVEbhxyWhSIkPWWTWF3sVjND7BXFzXP1DoggRiWCLW
oT9oBO2bBCaHb7Vvi2Bqf5Cbm/GxrCeCUP0QvJ2Fcz0fH+waNw==
/

