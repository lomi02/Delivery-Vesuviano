create TYPE kupc$_par_con FORCE AS OBJECT (
   ind1            NUMBER,          /* 1st Parameter number */
   ok_value1       VARCHAR2(200),   /* Ok value for 1st parameter */
   ind2            NUMBER,          /* 2nd Parameter number */
   ok_value2       VARCHAR2(200),   /* Ok value for 2nd parameter */
   ok_mode         VARCHAR2(30))   /* Legal if in using this mode */
NOT PERSISTABLE
/

