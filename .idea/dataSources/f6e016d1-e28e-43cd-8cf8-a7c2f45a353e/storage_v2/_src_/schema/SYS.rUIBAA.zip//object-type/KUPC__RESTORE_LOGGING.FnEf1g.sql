create TYPE kupc$_restore_logging FORCE UNDER kupc$_master_msg (
                                seqno          NUMBER,
        CONSTRUCTOR FUNCTION kupc$_restore_logging(
                                sq   NUMBER
                               ) RETURN SELF AS RESULT
        )
/

