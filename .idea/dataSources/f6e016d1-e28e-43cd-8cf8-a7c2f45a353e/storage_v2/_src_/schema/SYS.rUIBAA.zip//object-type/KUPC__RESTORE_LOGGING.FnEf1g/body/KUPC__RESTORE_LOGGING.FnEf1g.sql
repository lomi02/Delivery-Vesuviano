create TYPE BODY kupc$_restore_logging wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
118 103
lSMsI/kkrBi+qDwhb553c7IqsMYwgwLQf8sVfHTpWMeeKKRw7qbDdCEyjBg83oaRfYn7XJTh
zMOP+RRith0wzsI7SbUgBSrnWP/aUzS5sNuuc4at3O2dSmq4vLK4cPvKKi0q3KN5DrgUeSa9
SuL39HiFOG28JfKNGjw3+UxoOajqFxH5wv18EZCocNgYL2xfisWYRpd8BP9JJyvfvC0Fcmtd
M9WJtaYpWYJhGu/ZzcJUeuDQibDmokzt++yJNSo=
/

