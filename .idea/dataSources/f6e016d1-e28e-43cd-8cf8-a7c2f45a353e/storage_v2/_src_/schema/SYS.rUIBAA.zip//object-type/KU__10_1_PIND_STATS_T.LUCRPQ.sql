create type ku$_10_1_pind_stats_t force as object
(
  obj_num           number,
  schema_obj        ku$_schemaobj_t,
  bobj_num          number,
  rowcnt            number,
  leafcnt           number,
  distkey           number,
  lblkkey           number,
  dblkkey           number,
  clufac            number,
  blevel            number,
  ind_flags         number,
  obj_flags         number,
  cache_info        ku$_cached_stats_t, -- cached stats information
  subpartition_list ku$_10_1_spind_stats_list_t
)
not persistable
/

