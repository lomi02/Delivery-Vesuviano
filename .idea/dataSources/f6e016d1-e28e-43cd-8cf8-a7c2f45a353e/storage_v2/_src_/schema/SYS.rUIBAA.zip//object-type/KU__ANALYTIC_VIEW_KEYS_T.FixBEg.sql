create type ku$_analytic_view_keys_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  key_col_name    varchar2(128),/* key column name(hcs_src_col$.src_col_name)*/
  ref_attr_name   varchar2(128),/* ref attr name (hcs_av_key$.ref_attr_name) */
  order_num       number                   /* order number of the key column */
)
not persistable
/

