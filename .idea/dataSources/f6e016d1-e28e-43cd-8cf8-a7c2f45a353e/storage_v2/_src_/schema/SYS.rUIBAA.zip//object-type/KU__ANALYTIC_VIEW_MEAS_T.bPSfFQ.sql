create type ku$_analytic_view_meas_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  meas_id         number,                               /* id of the measure */
  meas_type       number,                                    /* base or calc */
  name            varchar2(128),    /* measure name (hcs_av_meas$.meas_name) */
  src_col_name    varchar2(128),  /* column name (hcs_src_col$.src_col_name) */
  expr            clob,                     /* calculated measure expression */
  aggr            varchar2(128),        /* aggr_function (hcs_av_meas$.aggr) */
  aggr_fn         ku$_hcs_aggr_fn_t,                        /* aggr_function */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  order_num       number                      /* order number of the measure */
)
not persistable
/

