create type ku$_attr_dim_lvl_key_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  lvl_id         number,               /* level number within this dimension */
  key_id         number,                       /* lvl key id in the hier dim */
  attr_list      ku$_attr_dim_attr_list_t,                  /* list of attrs */
  order_num      number                       /* order number of the lvl key */
)
not persistable
/

