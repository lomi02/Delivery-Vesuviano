create type ku$_attr_dim_lvl_ordby_t force as object
(
  dim_obj#       number,                             /* obj# of the attr dim */
  lvl_id         number,                         /* level id in the attr dim */
  agg_func       varchar2(3),             /* aggregation function MIN or MAX */
  attribute_name varchar2(128),                            /* attribute name */
  order_num      number,                                     /* order number */
  criteria       varchar2(4),                       /* criteria: ASC or DESC */
  nulls_position varchar2(5)                          /* NULLS FIRST or LAST */
)
not persistable
/

