create type ku$_audit_context_t force as object (
  "USER"        varchar2(128),
  aud_context   ku$_audit_namespace_list_t)
not persistable
/

