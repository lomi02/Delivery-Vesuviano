create type ku$_audit_sys_priv_t force as object (
        PRIVILEGE     number,
        NAME          varchar2(128),
        PROPERTY      number          /* 0x01 = do not export this privilege */
                                      /* using sql statements */
  )
not persistable
/

