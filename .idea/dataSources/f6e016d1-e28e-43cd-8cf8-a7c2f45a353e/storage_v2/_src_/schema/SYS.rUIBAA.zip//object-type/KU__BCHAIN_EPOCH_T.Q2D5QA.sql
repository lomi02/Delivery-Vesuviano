create type ku$_bchain_epoch_t force as object
(
  obj_num               number,                             /* obj# of table */
  epoch_num             number,
  pdb_guid              raw(16),
  hash_algo_num         number,
  hash_version          number,
  reason_num            number,
  spare1                number,
  spare2                number,
  spare3                number,
  bchain_chain_list     ku$_bchain_chain_list_t
)
not persistable
/

