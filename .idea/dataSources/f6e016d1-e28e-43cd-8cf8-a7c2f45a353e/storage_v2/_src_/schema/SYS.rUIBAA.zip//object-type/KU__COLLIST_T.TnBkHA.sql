create type ku$_collist_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                              /* obj# */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  property      number,
  col_list      ku$_tab_column_list_t                     /* list of columns */
)
not persistable
/

