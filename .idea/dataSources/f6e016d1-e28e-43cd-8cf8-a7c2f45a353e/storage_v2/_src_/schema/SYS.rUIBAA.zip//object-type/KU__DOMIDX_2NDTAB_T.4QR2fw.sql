create type ku$_domidx_2ndtab_t force as object
(
  obj_num       number,                            /* object number of index */
  secobj_num    number,                 /* object number of secondary object */
  schema_obj    ku$_schemaobj_t                          /* secondary object */
)
not persistable
/

