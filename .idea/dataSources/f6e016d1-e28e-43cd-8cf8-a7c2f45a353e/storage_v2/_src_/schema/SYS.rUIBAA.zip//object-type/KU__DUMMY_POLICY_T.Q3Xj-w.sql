create type ku$_dummy_policy_t force as object
(
  vers_major               char(1),                  /* UDT major version # */
  vers_minor               char(1),                  /* UDT minor version # */
  name                     varchar2(128)                     /* Policy Name */
)
not persistable
/

