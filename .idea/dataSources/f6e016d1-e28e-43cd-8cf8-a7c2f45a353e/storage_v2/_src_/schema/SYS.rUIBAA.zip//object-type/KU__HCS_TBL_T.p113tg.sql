create type ku$_hcs_tbl_t force as object
(
  top_obj_num    number,            /* obj# of the hier dim or analytic view */
  tbl_id         number,                                  /* id of the table */
  owner          varchar2(128),       /* owner of the table (hcs_tbl$.owner) */
  owner_in_ddl   number(1),                      /* whether owner was in DDL */
  name           varchar2(128)          /* name of the table (hcs_tbl$.name) */
)
not persistable
/

