create type ku$_hier_join_path_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128), /* name (hcs_hier_join_path$.join_path_name) */
  order_num      number                        /* order number of attributes */
)
not persistable
/

