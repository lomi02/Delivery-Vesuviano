create type ku$_index_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                          /* object # */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  col_list      ku$_index_col_list_t,               /* list of index columns */
  ts_name       varchar2(128),                                 /* tablespace */
  blocksize     number,                            /* size of block in bytes */
  storage       ku$_storage_t,                                    /* storage */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  dataobj_num   number,                          /* data layer object number */
  base_obj_num  number,                                     /* base object # */
  base_obj      ku$_schemaobj_t,                              /* base object */
  anc_obj       ku$_schemaobj_t,           /* Ancestor object - if available */
  indmethod_num number,             /* object # for cooperative index method */
  indtype_name  varchar2(128),                             /* indextype name */
  indtype_owner varchar2(128),                            /* indextype owner */
  secobjs       ku$_domidx_2ndtab_list_t,                /* secondary tables */
  plsql_code    ku$_domidx_plsql_t,               /* domain index plsql code */
  jijoin_tabs   ku$_jijoin_table_list_t, /* jijoin tables if bitmap join idx */
  jijoin        ku$_jijoin_list_t,       /* jijoin data if bitmap join index */
  cols          number,                                 /* number of columns */
  pct_free      number,          /* minimum free space percentage in a block */
  initrans      number,                     /* initial number of transaction */
  maxtrans      number,                    /* maximum number of transactions */
  pct_thres     number,           /* iot overflow threshold, null if not iot */
  type_num      number,                       /* what kind of index is this? */
  flags         number,                                     /* mutable flags */
  flags2        number,                                     /* flags <63:32> */
  property      number,             /* immutable flags for life of the index */
  blevel        number,                                       /* btree level */
  leafcnt       number,                                  /* # of leaf blocks */
  distkey       number,                                   /* # distinct keys */
  lblkkey       number,                          /* avg # of leaf blocks/key */
  dblkkey       number,                          /* avg # of data blocks/key */
  clufac        number,                                 /* clustering factor */
  analyzetime   varchar2(19),                /* timestamp when last analyzed */
  samplesize    number,                 /* number of rows sampled by Analyze */
  rowcnt        number,                       /* number of rows in the index */
  intcols       number,                        /* number of internal columns */
  degree        number,           /* # of parallel query slaves per instance */
  instances     number,             /* # of OPS instances for parallel query */
  trunccnt      number,                        /* re-used for iots 'inclcol' */
  numcolsdep    number,         /* number of columns depended on, >= intcols */
  numkeycols    number,             /* # of key columns in compressed prefix */
  part_obj      ku$_ind_partobj_t,                /* null if not partitioned */
  spare3        number,
  spare4        varchar2(1000),     /* used for parameter str for domain idx */
  spare5        varchar2(1000),
  spare6        varchar2(19),
  for_pkoid     number,                     /* 1 = enabled index for a pkoid */
  for_refpar    number,      /* 1 = used for ref partition parent constraint */
  oid_or_setid  number,        /* !0 = hidden unique index on OID column (1) */
                                  /* or nested tbl column's SETID column (2) */
  base_property number,             /* property flags of base object (table) */
  base_property2 number,
  base_property3 number,
  /* The following fields are used only for {sub}partition promotion (shard) */
  ind_part      ku$_ind_part_t,                /* p2t - index partition info */
  ind_subpart   ku$_ind_part_t,            /* sp2t - index subpartition info */
  tabpart_obj_num number,    /* obj_num of correspoding table {sub}partition */
  ind_part_name varchar(128),  /* index partition for domain_index_partition */
  ilm_policies  ku$_ilm_policy_list_t                       /*  ilm policies */
)
not persistable
/

