create type ku$_m_view_h_t force as object
(
  vers_major        char(1),                          /* UDT major version # */
  vers_minor        char(1),                          /* UDT minor version # */
  obj_num           number,                    /* object number of the mview */
  sowner            varchar2(128),                      /* Owner of snapshot */
  vname             varchar2(128),                       /* name of snapshot */
  mview             ku$_m_view_t,
  mview_tab         ku$_table_t,
  mview_idx_list    ku$_index_list_t
)
not persistable
/

