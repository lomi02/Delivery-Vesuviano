create type ku$_ntpart_parent_t force as object
(
  obj_num       number,                                /* obj# of base table */
  part_num      number,                     /* part# of base table partition */
  nts           ku$_ntpart_list_t                 /* nested table partitions */
)
not persistable
/

