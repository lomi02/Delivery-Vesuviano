create type ku$_procact_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  tag           varchar2(128),                             /* procedural tag */
  cmnt          varchar2(2000),                        /* procedural comment */
  package       varchar2(128),                         /* procedural package */
  schema        varchar2(128),                             /* package schema */
  level_num     number,                                             /* level */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
not persistable
/

