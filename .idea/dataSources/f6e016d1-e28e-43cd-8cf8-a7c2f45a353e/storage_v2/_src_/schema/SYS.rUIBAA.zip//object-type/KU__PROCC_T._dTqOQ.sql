create type ku$_procc_t force as object
( obj_num        number,                 /* spec/body object number */
  procedure_num   number,                  /* procedure# or position */
  entrypoint_num number)                 /* entrypoint table entry# */
not persistable
/

