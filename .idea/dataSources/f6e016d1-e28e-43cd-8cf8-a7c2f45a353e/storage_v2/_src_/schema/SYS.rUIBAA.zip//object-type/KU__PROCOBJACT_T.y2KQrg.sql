create type ku$_procobjact_t force as object
(
  package       varchar2(128),                    /* procedural package name */
  schema        varchar2(128)                              /* package schema */
)
not persistable
/

