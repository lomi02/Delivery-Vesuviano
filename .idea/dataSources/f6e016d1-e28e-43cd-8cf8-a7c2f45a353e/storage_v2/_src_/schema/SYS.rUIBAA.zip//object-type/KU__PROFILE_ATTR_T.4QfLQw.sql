create type ku$_profile_attr_t force as object
(
  profile_id    number,                                       /* profile id  */
  resource_num  number,                                        /* resource id*/
  resname       varchar2(128),                              /* resource name */
  type_num              number,                                      /* type */
  limit_num             number                                      /* limit */
)
not persistable
/

