create type ku$_rollback_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  us_num        number,                               /* undo segment number */
  name          varchar2(128),                      /* rollback segment name */
  user_num      number,                /* Owner: 0 = SYS(PRIVATE) 1 = PUBLIC */
  optimal       number,                                     /* optimal value */
  iniexts       number,                               /* initial extent size */
  minexts       number,                         /* minimum number of extents */
  maxexts       number,                         /* maximum number of extents */
  extsize       number,                          /* current next extent size */
                                           /* zero for bitmapped tablespaces */
  tablespace    ku$_tablespace_t                   /* tablespace information */
)
not persistable
/

