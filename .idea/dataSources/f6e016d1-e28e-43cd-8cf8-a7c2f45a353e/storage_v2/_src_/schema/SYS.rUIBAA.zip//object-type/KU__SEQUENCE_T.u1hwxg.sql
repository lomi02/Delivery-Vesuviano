create type ku$_sequence_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                            /* sequence object number */
  schema_obj    ku$_schemaobj_t,                   /* sequence schema object */
  incre         number,                     /* the sequence number increment */
  minvalue      varchar2(28),                   /* minimum value of sequence */
  maxvalue      varchar2(28),                   /* maximum value of sequence */
  cycle         number,                               /* 0 = FALSE, 1 = TRUE */
  seq_order     number,                               /* 0 = FALSE, 1 = TRUE */
  cache         number,                          /* how many to cache in sga */
  highwater     varchar2(29),                        /* disk high water mark */
  seq_audit     varchar2(38),                            /* auditing options */
  flags         number                               /* 0x08 LOGICAL STANDBY */
                                                           /* 0x16 [NO]SCALE */
                                       /* 0x2048 [NO]EXTEND (only for SCALE) */
)
not persistable
/

