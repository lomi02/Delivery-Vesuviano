create type ku$_sysgrant_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  privilege     number,                       /* numeric privilege type code */
  grantee       varchar2(128),
  privname      varchar2(128),
  sequence      number,
  wgo           number,
  user_spare1   number)
not persistable
/

