create type ku$_table_objnum_t force as object
(
  obj_num       number,                                              /* obj# */
  objnum_name   varchar(128),                 /* name associated with objnum */
  table_type    varchar2(1),         /* 'T' = base table, 'N' = nested table */
                                  /* 'X' = nested table belonging to XMLtype */
  property      number,                                    /* table property */
  property2     number,                                    /* table property */
  ts_num        number,                                          /* tab$.ts# */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  base_obj      ku$_schemaobj_t,            /* base object (if nested table) */
  spare7        number                                       /* table spare7 */
)
not persistable
/

