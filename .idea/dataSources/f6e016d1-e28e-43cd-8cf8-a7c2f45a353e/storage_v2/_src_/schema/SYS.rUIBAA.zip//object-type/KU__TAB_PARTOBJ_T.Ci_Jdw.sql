create type ku$_tab_partobj_t force as object
(
  obj_num       number,                         /* obj# of partitioned table */
  partobj       ku$_partobj_t,                     /* Base partitioning info */
  partcols      ku$_part_col_list_t,         /* list of partitioning columns */
  subpartcols   ku$_part_col_list_t,      /* list of subpartitioning columns */
  part_list     ku$_tab_part_list_t,                 /* table partition list */
  compart_list  ku$_tab_compart_list_t,    /* table composite partition list */
  tsubparts     ku$_tab_tsubpart_list_t        /* template subpartition list */
)
not persistable
/

