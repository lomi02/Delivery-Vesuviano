create TYPE     ku$_taction_t FORCE AS OBJECT
(
  text  varchar2(32000)
)
NOT PERSISTABLE
/

