create type ku$_tbs_ilm_policy_t force as object
(
  ts_num        number,                      /* tablespace identifier number */
  name          varchar2(128),                         /* name of tablespace */
  ilm_policies  ku$_ilm_policy_list_t                /* default ilm policies */
)
not persistable
/

