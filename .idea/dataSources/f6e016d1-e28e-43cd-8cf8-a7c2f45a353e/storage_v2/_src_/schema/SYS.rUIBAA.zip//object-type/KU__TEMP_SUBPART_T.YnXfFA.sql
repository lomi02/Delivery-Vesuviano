create type ku$_temp_subpart_t force as object
(
  obj_num       number,                             /* obj# of subpartition */
  ts_num        number,
  pobj_num      number,     /* object# of partition containing subpartition */
  subpartno     number,
  bhiboundval   blob
)
not persistable
/

