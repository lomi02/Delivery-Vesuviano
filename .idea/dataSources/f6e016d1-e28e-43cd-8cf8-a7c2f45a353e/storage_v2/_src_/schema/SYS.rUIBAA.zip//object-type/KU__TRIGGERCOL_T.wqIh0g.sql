create type ku$_triggercol_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                   /* obj# of trigger */
  col_num       number,                                     /* column number */
  type_num      number,                          /* type of column reference */
     /* 6 = OLD IN-ARG, 5 = NEW IN-ARG, 9 = NEW OUT-VAR, 13 = NEW IN/OUT-VAR */
                                                  /* 0x14 = 20 PARENT IN-ARG */
  position_num  number,                               /* position in trigger */
  intcol_num    number,                            /* internal column number */
  name          varchar2(128),                             /* name of column */
  attrname      varchar2(4000) /* name of type attr. column: null if != type */
)
not persistable
/

