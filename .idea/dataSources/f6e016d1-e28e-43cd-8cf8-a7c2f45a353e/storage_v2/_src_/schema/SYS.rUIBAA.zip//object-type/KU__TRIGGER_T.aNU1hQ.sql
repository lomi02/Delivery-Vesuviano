create type ku$_trigger_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                   /* obj# of trigger */
  schema_obj    ku$_schemaobj_t,                 /* object info. for trigger */
  base_obj_num  number,                                  /* obj# of base obj */
  base_obj_schema varchar2(128),        /* schema name - for schema triggers */
  base_obj      ku$_schemaobj_t,    /* object info. for base obj: May be null*/
  tab_property2 number,       /* table property bits if base object is table */
  xdb_generated number,                     /* 1 if xdb generated, else NULL */
  type_num      number,                                     /* trigger type: */
   /* 0=before table, 1=before row, 2=after table, 3=after row, 4=instead of */
  act_update    number,                                    /* fire on update */
  act_insert    number,                                    /* fire on insert */
  act_delete    number,                                    /* fire on delete */
  refoldname    varchar2(128),                       /* old referencing name */
  refnewname    varchar2(128),                       /* new referencing name */
  defschema_exst number,       /* Flag to identifify schema existance in def */
  definition    varchar2(4000),                /* text of trigger definition */
  parsed_def    ku$_source_t,          /* definition with name offset/length */
  whenclause    varchar2(4000),                       /* text of when clause */
  body          clob,                                /* text of trigger body */
  body_vcnt     ku$_vcnt,                            /* text of trigger body */
  body_len      number,                            /* length of trigger body */
  enabled       number,                         /* 0 = DISABLED, 1 = ENABLED */
  property      number,                                /* trigger properties */
                                                /* 0x01 = baseobject is view */
                                                /* 0x02 = Call style trigger */
                                                /* 0x04 = Java Trigger       */
                                            /* 0x08 = baseobject is database */
                                              /* 0x10 = baseobject is schema */
                                              /* 0x20 = Nested table trigger */
                                                 /* 0x40 = baseobject is IOT */
                              /* 0x80 = fire-once-only (fire one place only) */
  sys_evts      number,                         /* system events for trigger */
  nttrigcol     number,               /* intcol# on which trigger is defined */
  nttrigatt     number,                    /* attribute number within column */
  ntname        varchar2(128),                  /* nested table trigger name */
  refprtname    varchar2(128),                    /* PARENT referencing name */
  actionlineno  number,                         /* action line number offset */
  cols          ku$_triggercol_list_t,      /* columns referenced by trigger */
  trigdeps      ku$_triggerdep_list_t,               /* trigger dependencies */
  compiler_info ku$_switch_compiler_t
)
not persistable
/

