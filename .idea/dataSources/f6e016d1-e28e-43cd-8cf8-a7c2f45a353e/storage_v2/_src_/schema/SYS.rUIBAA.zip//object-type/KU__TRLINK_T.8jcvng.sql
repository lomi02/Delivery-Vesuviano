create type ku$_trlink_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  name          varchar2(132),                          /* trusted link name */
  function      varchar2(45),                                    /* function */
  type          number                               /* type of trusted link */
)
not persistable
/

