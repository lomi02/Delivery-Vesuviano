create type ku$_user_editioning_t force as object
(
  user_id   number,
  type_name varchar2(128)
)
not persistable
/

