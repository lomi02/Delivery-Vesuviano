create type ku$_user_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_id       number,                                          /* user id  */
  name          varchar2(128),                               /* name of user */
  type_num      number ,                               /* 0 = role, 1 = user */
  password      varchar2(128),                         /* encrypted password */
  datats        varchar2(128),                   /* user default tablespace  */
  tempts        varchar2(128),    /* default tablespace for temporary tables */
  ltempts       varchar2(128),                      /* local temp tablespace */
  ctime         varchar2(19),                  /* user account creation time */
  ptime         varchar2(19),                        /* password change time */
  exptime       varchar2(19),             /* actual password expiration time */
  ltime         varchar2(19),                 /* time when account is locked */
  profnum       number,                                 /* resource profile# */
  profname      varchar2(128),                              /* profile name  */
  user_audit    varchar2(128),                         /* user audit options */
  defrole       number,                           /* default role indicator: */
  defgrp_num    number,                                /* default undo group */
  defgrp_seq_num   number,             /* global sequence number for the grp */
  astatus       number,                             /* status of the account */
  astatus_12    number,              /* status of the account for version 12 */
  lcount        number,                    /* count of failed login attempts */
  defschclass   varchar2(128),                     /* initial consumer group */
  ext_username  varchar2(4000),                         /* external username */
  spare1        number,
  spare2        number,
  spare3        varchar2(128),                     /* Default collation name */
  spare4        varchar2(1000),           /* indentfier with only version 10 */
  spare4_12     varchar2(1000),     /* indentfier with version 10, 11 and 12 */
  spare5        varchar2(1000),
  spare6        varchar2(19),
  edn_types     ku$_user_editioning_list_t         /* editions-enabled types */
)
not persistable
/

