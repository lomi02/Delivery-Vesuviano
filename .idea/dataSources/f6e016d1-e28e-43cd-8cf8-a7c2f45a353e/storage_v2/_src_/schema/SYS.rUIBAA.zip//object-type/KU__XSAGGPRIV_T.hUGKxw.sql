create type ku$_xsaggpriv_t force as object
(
  vers_major     char(1),                             /* UDT major version # */
  vers_minor     char(1),                             /* UDT minor version # */
  scid           number,                                /* Security Class id */
  aggr_privid    number,
  implied_privid number,
  name           varchar2(128),
  owner_name     varchar2(128)
)
not persistable
/

