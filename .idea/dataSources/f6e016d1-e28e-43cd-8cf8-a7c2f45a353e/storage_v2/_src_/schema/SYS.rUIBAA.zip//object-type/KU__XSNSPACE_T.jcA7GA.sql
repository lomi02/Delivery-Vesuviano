create type ku$_xsnspace_t force as object
(
  vers_major     char(1),                            /* UDT major version # */
  vers_minor     char(1),                            /* UDT minor version # */
  xs_obj         ku$_xsobj_t,
  ns_num         number,
  aclid          number,
  handler_schema varchar2(128),                      /* handler schema name */
  handler_pkg    varchar2(128),                     /* handler package name */
  handler_func   varchar2(128),                    /* handler function name */
  ctime          timestamp,
  mtime          timestamp,
  description    varchar2(4000),
  attr_list      ku$_xsnstmpl_attr_list_t
)
not persistable
/

