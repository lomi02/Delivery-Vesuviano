create type ku$_xsolap_policy_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  olap_schema   varchar2(128),                           /* OLAP schema_name */
  logical_name  varchar2(128),                /* xs$olap_policy.logical_name */
  owner_name    varchar2(128),               /* xs$olap_policy.policy_schema */
  name          varchar2(128),                 /* xs$olap_policy.policy_name */
  enable        number
)
not persistable
/

