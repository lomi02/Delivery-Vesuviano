create type ku$_xssclass_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  scid          number,                                 /* Security Class id */
  ctime         timestamp,
  mtime         timestamp,
  description   varchar2(4000),
  xs_obj        ku$_xsobj_t,                               /* XS object info */
  priv_list     ku$_xspriv_list_t,
  parent_list   ku$_xssecclsh_list_t
)
not persistable
/

