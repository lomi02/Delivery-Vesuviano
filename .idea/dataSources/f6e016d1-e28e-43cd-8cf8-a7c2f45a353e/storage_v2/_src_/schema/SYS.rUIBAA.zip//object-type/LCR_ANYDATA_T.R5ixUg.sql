create TYPE       "LCR_ANYDATA_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","varchar2" CLOB,"char" CLOB,"nchar" NCLOB,"nvarchar2" NCLOB,"number" NUMBER,"raw" BLOB,"date" "LCR_DATETIME_FORMAT_T","timestamp" "LCR_DATETIME_FORMAT_T","timestamp_tz" "LCR_DATETIME_FORMAT_T","timestamp_ltz" "LCR_DATETIME_FORMAT_T","interval_ym" VARCHAR2(4000 CHAR),"interval_ds" VARCHAR2(4000 CHAR),"urowid" VARCHAR2(4000 CHAR))NOT FINAL INSTANTIABLE
/

