create type objrank FORCE is object(
                             rank number,
                             obj# number)
/

