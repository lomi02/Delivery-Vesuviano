create TYPE ODCIColInfo FORCE
                                         AS OBJECT
(
  TableSchema          VARCHAR2(130),
  TableName            VARCHAR2(130),
  ColName              VARCHAR2(4000),
  ColTypeName          VARCHAR2(130),
  ColTypeSchema        VARCHAR2(130),
  TablePartition       VARCHAR2(130),
  ColInfoFlags         NUMBER,
  OrderByPosition      NUMBER,
  TablePartitionIden   NUMBER,
  TablePartitionTotal  NUMBER
);
/

