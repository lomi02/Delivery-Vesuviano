create TYPE ODCIIndexInfo FORCE
                                         AS OBJECT
(
  IndexSchema         VARCHAR2(130),
  IndexName           VARCHAR2(130),
  IndexCols           ODCIColInfoList,
  IndexPartition      VARCHAR2(130),
  IndexInfoFlags      NUMBER,
  IndexParaDegree     NUMBER,
  IndexPartitionIden  NUMBER,
  IndexPartitionTotal NUMBER
);
/

