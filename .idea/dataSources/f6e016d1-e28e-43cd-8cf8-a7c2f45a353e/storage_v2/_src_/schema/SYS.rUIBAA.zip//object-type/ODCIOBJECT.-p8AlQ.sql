create TYPE ODCIObject FORCE
                                         AS OBJECT
(
  ObjectSchema VARCHAR2(130),
  ObjectName   VARCHAR2(130)
);
/

