create TYPE ODCIStatsOptions FORCE
                                         AS OBJECT
(
  Sample          NUMBER,
  Options         NUMBER,
  Flags           NUMBER
);
/

