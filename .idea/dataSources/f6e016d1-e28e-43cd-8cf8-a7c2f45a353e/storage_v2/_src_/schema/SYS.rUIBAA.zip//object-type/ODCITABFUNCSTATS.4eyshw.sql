create TYPE ODCITabFuncStats FORCE
                                         AS OBJECT
(
  num_rows NUMBER
);
/

