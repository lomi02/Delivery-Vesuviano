create type OLAPImpl_t wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
8f be
EIRG/2mT9NgI9iSPGvYFDdiol58wg+nw7Z4VfI5gkE6Ov341bpncePoCYSGhviQR6DSprNa7
0CbLQQjPLHY72jUxuA9BZIASHez/DEZwR4kNWC8dno6dCWl4V6ZY9z5hDr+m1AV88MFItz6S
8LySICqnmi3vXNF1CjOPf/Qbee31yGJC4HiHrixLge/+
/

