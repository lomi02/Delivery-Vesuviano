create TYPE     re$nv_list
                                                                      
AS OBJECT
( actx_list sys.re$nv_array,
  MEMBER PROCEDURE add_pair(name IN varchar2, value IN sys.anydata),
  MEMBER PROCEDURE remove_pair(name IN varchar2),
  MEMBER FUNCTION  get_value(name IN varchar2) RETURN sys.anydata,
  MEMBER FUNCTION  get_all_names RETURN sys.re$name_array
)
/

