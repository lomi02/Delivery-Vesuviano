create TYPE     re$nv_node
                                                                      
AS OBJECT
( nvn_name       varchar2(30),
  nvn_value      sys.anydata)
 alter type     re$nv_node modify attribute
           (nvn_name varchar2(128)) CASCADE
/

