create TYPE     re$table_value
AS OBJECT
(table_alias             varchar2(32),
 table_rowid             varchar2(18))
 alter type     re$table_value modify attribute
           (table_alias varchar2(130)) CASCADE
/

