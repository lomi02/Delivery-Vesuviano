create TYPE     re$variable_value
AS OBJECT
(variable_name           varchar2(32),
 variable_data           sys.anydata)
 alter type     re$variable_value modify attribute
           (variable_name varchar2(130)) CASCADE
/

