create type     SCHEDULER$_BATCHERR_VIEW_T as object
(
  currow     number,
  done       number,

  static function ODCITablePrepare
                    (sctx OUT sys.SCHEDULER$_BATCHERR_VIEW_T,
                     tf IN SYS.ODCITabFuncInfo)
    return number,

  static function ODCITableStart
                    (sctx IN OUT sys.SCHEDULER$_BATCHERR_VIEW_T)
    return number,

  member function ODCITableFetch
                    (self IN OUT sys.SCHEDULER$_BATCHERR_VIEW_T,
                     nrows IN number,
                     objset OUT sys.SCHEDULER$_BATCHERR_ARRAY)
    return number,

  member function ODCITableClose
                    (self IN sys.SCHEDULER$_BATCHERR_VIEW_T)
    return number
);
/

