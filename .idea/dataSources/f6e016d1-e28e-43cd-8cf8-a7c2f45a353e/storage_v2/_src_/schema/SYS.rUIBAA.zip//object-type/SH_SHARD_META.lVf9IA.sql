create type     sh$shard_meta force as object(
 queue number,
 shard number,
 enqueue_instance number,
 preferred_owner_instance number,
 owner_instance number,
 flags number,
 base_queue number,
 delay_shard number,
CONSTRUCTOR FUNCTION sh$shard_meta (queue number,
 shard number,
 enqueue_instance number,
 preferred_owner_instance number,
 owner_instance number,
 flags number)
  RETURN SELF AS RESULT
 );
/

