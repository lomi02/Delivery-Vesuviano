create TYPE BODY sh$shard_meta AS
CONSTRUCTOR FUNCTION sh$shard_meta (queue number,
 shard number,
 enqueue_instance number,
 preferred_owner_instance number,
 owner_instance number,
 flags number)
  RETURN SELF AS RESULT
IS
  BEGIN
    self.queue := queue;
    self.shard := shard;
    self.enqueue_instance := enqueue_instance;
    self.preferred_owner_instance := preferred_owner_instance;
    self.owner_instance := owner_instance;
    self.flags := flags;
    self.base_queue := NULL;
    self.delay_shard := NULL;
      return;
  END;

END;
/

