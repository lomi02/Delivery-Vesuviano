create type       "SYS_YOID0000017298$"              as object( "SYS_NC00001$" NUMBER)
/

