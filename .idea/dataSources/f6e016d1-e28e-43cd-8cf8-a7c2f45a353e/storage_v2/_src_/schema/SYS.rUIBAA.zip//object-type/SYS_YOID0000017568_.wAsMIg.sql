create type       "SYS_YOID0000017568$"              as object( "SYS_NC00001$" NUMBER, "SYS_NC00002$" VARCHAR2(132 BYTE), "SYS_NC00003$" NUMBER)
/

