create type       "SYS_YOID0000017597$"              as object( "SYS_NC00001$" NUMBER)
/

