create type       "SYS_YOID0000018389$"              as object( "SYS_NC00001$" NUMBER)
/

