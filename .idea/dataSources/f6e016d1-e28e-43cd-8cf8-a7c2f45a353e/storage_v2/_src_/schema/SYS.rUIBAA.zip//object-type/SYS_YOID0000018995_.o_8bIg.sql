create type       "SYS_YOID0000018995$"              as object( "SYS_NC00001$" NUMBER)
/

