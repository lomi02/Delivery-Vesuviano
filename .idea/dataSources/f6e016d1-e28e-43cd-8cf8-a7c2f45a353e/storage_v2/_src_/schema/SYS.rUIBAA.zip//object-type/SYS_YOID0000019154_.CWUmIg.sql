create type       "SYS_YOID0000019154$"              as object( "SYS_NC00001$" NUMBER)
/

