create type       "SYS_YOID0000019362$"              as object( "SYS_NC00001$" NUMBER)
/

