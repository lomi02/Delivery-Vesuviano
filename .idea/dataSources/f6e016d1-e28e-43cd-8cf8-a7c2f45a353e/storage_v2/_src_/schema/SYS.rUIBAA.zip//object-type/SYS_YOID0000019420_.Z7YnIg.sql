create type       "SYS_YOID0000019420$"              as object( "SYS_NC00001$" NUMBER)
/

