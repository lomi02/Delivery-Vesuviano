create type       "SYS_YOID0000019538$"              as object( "SYS_NC00001$" VARCHAR2(1))
/

