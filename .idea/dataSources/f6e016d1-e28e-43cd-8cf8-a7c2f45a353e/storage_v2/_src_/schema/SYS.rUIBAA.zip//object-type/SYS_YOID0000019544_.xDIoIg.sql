create type       "SYS_YOID0000019544$"              as object( "SYS_NC00001$" NUMBER)
/

