create type       "SYS_YOID0000019748$"              as object( "SYS_NC00001$" NUMBER)
/

