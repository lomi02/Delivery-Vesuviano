create type urifacelem force                                       
  as object
(
  prefix      varchar2(128),
  schemaname  varchar2(128),
  typename    varchar2(128),
  ignorecase  char(1),
  stripprefix char(1)
);
/

