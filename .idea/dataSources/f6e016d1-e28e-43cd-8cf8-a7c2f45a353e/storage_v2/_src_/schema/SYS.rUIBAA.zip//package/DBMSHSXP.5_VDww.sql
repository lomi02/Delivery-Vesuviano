create PACKAGE dbmshsxp AUTHID CURRENT_USER AS

  -- Support log based replication (proj 17779)
  -- The possible categories for SVRMAN are:
  --
  --       A) READ_ONLY:
  --          Procedure does not need to be replicated as it does not
  --          generate any UNDO/REDO. (e.g. Reporting APIs, Import/Export).
  --
  --       B) NONE:
  --          Any procedure that performs DDL/DML but the DML/DDL is either
  --          replicated naturally by log-miner (not in SYS schema) or the DML
  --          is to SYS schema, but it is OK not to replicate it.
  --          (e.g., ADDM execution, AWR snapshot, STS creation).
  --
  --       C) UNSUPPORTED:
  --          Any procedure that produces DML/DDL that must be replicated to
  --          the stand-by, but can not be replicated by running the same
  --          procedure on the stand-by RDBMS.
  --
  -- By default, SVRMAN procedures will follow the NONE semantics if they
  -- produce DML and READ_ONLY if they do not.
  -- Any exception must be declared at the END of the specific procedure.
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, READ_ONLY);

  -- Generate PL/SQL for procedural actions
  FUNCTION system_info_exp(
    prepost       IN  PLS_INTEGER,
    connectstring OUT VARCHAR2,
    version       IN  VARCHAR2,
    new_block     OUT PLS_INTEGER)
  RETURN VARCHAR2;

END dbmshsxp;
/

