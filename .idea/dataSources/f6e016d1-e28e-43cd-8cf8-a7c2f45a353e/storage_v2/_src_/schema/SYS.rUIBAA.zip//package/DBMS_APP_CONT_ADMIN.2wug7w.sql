create PACKAGE dbms_app_cont_admin AS

  ------------
  --  OVERVIEW
  --
  --  This package provides a collection dba level admin operations in
  --  relation to Application Continuity

  -- Planned Maintenance test types
  SQL_TEST        CONSTANT BINARY_INTEGER := 0;
  PING_TEST       CONSTANT BINARY_INTEGER := 1;
  ENDREQUEST_TEST CONSTANT BINARY_INTEGER := 2;
  BEGINREQUEST_TEST CONSTANT BINARY_INTEGER :=3;

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED);

  PROCEDURE add_sql_connection_test(connection_test IN VARCHAR2,
                                    service_name    IN VARCHAR2 DEFAULT '');
  -- This procedure can be used to add a sql connection test with or without a
  -- service specifier. These tests will be used by the server to drain
  -- sessions during planned maintenance.
  --
  -- Input parameters(s):
  --    connection_test - SQL rule to be added
  --    service_name    - Optional service name qualifier.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE delete_sql_connection_test(connection_test IN varchar2,
                                       service_name    IN varchar2 DEFAULT '');
  -- This procedure can be used to delete a sql connection test with or without
  -- a service specifier. Only custom tests can be deleted.
  --
  -- Input parameters(s):
  --    connection_test - SQL rule to be added
  --    service_name    - Optional service name qualifier.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_connection_test(connection_test_type IN BINARY_INTEGER,
                                   connection_test      IN varchar2 DEFAULT '',
                                   service_name        IN varchar2 DEFAULT '');
  -- This procedure can be used to enable a connection test. Connection test
  -- should be present in the table.
  --
  -- Input parameters(s):
  --    connection_test_type - Required field to indicate the type of test
  --                           to be disabled. Valid values are
  --                           dbms_app_cont_admin.SQL_TEST,
  --                           dbms_app_cont_admin.PING_TEST,
  --                           dbms_app_cont_admin.ENDREQUEST_TEST,
  --                           dbms_app_cont_admin.BEGINREQUEST_TEST.
  --    connection_test      - SQL to be disabled. Should be NULL('') string
  --                           for non-SQL connection tests.
  --    service_name         - Optional service name qualifier.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE disable_connection_test(connection_test_type IN BINARY_INTEGER,
                                    connection_test    IN varchar2 DEFAULT '',
                                    service_name       IN varchar2 DEFAULT '');
  -- This procedure should be used to disable existing connection tests. It
  -- can also be used to disable a particular (SQL, SVC) pair if the
  -- corresponding SQL is already across all services.
  --
  -- Input Parameter(s):
  --    connection_test_type - Required field to indicate the type of test
  --                           to be disabled. Valid values -
  --                           dbms_app_cont_admin.SQL_TEST,
  --                           dbms_app_cont_admin.PING_TEST,
  --                           dbms_app_cont_admin.ENDREQUEST_TEST,
  --                           dbms_app_cont_admin.BEGINREQUEST_TEST.
  --    connection_test      - SQL to be disabled. Should be NULL('') string
  --                           other connection tests.
  --    service_name         - Optional service name qualifier.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_AC(service_name     IN VARCHAR2,
                      failover_restore IN VARCHAR2 DEFAULT 'LEVEL1',
                      replay_initiation_timeout IN BINARY_INTEGER DEFAULT NULL);
  -- This procedure enables Application Continuity (AC) on the given service
  --
  -- Input Parameter(s):
  --    service_name     - Service name
  --    failover_restore - 'NONE' or 'LEVEL1'
  --    replay_initiation_timeout - replay initiation timeout
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_TAC(service_name     IN VARCHAR2,
                       failover_restore IN VARCHAR2 DEFAULT 'AUTO',
                       replay_initiation_timeout IN BINARY_INTEGER
                                                     DEFAULT NULL);
  -- This procedure enables Transparent Application Continuity (TAC) on the
  -- given service
  --
  -- Input Parameter(s):
  --    service_name     - Service name
  --    failover_restore - 'AUTO'
  --    replay_initiation_timeout - replay initiation timeout
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_TAF(
            service_name     IN VARCHAR2,
            failover_type    IN VARCHAR2 DEFAULT 'SELECT',
            failover_restore IN VARCHAR2 DEFAULT 'NONE');
  -- This procedure enables TAF on the given service
  --
  -- Input Parameter(s):
  --    service_name     - Service name
  --    failover_type    - 'SELECT' or 'SESSION'
  --    failover_restore - 'NONE' or 'LEVEL1'
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_TG(service_name IN VARCHAR2);
  -- This procedure enables Transaction Guard (TG) on the given service
  --
  -- Input Parameter(s):
  --    service_name - Service name.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE disable_failover(service_name IN VARCHAR2);
  -- This procedure disables failover features on the given service
  -- When failover is disabled on the service, the following client
  -- configurations can override the service setting:
  --   - FAILOVER_TYPE=SESSION
  --   - FAILOVER_TYPE=SELECT (with or without FAILOVER_RESTORE)
  --
  -- Input Parameter(s):
  --    service_name - Service name.
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE set_load_balancing_goal(service_name IN VARCHAR2,
                                    goal IN VARCHAR2 DEFAULT 'NONE');
  -- This procedure sets Runtime Load Balancing (RLB) goal for the given
  -- service
  --
  -- Input Parameter(s):
  --    service_name - Service name
  --    goal         - 'NONE', 'SERVICE_TIME' or 'THROUGHPUT'
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE set_draining(service_name IN VARCHAR2,
                         drain_timeout IN BINARY_INTEGER DEFAULT NULL,
                         stop_option IN VARCHAR2 DEFAULT NULL);
  -- This procedure sets session drain timeout and stop_option for the given
  -- service
  --
  -- Input Parameter(s):
  --    service_name - Service name
  --    drain_timeout - Integer in second for session drain timeout
  --    Service stop_option: NONE, TRANSACTIONAL, IMMEDIATE
  --
  -- error
  --    Appropriate error raised by server.

  PROCEDURE enable_ltxid_table_lock;
  -- This procedure enables table lock on ltxid_trans table
  -- Input Parameter(s):
  --    None
  -- error
  --    Appropriate error raised by server.

  PROCEDURE disable_ltxid_table_lock;
  -- This procedure disable table lock on ltxid_trans table
  -- Input Parameter(s):
  --    None
  -- error
  --    Appropriate error raised by server.

  PROCEDURE ACCHK_SET(enabled      IN BOOLEAN,
                      disable_time IN NUMBER DEFAULT 600);
  PRAGMA SUPPLEMENTAL_LOG_DATA(ACCHK_SET, READ_ONLY);

  -- This procedure enables or disables the data collection
  -- for acchk protection analysis.
  -- Set is at the PDB level or CDB root level, or non-CDB in the instance
  -- and does not remain in effect across instance restarts.
  -- Set can be used on both primary and standby databases.
  -- Set is not transfered automatically to standby.
  --
  -- Input Parameter(s):
  --    enabled      - TRUE or FALSE
  --                   TRUE: Enable ACCHK data collection.
  --                   FALSE: Disable ACCHK data collection.
  --    disable_time - Optional parameter. Default 600 seconds.
  --                   Used to disable ACCHK data collecting automatically
  --                   in a given number of seconds.
  --                   Valid range is from 60 up to 3600 seconds.
  --                   This parameter will take effect if ACCHK is not
  --                   explicitly disabled by the user.
  --                   This parameter is ignored when enabled is FALSE.
  --
  -- error:
  --    Appropiate error raised by server.

  PROCEDURE enable_reset_state(service_name IN VARCHAR2,
                               level IN VARCHAR2 DEFAULT 'NONE');
  -- This procedure enables reset_state for the named service.
  -- To use this interface the service must have
  -- FAILOVER_TYPE TRANSACTION or AUTO
  --
  -- Input Parameter(s):
  --    service_name - Service name
  --    level        - 'NONE' or 'LEVEL1'
  --
  -- error
  --    Appropriate error raised by server.

END dbms_app_cont_admin;
/

