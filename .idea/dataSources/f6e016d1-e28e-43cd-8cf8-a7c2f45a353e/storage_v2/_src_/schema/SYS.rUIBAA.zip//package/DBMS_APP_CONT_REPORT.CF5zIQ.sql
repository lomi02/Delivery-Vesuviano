create PACKAGE dbms_app_cont_report AS

  ------------
  --  OVERVIEW
  --
  --  This package provides protection reports for Application Continuity.
  --
  PRAGMA SUPPLEMENTAL_LOG_DATA(DEFAULT, READ_ONLY);

  -- Constants for report levels.
  SUMMARY CONSTANT NUMBER := 1;
  WARNING CONSTANT NUMBER := 2;
  FULL    CONSTANT NUMBER := 3;

  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --
  PROCEDURE ACCHK_REPORT(level        IN NUMBER DEFAULT SUMMARY,
                         service_name IN VARCHAR2 DEFAULT NULL);
  -- This procedure provides a report of ACCHK trace collected
  -- while ACCHK_SET(TRUE)
  -- Input Parameters(s):
  --    DBMS_APP_CONT_REPORT.SUMMARY summary report only (default)
  --    DBMS_APP_CONT_REPORT.WARNING summary and warnings
  --    DBMS_APP_CONT_REPORT.FULL    summary and all workload captured by ACCHK
  --   service_name - Optional service name qualifier, report for this
  --                  service only.
  -- error:
  -- Appropiate error raised by the server.
END dbms_app_cont_report;
/

