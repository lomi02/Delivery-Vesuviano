create package dbms_auto_index authid current_user is
  -- Bug 29472084: Package level pragma for plsql replication in Data Guard
  -- Rolling Upgrade. Please check if PRAGMA at individual API level is needed
  -- if you are adding a new one or updating an existing one.
  --
  -- For information on PRAGMA support check the following link
  -- https://confluence.oraclecorp.com/confluence/display/LTWO/PRAGMA+SUPPORT
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED);

  ---------------------------------------------------------------------------
  ---------------------------------------------------------------------------
  /*
    Package: DBMS_AUTO_INDEX

      Oracle periodically runs a task, SYS_AUTO_INDEX_TASK that monitors
      system and creates indexes based on workload running in the system.
      This package contains subprograms that display the report of the task,
      configure the execution and behavior of task etc.

    Notes:

      This is a invoker's right package created by SYS. The procedures in
      this package can be executed only by a dba.
  */
  ---------------------------------------------------------------------------
  ---------------------------------------------------------------------------

  ---------------------------------------------------------------------------
  --                           TYPES AND CONSTANTS
  ---------------------------------------------------------------------------


  ---------------------------------------------------------------------------
  --                           PUBLIC SUBPROGRAMS
  ---------------------------------------------------------------------------

  /*
    Procedure: report_activity

      Reports the results of auto index executions between specified
      acitivy_start and activity_end.
      Bug 29472084: This function is just reading data from dictionary and
      returning it, so PRAGMA is set to READ_ONLY.

    Parameters:
      activity_start   - Timestamp from which auto index executions are
                         observed for the report.
                         NULL => show the report for last execution
                         Default is current time - 1 day                 (IN)
      activity_end     - Timestamp until which auto index executions are
                         observed for the report.
                         Default is current time                         (IN)
      type             - Type of the report.  Possible values are:
                         TEXT, HTML, XML
                         Default is 'TEXT'                               (IN)
      section          - Particular section in the report.
                         Possible values are:
                         SUMMARY, INDEX_DETAILS, VERIFICATION_DETAILS,
                         ERRORS, ALL
                         Combinations of different values can be
                         specified using +/-, for example:
                         'SUMMARY +INDEX_DETAILS +ERRORS',
                         'ALL -ERRORS'
                         Default is 'ALL'                                (IN)
      level            - Format of the report.  Possible values are:
                         BASIC, TYPICAL, ALL
                         Default is 'TYPICAL'                            (IN)


    Exceptions:

    Notes:

    Examples:

      declare
        report clob := null;
      begin
        -- create a typical report for last day in text format
        report := dbms_auto_index.report_activity();
      end;

    Returns:
      Report
  */
  function report_activity(
    activity_start      IN timestamp with time zone := systimestamp - 1,
    activity_end        IN timestamp with time zone := systimestamp,
    type                IN varchar2                 := 'TEXT',
    section             IN varchar2                 := 'ALL',
    level               IN varchar2                 := 'TYPICAL')
  return clob;
  PRAGMA SUPPLEMENTAL_LOG_DATA(report_activity, READ_ONLY);

  /*
    Procedure: report_last_activity

      Reports the results of last auto index execution
      Bug 29472084: This function is just reading data from dictionary and
      returning it, so PRAGMA is set to READ_ONLY.

    Parameters:
      type             - Type of the report.  Possible values are:
                         TEXT, HTML, XML
                         Default is 'TEXT'                               (IN)
      section          - Particular section in the report.
                         Possible values are:
                         SUMMARY, INDEX_DETAILS, VERIFICATION_DETAILS,
                         ERRORS, ALL
                         Combinations of different values can be
                         specified using +/-, for example:
                         'SUMMARY +INDEX_DETAILS +ERRORS',
                         'ALL -ERRORS'
                         Default is 'ALL'                                (IN)
      level            - Format of the report.  Possible values are:
                         BASIC, TYPICAL, ALL
                         Default is 'TYPICAL'                            (IN)


    Exceptions:

    Notes:

    Examples:

      declare
        report clob := null;
      begin
        -- create a typical report for last day in text format
        report := dbms_auto_index.report_last_activity();
      end;

    Returns:
      Report
  */
  function report_last_activity(
    type                IN varchar2                 := 'TEXT',
    section             IN varchar2                 := 'ALL',
    level               IN varchar2                 := 'TYPICAL')
  return clob;
  PRAGMA SUPPLEMENTAL_LOG_DATA(report_last_activity, READ_ONLY);

  /*
     Procedure: configure
       Sets configuration options for auto indexing.
     Parameters:
       parameter_name  - One of the following possible values:
                         'AUTO_INDEX_SCHEMA' - Used for specifying a
                         schema name to include or exclude from creating
                         indexes automatically.
                         A detailed explanation is below:
                         1. By default, if inclusion list and exclusion list
                            are empty: auto indexing considers tables in all
                            user created schemas.
                         2. If there is at least one schema in the
                            inclusion list: then from then onward auto index
                            will only consider schema in the inclusion list.
                         3. If inclusion list is empty, but exclusion list
                            has at least one schema: auto index will consider
                            all user created schemas EXCEPT those in exclusion
                            list.
                         4. If both inclusion list and exclusion list has at
                            least one entry: It will do both (2) and (3).
                         Configure function can be called multiple times to
                         specify multiple schemas. How to put a matching string
                         for the schema name to the exclusion list or inclusion
                         list is specified in the 'allow' argument of this
                         function.

                         'AUTO_INDEX_TABLE' - Used for specifying a table
                         name to include or exclude from creating indexes
                         automatically. A detailed explanation is below:
                         1. By default, if inclusion list and exclusion list
                            are empty: auto indexing considers tables in all
                            user created schemas.
                         2. If there is at least one table in the
                            inclusion list: then from then onward auto index
                            will only consider tables in the inclusion list.
                         3. If inclusion list is empty, but exclusion list
                            has at least one table: auto index will consider
                            all tables from all user created schemas EXCEPT
                            those in exclusion list.
                         4. If both inclusion list and exclusion list has at
                            least one entry: It will do both (2) and (3).
                         Configure function can be called multiple times to
                         specify multiple tables. How to put a matching string
                         for the table name to the exclusion list or inclusion
                         list is specified in the 'parameter_value' argument
                         of this function.
                         'AUTO_INDEX_TABLE' can be used with 'AUTO_INDEX_SCHEMA'
                         to give a finer granularity of what to be considered
                         for auto indexing. For example, if we want to include
                         schema SH for auto indexing but exclude table SALES
                         of SH, we could put SH to inclusion list using
                         'AUTO_INDEX_SCHEMA' and put SH.SALES to exclusion
                         list using 'AUTO_INDEX_TABLE'. Then all tables in
                         schema SH will be considered for auto indexing except
                         table SH.SALES. In case there is a conflict between
                         'AUTO_INDEX_TABLE' and 'AUTO_INDEX_SCHEMA', table
                         will be given higer priority over schema. For example,
                         if schema SH is in the exclusion list but table
                         SH.PRODUCTS is in the inclusion list, auto indexing
                         will consider table SH.PRODUCTS even though schema
                         SH is excluded.

                         'AUTO_INDEX_REPORT_RETENTION' - Number of days
                         auto indexing logs are retained before they are purged.
                         Auto index report is generated based on the logs and it
                         can not generate report for the period beyond
                         the specified retention. Default value is 373 days.

                         'AUTO_INDEX_RETENTION_FOR_AUTO' - Number of days
                         auto indexes are retained after their last used date
                         before they are purged. Default value is 373 days.

                         'AUTO_INDEX_RETENTION_FOR_MANUAL' - Number of days
                         user-created indexes are retained after their last
                         used date before they are purged. NULL value means
                         user-created indexes will not be purged by auto
                         index task. Default value is NULL.

                         'AUTO_INDEX_DEFAULT_TABLESPACE' - The tablespace name
                         where all auto indexes are stored. Default value is
                         NULL. By default auto indexes are created in the
                         default tablespace of the owner of the table for
                         which the index is being created.

                         'AUTO_INDEX_MODE' - Different modes that auto index
                         can operate. Two available modes are 'IMPLEMENT',
                         'REPORT ONLY' and OFF. On 'IMPLEMENT', auto indexes
                         are available for user to use in their workload.
                         'REPORT ONLY' mode, on the other hand, does not made
                         auto indexes be available to use for user.
                         OFF value disables auto indexing completely.

                         'AUTO_INDEX_SPACE_BUDGET' -  Percent of space used
                         by auto indexes over total space used by all objects
                         in the tablespace. Default is 50. i.e. Auto indexing
                         will use up to 50% of the total space used by all
                         objects in the tablespace. In other words, if X is
                         the total space consumed by auto indexes and Y is the
                         total space consumed by all objects including auto
                         indexes, the ratio (X/Y)*100 should be <= 50. 100 is
                         a special value. If 100 is specified, auto indexing
                         will use up all space available in tablespace. This
                         parameter is ignored if AUTO_INDEX_DEFAULT_TABLESPACE
                         is specified. if it is specified, auto indexing will
                         use up all space available in the tablespace specified
                         by AUTO_INDEX_DEFAULT_TABLESPACE.

                         'AUTO_INDEX_COMPRESSION' - Used for specifying
                         whether compression to be used for automatically
                         created indexes or not. Suppoered values are
                         ON  - compression used for the indexes
                         OFF - do not use compression. This is the default.

       parameter_value - Values for the above parameters.
                         If the parameter_name is 'AUTO_INDEX_TABLE',
                         parameter_value must be in the format of
                         'OWNER_NAME.TABLE_NAME'. OWNER_NAME and TABLE_NAME
                         can be any valid sql identifier.

       allow           - This argument can only be TRUE for parameter other
                         than 'AUTO_INDEX_SCHEMA' and 'AUTO_INDEX_TABLE'.
                         For 'AUTO_INDEX_SCHEMA' and 'AUTO_INDEX_TABLE, the
                         meaning of allow value is as follows:
                         a) if value is specified in parameter_value
                           1. TRUE : put schema name/table name (specified
                                     in parameter value) into inclusion list
                           2. FALSE: put schema name/table name (specified
                                     in parameter value) into exclusion list
                           3. NULL : pull out schema name/table name
                                     (specified inparameter value) off either
                                     exclusion or inclusion list.
                          b) if parameter_value is NULL: allow will have
                             no effect and both inclusion and exclusion list
                             are emptied
                         Default is TRUE.

    Exceptions:
    Notes:
      The current configuration values can be displayed using
      dba_auto_index_config view.
    Examples:
      -- Exclude SH and HR schema from auto indexing
      => schema NOT LIKE ('SH', 'HR' )
      begin
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', 'SH', FALSE);
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', 'HR', FALSE);
      end;
      -- Remove HR schema from exclusion list
      => schema NOT LIKE ('SH')
      begin
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', 'HR', NULL);
      end;
      -- Remove all schemas from inclusion/exclusion list. When the
      -- parameter_value is NULL, the third parameter allow will have
      -- no effect and can be omitted.
      begin
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', NULL);
      end;
      -- Include SH for auto indexing but exclude HR
      => schema LIKE ('SH') AND NOT LIKE ('HR')
      begin
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', 'SH', FALSE);
        dbms_auto_index.configure('AUTO_INDEX_SCHEMA', 'HR', TRUE);
      end;
      -- Include table SH.SALES for auto indexing. None of the other
      -- tables are considered for auto indexing.
      begin
        dbms_auto_index.configure('AUTO_INDEX_TABLE', 'SH.SALES', TRUE);
      end;
      -- Remove table SH.SALES from inclusion list
      begin
        dbms_auto_index.configure('AUTO_INDEX_TABLE', 'SH.SALES', NULL);
      end;
      -- Exclude table SH.SALES for auto indexing. It will consider all
      -- user tables except SH.SALES.
      begin
        dbms_auto_index.configure('AUTO_INDEX_TABLE', 'SH.SALES', FALSE);
      end;
      -- Remove all tables from inclusion/exclusion list. When the
      -- parameter_value is NULL, the third parameter allow will have
      -- no effect and can be omitted.
      begin
        dbms_auto_index.configure('AUTO_INDEX_TABLE', NULL);
      end;
      -- Set report retention to 100 days
      begin
        dbms_auto_index.configure('AUTO_INDEX_REPORT_RETENTION', 100);
      end;
      -- Set report retention to default, 31 days
      begin
        dbms_auto_index.configure('AUTO_INDEX_REPORT_RETENTION', NULL);
      end;

    Returns:
      Nothing
  */
  procedure configure( parameter_name    IN VARCHAR2,
                       parameter_value   IN VARCHAR2,
                       allow             IN BOOLEAN  := TRUE);

  /*
    Procedure: drop_secondary_indexes

     Drops indexes that are not used for constraints for given
     schema and table.
     If OWNER is explicitly set to null and TABLE_NAME is explicitly set to
     null all secondary indexes which the user has privileges on will be
     dropped.

     If OWNER is explicitly specified and TABLE_NAME is set to null, all
     secondary indexes within the given schema will be dropped.

    Parameters:
     owner        -   schema name (IN)
     table_name   -   table name (IN)

    Exceptions:

    Notes:

    Examples:

    Returns:
      Nothing.
  */
  procedure drop_secondary_indexes(
    owner      varchar2,
    table_name varchar2);

 /*
    Procedure: drop_auto_indexes

    Drops indexes created by auto index task.

    If OWNER is explicitly set to null and INDEX_NAME is explicitly set to null
    all auto indexes which the user has privileges on will be dropped.

    If OWNER is explicitly specified and INDEX_NAME is set to null, all auto
    indexes within the given schema will be dropped. The dropped indexes are
    not recreated automatically by the system by default.
    Specify allow_recreate argument 'TRUE' to change this behavior.

    If the index to be dropped does not exist, the procedure simply mark the
    index to be allowed to be recreated or not based on allow_recreate param

    Parameters:
         owner                  -   name of the owner of the index (IN)
         index_name             -   index name (IN) - - (NO DEFAULT VALUE)
         allow_recreate         -   allow/disallow automatic creation of the
                                    dropped index again (IN)

    Exceptions:

        Notes:

        Examples:

        Returns:
          Nothing.
 */
 procedure drop_auto_indexes(
   owner          varchar2,
   index_name     varchar2,
   allow_recreate boolean default false);

end dbms_auto_index;
/

