create PACKAGE dbms_hierarchy AUTHID CURRENT_USER IS

  TYPE ID3 IS RECORD (
    comp1 VARCHAR2(128),
    comp2 VARCHAR2(128),
    comp3 VARCHAR2(128));

  TYPE ID2 IS RECORD (
    comp1 VARCHAR2(128),
    comp2 VARCHAR2(128));

  TYPE ID_SEQUENCE IS VARRAY(32767) OF VARCHAR2(128);

  TYPE ID2_SEQUENCE IS VARRAY(32767) OF ID2;

  TYPE ID3_SEQUENCE IS VARRAY(32767) OF ID3;

  -- Constants used for upgrade log table
  VERSION_12_2_0_1 CONSTANT NUMBER := 1;
  VERSION_12_2_0_2 CONSTANT NUMBER := 2;
  VERSION_NONE     CONSTANT NUMBER := 3;
  VERSION_LATEST   CONSTANT NUMBER := VERSION_12_2_0_2;

  TABLE_DOES_NOT_EXIST EXCEPTION;
       PRAGMA EXCEPTION_INIT(TABLE_DOES_NOT_EXIST, -942);
  NAME_ALREADY_USED EXCEPTION;
      PRAGMA EXCEPTION_INIT(NAME_ALREADY_USED, -955);
  MISMATCH_OBJ_LOGNUM EXCEPTION;
      PRAGMA EXCEPTION_INIT(MISMATCH_OBJ_LOGNUM, -18263);
  MISMATCH_COL_LENGTH EXCEPTION;
      PRAGMA EXCEPTION_INIT(MISMATCH_COL_LENGTH, -18275);
  LOG_TABLE_UPGRADE EXCEPTION;
      PRAGMA EXCEPTION_INIT(LOG_TABLE_UPGRADE, -18276);
  INVALID_SQL_NAME EXCEPTION;
      pragma EXCEPTION_INIT(INVALID_SQL_NAME, -44003);
  INVALID_SQL_ARG EXCEPTION;
      pragma EXCEPTION_INIT(INVALID_SQL_ARG, -18250);

  PROCEDURE upgrade_validate_log_table(
    table_name           IN VARCHAR2,
    owner_name           IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'));
  PRAGMA supplemental_log_data(upgrade_validate_log_table, AUTO);

  PROCEDURE create_validate_log_table (
    table_name           IN VARCHAR2,
    owner_name           IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    ignore_if_exists     IN BOOLEAN DEFAULT FALSE);
  PRAGMA supplemental_log_data(create_validate_log_table, AUTO);

  FUNCTION validate_hierarchy (
    hier_name	 	 IN VARCHAR2,
    hier_owner_name	 IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    log_table_name	 IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    error_threshold      IN NUMBER default 100)
  RETURN NUMBER;

  FUNCTION VALIDATE_CHECK_SUCCESS(
    topobj_name IN VARCHAR2,
    topobj_owner IN VARCHAR2 DEFAULT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    log_number IN NUMBER,
    log_table_name IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'))
  RETURN VARCHAR2;

  FUNCTION validate_analytic_view (
    analytic_view_name	     IN VARCHAR2,
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    log_table_name	     IN VARCHAR2 DEFAULT NULL,
    log_table_owner_name     IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    skip_hiers               IN VARCHAR2 DEFAULT 'N',
    error_threshold          IN NUMBER default 100)
  RETURN NUMBER;

  FUNCTION get_mv_sql_for_av_cache (
    analytic_view_name       IN VARCHAR2,
    cache_idx                IN NUMBER, -- 0 based cache index
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'))
  RETURN CLOB;

  FUNCTION get_mv_sql_for_av_cache (
    analytic_view_name       IN VARCHAR2,
    lvl_seq                  IN dbms_hierarchy.ID3_SEQUENCE,
    meas_seq                 IN dbms_hierarchy.ID_SEQUENCE DEFAULT NULL,
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'))
  RETURN CLOB;

  FUNCTION get_mv_sql_for_star_cache (
    attr_dim_name       IN VARCHAR2,
    attr_dim_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'))
  RETURN CLOB;

  FUNCTION is_numeric(strnum VARCHAR2) RETURN NUMBER;

  PROCEDURE create_view_for_fact_rows(
    analytic_view_name       IN VARCHAR2,
    view_name                IN VARCHAR2,
    dim_hier_seq             IN dbms_hierarchy.ID2_SEQUENCE DEFAULT NULL,
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    view_owner_name          IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    dim_qual_sep             IN VARCHAR2 DEFAULT '_',
    all_join_keys            IN BOOLEAN DEFAULT TRUE,
    include_meas             IN BOOLEAN DEFAULT FALSE,
    include_hier_attr        IN BOOLEAN DEFAULT FALSE);
  PRAGMA supplemental_log_data(create_view_for_fact_rows,
                               UNSUPPORTED_WITH_COMMIT);

  PROCEDURE create_view_for_star_rows(
    analytic_view_name       IN VARCHAR2,
    dimension_alias          IN VARCHAR2,
    view_name                IN VARCHAR2,
    analytic_view_owner_name IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    view_owner_name          IN VARCHAR2 DEFAULT
      SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA'),
    hier_qual_sep            IN VARCHAR2 DEFAULT '_',
    include_hier_attr        IN BOOLEAN DEFAULT FALSE);
  PRAGMA supplemental_log_data(create_view_for_star_rows,
                               AUTO_WITH_COMMIT);

END dbms_hierarchy;
/

