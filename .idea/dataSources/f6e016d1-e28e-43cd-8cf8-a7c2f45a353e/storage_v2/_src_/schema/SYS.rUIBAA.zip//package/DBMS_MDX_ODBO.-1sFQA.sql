create PACKAGE DBMS_MDX_ODBO AUTHID CURRENT_USER AS
  PRAGMA supplemental_log_data(default, READ_ONLY);

  MDX_DATE CONSTANT VARCHAR2(8) := 'MDX_DATE';
  MDX_NUMBER CONSTANT VARCHAR2(10) := 'MDX_NUMBER';

  MDSCHEMA_ACTIONS CONSTANT BINARY_INTEGER := 1;
  MDSCHEMA_CUBES CONSTANT BINARY_INTEGER := 2;
  MDSCHEMA_DIMENSIONS CONSTANT BINARY_INTEGER := 3;
  MDSCHEMA_FUNCTIONS CONSTANT BINARY_INTEGER := 4;
  MDSCHEMA_HIERARCHIES CONSTANT BINARY_INTEGER := 5;
  MDSCHEMA_LEVELS CONSTANT BINARY_INTEGER := 6;
  MDSCHEMA_MEASURES CONSTANT BINARY_INTEGER := 7;
  MDSCHEMA_PROPERTIES CONSTANT BINARY_INTEGER := 8;
  MDSCHEMA_MEMBERS CONSTANT BINARY_INTEGER := 9;
  MDSCHEMA_SETS CONSTANT BINARY_INTEGER := 10;
  MDSCHEMA_ROWSET_MAX CONSTANT BINARY_INTEGER := 11;

  -- RDBMS bug (fixed in MAIN) prevents use of SMALLINT here
  --TYPE odbo_boolean_sequence  IS VARRAY(32767) OF SMALLINT;
  --TYPE odbo_short_sequence IS VARRAY(32767) OF SMALLINT;
  TYPE odbo_boolean_sequence IS VARRAY(32767) OF NUMBER;
  TYPE odbo_short_sequence IS VARRAY(32767) OF NUMBER;
  TYPE odbo_number_sequence IS VARRAY(32767) OF NUMBER;
  TYPE odbo_string_sequence IS VARRAY(32767) OF VARCHAR2(10922);

  INVALID_ROWSET_TYPE EXCEPTION;
      PRAGMA EXCEPTION_INIT(INVALID_ROWSET_TYPE, -18259);

  INVALID_ROWSET_ARRAYS EXCEPTION;
      PRAGMA EXCEPTION_INIT(INVALID_ROWSET_ARRAYS, -18260);

  INVALID_QRY_PROPS EXCEPTION;
      PRAGMA EXCEPTION_INIT(INVALID_QRY_PROPS, -18264);

  PROCEDURE execute(
    mdx_str IN VARCHAR2,
    query_properties IN odbo_string_sequence,
    column_axis OUT SYS_REFCURSOR, row_axis OUT SYS_REFCURSOR,
    page_axis OUT SYS_REFCURSOR, chapter_axis OUT SYS_REFCURSOR,
    section_axis OUT SYS_REFCURSOR, slicer OUT SYS_REFCURSOR,
    mdx_info OUT CLOB, query_id OUT NUMBER);

  FUNCTION GET_MDX_DATE_TYPE RETURN VARCHAR2;
  FUNCTION GET_MDX_NUMBER_TYPE RETURN VARCHAR2;

  FUNCTION GET_MDSCHEMA_ACTIONS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_CUBES RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_DIMENSIONS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_FUNCTIONS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_HIERARCHIES RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_LEVELS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_MEASURES RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_PROPERTIES RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_MEMBERS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_SETS RETURN BINARY_INTEGER;
  FUNCTION GET_MDSCHEMA_ROWSET_MAX RETURN BINARY_INTEGER;

  PROCEDURE get_axis_data(
    query_id IN NUMBER,
    axis_index IN NUMBER,
    axis_data OUT SYS_REFCURSOR);

  PROCEDURE get_cell_data(
    query_id IN NUMBER,
    cell_range IN odbo_number_sequence,
    cell_data OUT SYS_REFCURSOR);

  PROCEDURE close(query_id IN NUMBER);

  FUNCTION convert_format_string (
    orcl_fmt_str         IN VARCHAR2,
    datatype             IN VARCHAR2)
  RETURN VARCHAR2;

  FUNCTION mdx_component_id (
    component1 	 IN VARCHAR2,
    component2   IN VARCHAR2 DEFAULT NULL,
    component3   IN VARCHAR2 DEFAULT NULL,
    component4   IN VARCHAR2 DEFAULT NULL)
  RETURN VARCHAR2;

  FUNCTION mdx_strip_component (
    id           IN VARCHAR2)
  RETURN VARCHAR2;

  FUNCTION get_mdx_keyword_names
  return sys.dbms_mdx_odbo_keyword_t
  pipelined;

  FUNCTION get_mdx_function_names
  return sys.dbms_mdx_odbo_function_t
  pipelined;

  FUNCTION get_mdx_property_values
  return sys.dbms_mdx_odbo_propval_t
  pipelined;

  PROCEDURE get_dso_properties(mdpropvals OUT odbo_short_sequence);

  PROCEDURE get_keywords(keywords OUT VARCHAR2);

  PROCEDURE get_schema_rowset(
      rowset_type IN NUMBER,
      restrictions IN odbo_string_sequence,
      empty IN odbo_boolean_sequence,
      rowset OUT SYS_REFCURSOR,
      query_properties IN odbo_string_sequence);

  PROCEDURE close_schema_rowset(
      rowset_type IN NUMBER,
	  rowset In OUT SYS_REFCURSOR);

  -- Function to return Dimension Types
  FUNCTION mdx_dimension_type(dimtype IN VARCHAR2)
      RETURN INTEGER DETERMINISTIC;

  -- Function to return Measure Cardinality
  FUNCTION mdx_get_measure_cardinality(
      cubeowner IN VARCHAR2,
	  cubename IN VARCHAR2)
      RETURN INTEGER DETERMINISTIC;

  -- Function to return Dimension Cardinality
  FUNCTION mdx_get_dimension_cardinality(
      cubeowner IN VARCHAR2,
	  cubename IN VARCHAR2,
	  dimalias IN VARCHAR2)
      RETURN INTEGER DETERMINISTIC;

  -- Function to return Level Cardinality
  FUNCTION mdx_get_level_cardinality(
      cubeowner IN VARCHAR2,
	  cubename IN VARCHAR2,
	  dimalias IN VARCHAR2,
	  hierarchyalias IN VARCHAR2,
	  levelname IN VARCHAR2)
      RETURN INTEGER DETERMINISTIC;

  -- Function to return Hierarchy Cardinality
  FUNCTION mdx_get_hierarchy_cardinality(
      cubeowner IN VARCHAR2,
	  cubename IN VARCHAR2,
	  dimalias IN VARCHAR2,
	  hierarchyalias IN VARCHAR2)
      RETURN INTEGER DETERMINISTIC;

  -- Function to return Hierarchy Structures
  FUNCTION mdx_hierarchy_structure(structuretype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Hierarchy and Level Origins
  FUNCTION mdx_origin(origintype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Hierarchy Instance Selections
  FUNCTION mdx_hierarchy_inst_selection(selectiontype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Level Unique Settings
  FUNCTION mdx_level_unique_settings(type IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Measure Aggregation Value
  FUNCTION mdx_measure_aggregator(aggtype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Property Types
  FUNCTION mdx_property_type(propertytype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Property Content Types
  FUNCTION mdx_property_content_type(propertytype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  -- Function to return Property Origins
  FUNCTION mdx_property_origin(propertytype IN VARCHAR2)
    RETURN INTEGER DETERMINISTIC;

  FUNCTION mdx_datatype (orclDt IN VARCHAR2)
  RETURN NUMBER DETERMINISTIC;

END;
/

