create package dbms_pdb_app_con authid current_user is

  -- Return Codes from Sync Error Handler should be one of these values:
  --
  -- SYNC_ERROR_NOT_OK
  -- SYNC_ERROR_OK_ALWAYS
  -- SYNC_ERROR_OK_ON_RETRY
  --
  -- The above constants have to be kept in sync with KPDBFD_ERROR macros.
  --
  -- KPDBFD_ERROR_NOT_OK
  -- KPDBFD_ERROR_OK
  -- KPDBFD_ERROR_OK_RETRY

  -- Error encountered by Application Sync is NOT acceptable
  SYNC_ERROR_NOT_OK      CONSTANT NUMBER := 1;

  -- Error encountered by Application Sync is acceptable whether resync or not
  SYNC_ERROR_OK_ALWAYS   CONSTANT NUMBER := 2;

  -- Error encountered by Application Sync is acceptable during resync
  SYNC_ERROR_OK_ON_RETRY CONSTANT NUMBER := 3;

  -- Sync Error Handler can check the value of parameter RESYNC against
  -- this constant to know if the handler is being invoked as part of a
  -- retry of Application Sync.
  SYNC_RETRY CONSTANT NUMBER := 1;

  -- This procedure should be used move data from one partition to another
  -- partition. It is intended to be used after split partition is done
  -- on container map partition. This movement of data is done only for
  -- the PDBs in the same CDB and intra CDB dblinks should be enabled before
  -- calling this procedure. This movement will also be according to the map
  -- constraints and data will be moved from old partition to new partition
  -- and not the other way around. This routine affects all container_map
  -- enabled tables.
  procedure move_data (old_partition_name IN varchar2,
                       new_partition_name IN varchar2);
end;
/

