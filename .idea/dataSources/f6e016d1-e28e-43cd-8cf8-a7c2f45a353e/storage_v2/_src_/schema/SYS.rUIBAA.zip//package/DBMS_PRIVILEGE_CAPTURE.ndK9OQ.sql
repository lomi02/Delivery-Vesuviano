create PACKAGE     dbms_privilege_capture AUTHID CURRENT_USER AS

 -- Capture Types
  g_database            CONSTANT NUMBER := 1;
  g_role                CONSTANT NUMBER := 2;
  g_context             CONSTANT NUMBER := 3;
  g_role_and_context    CONSTANT NUMBER := 4;


  -- Bug 31168578: PA metadata dictionary change should be propagated and synced
  -- between primary and standby, so that in case of failover/switchover, user
  -- does not need to redo the operation. This means that when the user
  -- creates/deletes PA policy, enables/disables a capture, the metadata
  -- in both primary and standby should reflect the corresponding changes.
  --
  -- However, PA cannot be enabled effectively on the standby because:
  -- 1. PA records from one database cannot be merged with those collected from
  -- another database. 2. The logical standby could be connected and used
  -- by other people and the PA records if captured, are outside of user's
  -- intention.
  -- PA does not capture/store any privileges if it's a standby database.
  -- Please see the check at the beginning of kzpp.c - kzppinsrec1.
  PROCEDURE create_capture(
    name            IN  VARCHAR2,
    description     IN  VARCHAR2 DEFAULT NULL,
    type            IN  NUMBER DEFAULT G_DATABASE,
    roles           IN  role_name_list DEFAULT role_name_list(),
    condition       IN  VARCHAR2   DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_capture, AUTO_WITH_COMMIT);

  PROCEDURE drop_capture(name  IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_capture, AUTO_WITH_COMMIT);

  PROCEDURE enable_capture(name  IN VARCHAR2, run_name IN VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_capture, AUTO_WITH_COMMIT);

  PROCEDURE disable_capture(name IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_capture, AUTO_WITH_COMMIT);

  PROCEDURE generate_result(name     IN VARCHAR2,
                            run_name IN VARCHAR2 DEFAULT NULL,
                            dependency  IN BOOLEAN DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(generate_result, NONE);

  PROCEDURE delete_run(name  IN VARCHAR2, run_name IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_run, AUTO_WITH_COMMIT);

  PROCEDURE capture_dependency_privs;
  PRAGMA SUPPLEMENTAL_LOG_DATA(capture_dependency_privs, NONE);

END;
/

