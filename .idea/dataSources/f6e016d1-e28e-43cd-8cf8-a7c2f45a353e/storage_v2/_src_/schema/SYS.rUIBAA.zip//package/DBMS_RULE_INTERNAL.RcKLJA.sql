create PACKAGE dbms_rule_internal AUTHID CURRENT_USER AS

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, READ_ONLY);
  -- Internal constants used across packages should be defined here.
  -- Bug 8656192: Add macro KWRX_CHN_ANYDTA.
  --              This should be in sync with C layer macro defined in kwrx.h

  KWRX_CHN_ANYDTA                CONSTANT PLS_INTEGER := 1;


  PROCEDURE i_evaluate(
        rule_set_name           IN      varchar2,
        evaluation_context      IN      varchar2,
        event_context           IN      sys.re$nv_list := NULL,
        table_values            IN      sys.re$table_value_list := NULL,
        column_values           IN      sys.re$column_value_list := NULL,
        variable_values         IN      sys.re$variable_value_list := NULL,
        attribute_values        IN      sys.re$attribute_value_list := NULL,
        stop_on_first_hit       IN      boolean := FALSE,
        simple_rules_only       IN      boolean := FALSE,
        result_cache            IN      boolean := TRUE,
        variable_flag           IN      pls_integer,
        true_rules              OUT     sys.re$rule_hit_list,
        maybe_rules             OUT     sys.re$rule_hit_list);


      procedure i_evaluate(
        rule_set_name           IN      varchar2,
        evaluation_context      IN      varchar2,
        event_context           IN      sys.re$nv_list := NULL,
        table_values            IN      sys.re$table_value_list := NULL,
        column_values           IN      sys.re$column_value_list := NULL,
        variable_values         IN
                sys.scheduler$_var_value_list := NULL,
        attribute_values        IN      sys.re$attribute_value_list := NULL,
        stop_on_first_hit       IN      boolean := FALSE,
        simple_rules_only       IN      boolean := FALSE,
        result_cache            IN      boolean := TRUE,
        variable_flag           IN      pls_integer,
        true_rules              OUT     sys.re$rule_hit_list,
        maybe_rules             OUT     sys.re$rule_hit_list);

END dbms_rule_internal;
/

