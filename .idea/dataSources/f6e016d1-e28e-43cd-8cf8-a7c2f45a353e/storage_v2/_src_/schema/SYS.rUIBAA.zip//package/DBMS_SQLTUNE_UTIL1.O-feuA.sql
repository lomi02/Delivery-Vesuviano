create PACKAGE dbms_sqltune_util1 AS

  -- Support log based replication (proj 17779)
  -- The possible categories for SVRMAN are:
  --
  --       A) READ_ONLY:
  --          Procedure does not need to be replicated as it does not
  --          generate any UNDO/REDO. (e.g. Reporting APIs, Import/Export).
  --
  --       B) NONE:
  --          Any procedure that performs DDL/DML but the DML/DDL is either
  --          replicated naturally by log-miner (not in SYS schema) or the DML
  --          is to SYS schema, but it is OK not to replicate it.
  --          (e.g., ADDM execution, AWR snapshot, STS creation).
  --
  --       C) UNSUPPORTED:
  --          Any procedure that produces DML/DDL that must be replicated to
  --          the stand-by, but can not be replicated by running the same
  --          procedure on the stand-by RDBMS.
  --
  -- By default, SVRMAN procedures will follow the NONE semantics if they
  -- produce DML and READ_ONLY if they do not.
  -- Any exception must be declared at the END of the specific procedure.
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -----------------------------------------------------------------------------
  --                 section for constants and global variables              --
  -----------------------------------------------------------------------------

  -- target object ids which are defined in OBJ_XXX_NUM keat constants
  OBJ_SQL#                CONSTANT NUMBER    :=  7;   -- obj
  OBJ_SQLSET#             CONSTANT NUMBER    :=  8;   -- obj
  OBJ_AUTO_SQLWKLD#       CONSTANT NUMBER    :=  22;  -- obj
  OBJ_SPA_EXEC_PROP#      CONSTANT NUMBER    :=  23;  -- SPA exec property
  OBJ_SPA_TASK#           CONSTANT NUMBER    :=  24;  -- SPA task obj
  OBJ_SPM_EVOLVE_TASK#    CONSTANT NUMBER    :=  25;  -- SPM evolve task obj
  OBJ_COMPARE_PLANS_TASK# CONSTANT NUMBER    :=  30;  -- compare plans task obj
  OBJ_AUTOSTS#            CONSTANT NUMBER    :=  33;  -- Auto Sql Tunning Set

  -- Execution types
  --   Names:
  SQLTUNE      CONSTANT VARCHAR2(10) := 'TUNE SQL';
  TEST_EXECUTE CONSTANT VARCHAR2(12) := 'TEST EXECUTE';
  EXPLAIN_PLAN CONSTANT VARCHAR2(12) := 'EXPLAIN PLAN';
  COMPARE      CONSTANT VARCHAR2(19) := 'COMPARE PERFORMANCE';
  STS2TRIAL    CONSTANT VARCHAR2(19) := 'CONVERT SQLSET';
  SQLDIAG      CONSTANT VARCHAR2(19) := 'SQL DIAGNOSIS';
  SPMEVOLVE    CONSTANT VARCHAR2(14) := 'SPM EVOLVE';
  COMPAREPLANS CONSTANT VARCHAR2(19) := 'COMPARE PLANS';

  --   IDs:
  SQLTUNE#       CONSTANT PLS_INTEGER := 1;                    /* Sql tuning */
  EXECUTE#       CONSTANT PLS_INTEGER := 2;              /* SQL test execute */
  EXPLAIN#       CONSTANT PLS_INTEGER := 3;              /* SQL explain plan */
  SQLDIAG#       CONSTANT PLS_INTEGER := 4;                 /* SQL diagnosis */
  COMPARE#       CONSTANT PLS_INTEGER := 5;             /* compare for SQLPA */
  EVOLVE#        CONSTANT PLS_INTEGER := 6;                    /* SPM Evolve */
  COMPAREPLANS#  CONSTANT PLS_INTEGER := 7;                 /* Compare Plans */

  -- DB link owner for remote queries
  TASK_DBLINK_OWNER CONSTANT VARCHAR2(3)   := 'SYS';

  -- DB link user for remote queries
  TASK_DBLINK_USER  CONSTANT VARCHAR2(7)   := 'SYS$UMF';

  -- parameter name for a DB link to a remote db
  PARAM_DBLINK_TO    CONSTANT VARCHAR2(16) := 'DATABASE_LINK_TO';

  --
  -- task_wkldobj, task_sqlobj, property_map
  --
  -- The task_wkldobj structure stores information about the input to
  -- a tuning task.  We examine it during the parts of the report where
  -- we need to have different logic depending on the target object.  The
  -- 'props' field is a hashtable mapping property names to values, and the
  -- 'sql' field defines the current SQL we are operating on.  For
  -- single-statement tasks it is populated with the sql target object.
  --
  -- For STSes the workload is the same for all executions so we just load
  -- it up once.  For the automatic sql workload, it is different in each
  -- execution so we have to refresh the data.
  --
  -- We also define constants for valid property names here.
  TYPE property_map IS TABLE OF VARCHAR2(32767) INDEX BY VARCHAR2(32767);
  TYPE task_sqlobj IS RECORD(
    obj_id              NUMBER,
    sql_id              VARCHAR2(13),
    plan_hash_value     NUMBER,
    parsing_schema_name DBMS_ID,
    sql_text            CLOB,
    other_xml           CLOB,
    exec_frequency      NUMBER,
    flags               BINARY_INTEGER,
    con_name            varchar2(30),
    con_dbid            NUMBER
  );

  TYPE task_wkldobj IS RECORD(
    adv_id    NUMBER,          -- advisor id#
    task_name VARCHAR2(30),    -- name of the current task
    type      NUMBER,          -- one of OBJ_XXX_NUM keat constants
    obj_id    NUMBER,          -- object id of target object
    props     property_map,    -- (name, value) pairs describing the target
    cursql    task_sqlobj,     -- SQL object for the current statement
    is_cdb    BOOLEAN          -- checks if this ia cdb env
  );

  TYPE task_spaobj IS RECORD(
    exec1_name        VARCHAR2(32767),  -- the execution name of trial one
    exec1_type_num    NUMBER,           -- the execution type of trial one
    comp_exec_name    VARCHAR2(32767),  -- compare exec name, max length ?
    ce_obj_id         NUMBER,           -- obj id of comp env
    target_obj_type   NUMBER,           -- could be SQLSET or SQL
    target_obj_id     NUMBER,           -- id of the target object of SPA task
    wkld              task_wkldobj      -- has the target obj id
  );

  -- Constants used as property names in the 'props' hashtable

  -- STS properties
  PROP_SQLSET_NAME   CONSTANT VARCHAR2(30) := 'SQLSET_NAME';   -- sts name
  PROP_SQLSET_OWNER  CONSTANT VARCHAR2(30) := 'SQLSET_OWNER';  -- sts owner
  PROP_SQLSET_ID     CONSTANT VARCHAR2(30) := 'SQLSET_ID';     -- sts id
  PROP_SQLSET_DESC   CONSTANT VARCHAR2(30) := 'SQLSET_DESC';   -- sts desc

  -- Shared properties for multi-statement targets
  PROP_NB_SQL        CONSTANT VARCHAR2(30) := 'NB_STMTS';   -- total #stmts
                                                            -- (NOT # in rept)
  PROP_CON_DBID      CONSTANT VARCHAR2(30) := 'CON_DBID';

  -- properties for STS2 (compare STS)
  PROP_SQLSET_NAME2  CONSTANT VARCHAR2(30) := 'SQLSET_NAME2';
  PROP_SQLSET_OWNER2 CONSTANT VARCHAR2(30) := 'SQLSET_OWNER2';
  PROP_SQLSET_ID2    CONSTANT VARCHAR2(30) := 'SQLSET_ID2';
  PROP_SQLSET_DESC2  CONSTANT VARCHAR2(30) := 'SQLSET_DESC2';
  PROP_NB_SQL2       CONSTANT VARCHAR2(30) := 'NB_STMTS2';
  PROP_CON_DBID2     CONSTANT VARCHAR2(30) := 'CON_DBID2';

  -- properties for SPA
  PROP_SPA_EXECNAME  CONSTANT VARCHAR2(30) := 'EXEC_NAME';
  PROP_SPA_EXECNAME2 CONSTANT VARCHAR2(30) := 'EXEC_NAME2';

  -- Automatic Workload properties
  PROP_SUM_ELAPSED   CONSTANT VARCHAR2(30) := 'SUM_ELAPSED'; -- sum of elapsed

  -- Single statement properties
  PROP_SQL_ID         CONSTANT VARCHAR2(30) := 'SQL_ID';
  PROP_PARSING_SCHEMA CONSTANT VARCHAR2(30) := 'PARSING_SCHEMA';
  PROP_SQL_TEXT       CONSTANT VARCHAR2(30) := 'SQL_TEXT';
  PROP_TUNE_STATS     CONSTANT VARCHAR2(30) := 'TUNE_STATS';

  -- Parse modes for query
  PARSE_MOD_SQLSET  CONSTANT VARCHAR2(6) := 'SQLSET'     ;
  PARSE_MOD_AWR     CONSTANT VARCHAR2(4) := 'AWR'        ;
  PARSE_MOD_CURSOR  CONSTANT VARCHAR2(5) := 'V$SQL'      ;
  PARSE_MOD_CAPCC   CONSTANT VARCHAR2(8) := 'V$SQLCAP'   ;
  PARSE_MOD_PROFILE CONSTANT VARCHAR2(10):= 'SQLPROFILE' ;
  PARSE_MOD_AUTOSTS CONSTANT VARCHAR2(8) := 'AUTOSTS'    ;

  -- Different types for validate_name
  TYPE_STS   CONSTANT BINARY_INTEGER := 0;
  TYPE_DBOP  CONSTANT BINARY_INTEGER := 1;

  --
  -- Database type constants
  -- Describe the type of database that corresponds to the dbid value that
  -- is passed as parameter to resolve_db_type function.
  --
  DB_TYPE_ROOT CONSTANT VARCHAR(4) := 'ROOT';
  DB_TYPE_PDB  CONSTANT VARCHAR(3) := 'PDB';
  DB_TYPE_IMP  CONSTANT VARCHAR(8) := 'IMPORTED';

  --
  -- AWR view prefixes
  -- Describe the location of AWR views that corresponds to a dbid value.
  -- Returned by get_awr_view_location function.
  --
  AWR_VIEW_ROOT CONSTANT VARCHAR(8) := 'AWR_ROOT';
  AWR_VIEW_PDB  CONSTANT VARCHAR(7) := 'AWR_PDB';

  --
  -- Session Parameter input
  -- Describe with parameter will be change by this function.
  -- Used by alter_session_parameter and restore_session_parameter
  --
  PNUM_SYSPLS_OBEY_FORCE CONSTANT NUMBER := 1;

  -----------------------------------------------------------------------------
  --                  public utility procedures and functions                --
  -----------------------------------------------------------------------------

  ---------------------------- get_sqlset_identifier --------------------------
  -- NAME:
  --     get_sqlset_identifier
  --
  -- DESCRIPTION:
  --     This function gets the SqlSet identifier ginven its name
  --
  -- PARAMETERS:
  --     sts_name  (IN) - sqlset name
  --     sts_owner (IN) - owner of sqlset
  --
  -- RETURN:
  --     The SqlSet id.
  -----------------------------------------------------------------------------
  FUNCTION get_sqlset_identifier(sts_name  IN VARCHAR2, sts_owner IN VARCHAR2)
  RETURN NUMBER;

  ---------------------------- get_sqlset_con_dbid --------------------------
  -- NAME:
  --     get_sqlset_con_dbid
  --
  -- DESCRIPTION:
  --     This function gets the container DB id given STS id
  --
  -- PARAMETERS:
  --     sts_id  (IN) - SQL tuning set id
  --
  -- RETURN:
  --     Container DB id.
  -----------------------------------------------------------------------------
  FUNCTION get_sqlset_con_dbid(sts_id  IN NUMBER)
  RETURN NUMBER;

  ----------------------------- get_sqlset_nb_stmts ---------------------------
  -- NAME:
  --     get_sqlset_nb_stmts
  --
  -- DESCRIPTION:
  --     This function gets number of SQL statements in a SQL tuning set
  --
  -- PARAMETERS:
  --     sts_id  (IN) - SQL tuning set id
  --
  -- RETURN:
  --     Number of SQL in SQL tuning sets.
  -----------------------------------------------------------------------------
  FUNCTION get_sqlset_nb_stmts(sts_id IN NUMBER)
  RETURN NUMBER;

  ---------------------------- get_autosts_nb_stmts ---------------------------
  -- NAME:
  --     get_autosts_nb_stmts
  --
  -- DESCRIPTION:
  --     This function gets number of SQL statements in a Auto SQL tuning set
  --
  -- PARAMETERS:
  --     begin_time (IN) - Begini of the range of time
  --     end_time   (IN) - End of the range of time
  --
  -- RETURN:
  --     Number of SQL in SQL tuning sets.
  -----------------------------------------------------------------------------
  FUNCTION get_autosts_nb_stmts(begin_time IN DATE, end_time IN DATE)
  RETURN NUMBER;

  ------------------------------------ get_view_text --------------------------
  -- NAME:
  --     get_view_text
  --
  -- DESCRIPTION:
  --     This function is used to return the text of the sql to capture plans
  --     given a parse mode
  --
  -- PARAMETERS:
  --     parse_mode (IN) - parsing mode (PARSE_MOD_XXX constants)
  --
  -- RETURN:
  --     plan query text corresponding to the parsing mode
  --
  -- NOTE:
  --     Do not use this function with PARSE_MOD_AWR. Use get_awr_query_text
  --     instead, which builds an optimized SQL statement for capturing plans
  --     from AWR.
  -----------------------------------------------------------------------------
  FUNCTION get_view_text(parse_mode IN VARCHAR2)
  RETURN VARCHAR2;

  ----------------------------get_awr_query_text ------------------------------
  -- NAME:
  --     get_awr_query_text
  --
  -- DESCRIPTION:
  --     This function builds the text of the SQL statement that captures plans
  --     from AWR based on the flags passed as parameters
  --
  -- PARAMETERS:
  --     con_dbid_bind   (IN) - optionally include :con_dbid bind
  --     stmt_bind       (IN) - optionally include :sql_id, :phv, and :con_dbid
  --                            binds to target a single (statement, plan)
  --     begin_snap_op   (IN) - optionally include begin_snap: '>' or '>='
  --     stats_only      (IN) - if TRUE then select only from DBA_HIST_SQLSTAT,
  --                            otherwise join with DBA_HIST_SQLTEXT and
  --                            DBA_HIST_OPTIMIZER_ENV
  --     cmd_type_filter (IN) - set TRUE if no basic_filter is specified to
  --                            consider only certain types of statements:
  --                            1: create table, 2: insert, 3: select,
  --                            6: update, 7: delete, 189: merge
  --     awr_view        (IN) - AWR view location, allowed values are:
  --                            AWR_VIEW_ROOT and AWR_VIEW_PDB
  --
  -- RETURN:
  --     uniform AWR view query text
  --
  -- NOTES:
  --     1. It is important to only reference tables/views that the user can
  --        also access, since we run the select_xxx queries as invoker rights.
  --
  --     2. The predicate on the flag column of sqlstat is there to ensure that
  --        we only select sqls that have a full set of data in AWR
  --        (see bug #5659183).
  -----------------------------------------------------------------------------
  FUNCTION get_awr_query_text(
    con_dbid_bind   IN BOOLEAN := FALSE,
    stmt_bind       IN BOOLEAN := FALSE,
    begin_snap_op   IN NUMBER  := 0,
    stats_only      IN BOOLEAN := FALSE,
    cmd_type_filter IN BOOLEAN := FALSE,
    awr_view        IN VARCHAR2 := AWR_VIEW_ROOT)
  RETURN VARCHAR2;

  ------------------------------ validate_task_status -------------------------
  -- NAME:
  --     validate_task_status: check whether the task status is valid to
  --                           be reported
  --
  -- DESCRIPTION:
  --     A task report cannot be generated if the task status is INITIAL
  --     or CANCELED
  --
  -- PARAMETERS:
  --     tid        (IN)     - task identifier
  --
  -- RETURN:
  --     VOID
  --
  -- NOTE:
  --     This function supports remote execution either via UMF or by task
  --     parameters.
  -----------------------------------------------------------------------------
  PROCEDURE validate_task_status(tid IN NUMBER);

  ----------------------------- get_execution_type ----------------------------
  -- NAME:
  --     get_execution_type: get type of a task execution
  --
  --
  -- DESCRIPTION:
  --     This functin retrieve the type of a given task execution
  --
  -- PARAMETERS:
  --     tid        (IN)     - task identifier
  --     ename      (IN)     - name of the execution
  --
  -- RETURN:
  --     VOID
  --
  -- NOTE:
  --     This function supports remote execution either via UMF or by task
  --     parameters.
  -----------------------------------------------------------------------------
  FUNCTION get_execution_type(tid VARCHAR2, ename VARCHAR2)
  RETURN VARCHAR2;

  ------------------------------ init_task_wkldobj ----------------------------
  -- NAME:
  --     init_task_wkldobj: initialize the task_wkldobj structure
  --                        specifying the target of this tuning task.
  --
  -- DESCRIPTION:
  --     This procedure initializes our structure of that defines the object
  --     type of the workload as well as all of its properties.  We pass
  --     it to different functions in the report that need to have logic about
  --     the input.
  --
  -- PARAMETERS:
  --     tid        (IN)         - task ID
  --     begin_exec (IN)         - first execution name for the report
  --                               (auto wkld only)
  --     end_exec   (IN)         - last execution name for the report
  --                               (auto wkld only)
  --     target     (OUT NOCOPY) - initialized task_wkldobj structure
  --
  -- RETURN:
  --     VOID
  --
  -- RAISES:
  --     NO_DATA_FOUND if the workload object cannot be located
  --
  -- NOTE:
  --     This function supports remote execution either via UMF or by task
  --     parameters.
  -----------------------------------------------------------------------------
  PROCEDURE init_task_wkldobj(
    tid        IN         NUMBER,
    begin_exec IN         VARCHAR2 := NULL,
    end_exec   IN         VARCHAR2 := NULL,
    wkld       OUT NOCOPY task_wkldobj);

  ---------------------------- init_task_spaobj -------------------------------
  -- NAME:
  --     init_task_spaobj: initialize the task_spaobj structure specifying
  --                       the target of this tuning task.
  --
  -- DESCRIPTION:
  --     This procedure initializes our structure of that defines the object
  --     type of SPA task whose regressions will be tuned by the tuning task.
  --
  -- PARAMETERS:
  --     tid             (IN)         - task ID
  --     comp_exec_name  (IN)         - execution name of compare performance
  --                                    trial for the SPA task
  --     spa_task     (OUT NOCOPY)    - initialized task_wkldobj structure
  --
  -- RETURN:
  --     VOID
  --
  -----------------------------------------------------------------------------
  PROCEDURE init_task_spaobj(
    tid              IN         NUMBER,
    task_name        IN         VARCHAR2,
    comp_exec_name   IN         VARCHAR2,
    spa_task         OUT NOCOPY task_spaobj);

  ------------------------------ get_wkldtype_name ----------------------------
  -- NAME:
  --     get_wkldtype_name
  --
  -- DESCRIPTION:
  --     This function returns the string version of the workload type
  --     number.
  --
  -- PARAMETERS:
  --     type_num  (IN) - OBJ_XXX# constant
  --
  -- RETURN:
  --     Workload type name
  -----------------------------------------------------------------------------
  FUNCTION get_wkldtype_name(type_num IN NUMBER)
  RETURN   VARCHAR2;

  --------------------------------- validate_name -----------------------------
  -- NAME:
  --     validate_name
  --
  -- DESCRIPTION:
  --     This function checks whether a given name (e.g. sqlset name) is valid.
  --     It is just a syntactic checker, i.e., it does not check whether the
  --     object actually exists.
  --
  -- PARAMETERS:
  --     name       (IN) - name to validate
  --     type       (IN) - type of identifier to validate
  --
  -- RETURN:
  --     VOID if the name is valid, otherwise an appropriate error
  ----------------------------------------------------------------------------
  PROCEDURE validate_name(name IN VARCHAR2, type IN BINARY_INTEGER := NULL);

  -------------------------- alter_session_parameter -------------------------
  -- NAME:
  --     alter_session_parameter
  --
  -- DESCRIPTION:
  --     This function sets the indicated parameter to a hardcoded value
  --     if it is currently different, and returns a boolean value indicating
  --     whether or not the value had to be changed.
  --
  --     It is designed to be pretty generic so we can use it for different
  --     parameters but not so generic to cause SQL injections.  Right now
  --     it won't work for anything more than a simple on/off value.
  --     Values are hardcoded because for the simple boolean scenario it is
  --     unlikely that we would need to change a session parameter to have
  --     different values.  Typical usage model is as follows:
  --
  --     prm_set := alter_session_parameter(PNUM_XXX);
  --
  --     ...
  --
  --     if (prm_set) then
  --       restore_session_parameter(PNUM_XXX);
  --     end if;
  --
  -- PARAMETERS:
  --     pnum  (IN) - parameter number as PNUM_XXX constant
  --         PNUM_SYSPLS_OBEY_FORCE: set _parallel_syspls_obey_force to FALSE
  --
  --
  -- RETURN:
  --     TRUE if the parameter value needed to be changed
  ----------------------------------------------------------------------------
  FUNCTION alter_session_parameter(pnum IN NUMBER)
  RETURN BOOLEAN;

  -------------------------- restore_session_parameter -----------------------
  -- NAME:
  --     restore_session_parameter
  --
  -- DESCRIPTION:
  --     This function follows up on a call to set_session_parameter by
  --     clearing it back to its initial value.  It should only be called
  --     when the set function returns TRUE indicating the value was changed.
  --
  -- PARAMETERS:
  --     pnum  (IN) - parameter number as PNUM_XXX constant
  --
  -- RETURN:
  --     NONE
  ----------------------------------------------------------------------------
  PROCEDURE restore_session_parameter(pnum IN NUMBER);

  ----------------------------- is_fix_control_on ----------------------------
  -- NAME:
  --     is_fix_control_on
  --
  -- DESCRIPTION:
  --     This function verify if fix control is on in session for the
  --     respective bug number.
  --
  -- PARAMETERS:
  --     bug_number (IN) - bug number to verify
  --
  -- RETURN:
  --     TRUE if the bug number has fix control on, FALSE elsewhere.
  ----------------------------------------------------------------------------
  FUNCTION is_fix_control_on(bug_number IN NUMBER)
  RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(IS_FIX_CONTROL_ON, READ_ONLY);

  -------------------------------- ds_setting --------------------------------
  -- NAME:
  --     ds_setting
  --
  -- DESCRIPTION:
  --     This function set dyanmic_sampling to 11 and other parameters to
  --     avoid ORA-01002 during old style ds when stmt has table functions.
  --     See bugs 6708183, 26578934 and 29996208
  --
  -- PARAMETERS:
  --     None
  --
  -- RETURN:
  --     String that can be used for reset the ds 11 setting.
  ----------------------------------------------------------------------------
  PROCEDURE ds_setting(reset_str out NOCOPY varchar2);

  ------------------------------- get_current_time ---------------------------
  -- NAME:
  --     get_current_time
  --
  -- DESCRIPTION:
  --     Just a wrapper around ksugctm().
  --
  -- PARAMETERS:
  --     None
  --
  -- RETURN:
  --     current time (from ksugctm) as DATE
  ----------------------------------------------------------------------------
  FUNCTION get_current_time
  RETURN DATE;

  ----------------------------- get_dbid_from_conid ---------------------------
  --
  -- NAME:
  --     get_dbid_from_conid - Get con Dbid From Conid
  --
  -- DESCRIPTION:
  --     This function returns the container dbid for a container id. If not in
  --     in a cdb environment, it simply returns the dbid from v$database.
  --
  -- PARAMETERS:
  --     con_id    (IN)  - (REQUIRED) CDB container id
  --
  -- RETURNS:
  --     con_dbid for the given con_id
  -----------------------------------------------------------------------------
  FUNCTION get_dbid_from_conid(con_id IN PLS_INTEGER)
  RETURN NUMBER;

  -------------------------------- resolve_db_type ----------------------------
  -- NAME:
  --     resolve_db_type
  --
  -- DESCRIPTION:
  --     This function resolves the type of database that corresponds to the
  --     dbid given as parameter. It is used by get_awr_view_location function
  --     to determine the location of AWR views.
  --
  -- PARAMETERS:
  --     dbid            (IN)  - database id
  --
  -- RETURN:
  --     Returned type can be 'ROOT', 'PDB' or 'IMPORTED'.
  --
  -----------------------------------------------------------------------------
  FUNCTION resolve_db_type(dbid IN NUMBER)
  RETURN VARCHAR2;

  ----------------------------- get_awr_view_location -------------------------
  -- NAME:
  --     get_awr_view_location
  --
  -- DESCRIPTION:
  --     This function determines the location/prefix of the AWR view to use
  --     for the database that corresponds to the dbid parameter.
  --
  -- PARAMETERS:
  --     dbid            (IN)  - database id
  --
  -- RETURN:
  --     Returned type can be 'AWR_ROOT' or 'AWR_PDB'.
  --
  -----------------------------------------------------------------------------
  FUNCTION get_awr_view_location(dbid IN NUMBER)
  RETURN VARCHAR2;

  --------------------------- is_running_fake_cc_test -------------------------
  -- NAME:
  --     is_running_fake_cc_test: check if we are running the fake cc tests
  --
  --
  -- DESCRIPTION:
  --     Determine from _sta_control, if we are running fake cursor cache
  --     tests. The capture sts queries are parsed differently for those tests.
  --
  -- PARAMETERS:
  --     MONE
  --
  -- RETURN:
  --     TRUE if we are running fake cc tests, FALSE otherwise
  ----------------------------------------------------------------------------
  FUNCTION is_running_fake_cc_test
  RETURN BOOLEAN;

  ---------------------------- is_standby -----------------------------
  -- NAME:
  --    is_standby
  --
  -- DESCRIPTION:
  --    check current DB is a physical standby.
  --
  -- PARAMETERS:
  --
  --
  -- RETURNS
  --    boolean : When a DB is a physical standby TRUE is returned,
  --              otherwise FALSE.
  -----------------------------------------------------------------------------
  FUNCTION is_standby
  return BOOLEAN;

  --------------------------- check_stby_oper --------------------------------
  -- NAME:
  --    check_stby_oper
  --
  -- DESCRIPTION:
  --    This procedure raises an error if it is called from a standby db and
  --    returns otherwise.
  --
  -- PARAMETERS:
  --    VOID
  --
  -- RETURNS:
  --    VOID
  --
  -----------------------------------------------------------------------------
  PROCEDURE check_stby_oper;

  ---------------------------- get_seq_remote ------------------------
  -- NAME:
  --    get_seq_remote
  --
  -- DESCRIPTION:
  --    This PL/SQL function to get sequence from primary
  --    when it is required at standby.
  --
  --
  -- PARAMETERS:
  --    seq_name(IN)  - sequence name
  --    ref_id  (OUT) - sqlset reference id
  --
  -- NOTES:
  --   Sequence like WRI$_SQLSET_REF_ID_SEQ is defined with NOCACHE .
  --   Only cached sequence can be accessed on standby. Therefore ref_id
  --   is retrieved from primary. To retrieve ref_id the following query need
  --   to be executed:
  --    SELECT sys.wri$_sqlset_ref_id_seq.NEXTVAL FROM DUAL
  --   We can't execute this query remotely by adding a db link to dual
  --   as it is always try to get a local ref_id. Therefore this query
  --   need to be executed via OCI using a remote service context.
  --   To serve such purpose, get_sqlset_ref_id_callout is calling
  --   a C function.
  -----------------------------------------------------------------------------
  PROCEDURE get_seq_remote(seq_name IN VARCHAR2, ref_id OUT NUMBER)
  ACCESSIBLE BY (PACKAGE SYS.DBMS_SQLTUNE_INTERNAL);

  ---------------------------- get_task_name ---------------------------------
  -- NAME:
  --    get_task_name
  --
  -- DESCRIPTION:
  --    This function gets task_name of a given task_id
  --
  --
  -- PARAMETERS:
  --     task_id    (IN) - task id
  -- RETURNS
  --     task name
  --
  -----------------------------------------------------------------------------
  FUNCTION get_task_name(task_id    IN NUMBER)
  RETURN VARCHAR2;

  ---------------------------- init_remote_context ----------------------------
  -- NAME:
  --    init_remote_context
  --
  -- DESCRIPTION:
  --    This procedure initialize db_links to/from a remote db
  --    to global variable sqlt_rmt_ctx.
  --
  -- PARAMETERS:
  --     task_name      (IN)  - task name
  --     db_link_to     (IN)  - database link to remote db
  --     db_link_reqd   (IN)  - database link required
  --     user_id        (IN)  - logged in user id
  -- RETURNS
  --    VOID
  -- NOTES
  -- remote context is required for a remote query.
  -- init_remote_context is called for sql tuning advisor APIs like
  -- create_tuning_task, execute_tuning_task.
  --
  -----------------------------------------------------------------------------
  PROCEDURE init_remote_context(
    task_name        IN VARCHAR2             := NULL,
    db_link_to       IN VARCHAR2             := NULL,
    db_link_reqd     IN BOOLEAN              := FALSE,
    user_id          IN BINARY_INTEGER       := -1 );

  ---------------------------- copy_clob -----------------------------
  -- NAME:
  --    copy clob
  --
  -- DESCRIPTION:
  --    This procedure returns copying values from remote/local CLOB
  --    to local/remote CLOB
  --
  --
  -- PARAMETERS:
  --     inCLOB (IN) - remote/local CLOB
  --     outCLOB(IN/OUT)- local/remote CLOB
  --
  -- RETURNS
  --  void
  --
  -----------------------------------------------------------------------------
  PROCEDURE copy_clob(
    inCLOB IN CLOB,
    outCLOB IN OUT NOCOPY CLOB);

  ------------------------------ is_adaptive_plan ----------------------------
  -- NAME:
  --    is_adaptive_plan
  --
  -- DESCRIPTION:
  --    This function returns TRUE when the specified plan is an adaptive one
  --
  --
  -- PARAMETERS:
  --     task_id (IN)  - Identifier of the task
  --     exec_name(IN) - Execution name
  --     plan_id       - Identifier of the execution plan
  --     plan_hash     - Hash value of the execution plan
  --
  -- RETURNS
  --     BOOLEAN: TRUE when the specified plan is adaptive; FALSE otherwise
  --
  -----------------------------------------------------------------------------
  FUNCTION is_adaptive_plan(
    task_id   IN   NUMBER,
    exec_name IN   VARCHAR2,
    plan_id   IN   NUMBER,
    plan_hash IN   NUMBER)
  RETURN BOOLEAN;

  -------------------------- replace_awr_view_prefix --------------------------
  -- NAME:
  --   replace_awr_view_prefix
  --
  -- DESCRIPTION:
  --   Replaces awr view prefix in the sql text with p_awr_view_prefix
  --
  -- PARAMETERS:
  --   p_qry                (IN OUT) - sql to replace
  --   p_awr_view_prefix    (IN OUT) - awr view prefix
  --
  -- RETURNS
  --   modified sql
  --
  PROCEDURE replace_awr_view_prefix(
    p_qry               IN OUT varchar2,
    p_awr_view_prefix   IN OUT varchar2);

  ------------------------------- resolve_exec_name ---------------------------
  -- NAME:
  --     resolve_exec_name
  --
  -- DESCRIPTION:
  --     This function validates the execution name of a SPA task to ensure
  --     it was a Compare Performance (type id 5) while if NULL was supplied,
  --     it returns the name of the most recent compare execution for the
  --     given SPA task.
  --
  -- PARAMETERS:
  --     task_name         (IN)     - name of the SPA task whose execution we
  --                                  are examining
  --     compare_exec_name (IN/OUT) - execution name
  --
  -- RETURN:
  --     TRUE if exec_name was valid or we found a valid compare execution
  --     name of the given SPA task, FALSE otherwise
  --
  -----------------------------------------------------------------------------
  FUNCTION resolve_exec_name(
    task_name   IN     VARCHAR2,
    task_owner  IN     VARCHAR2,
    exec_name   IN OUT VARCHAR2)
  RETURN NUMBER;

  ---------------------------- is_exadata_profile -----------------------------
  -- NAME:
  --    is_exadata_profile
  --
  -- DESCRIPTION:
  --    check whether an Exadata-aware profile exists
  --    for a task referenced by a given task_id
  --
  -- PARAMETERS:
  --    tid (IN) - task id
  --
  -- RETURNS
  --    boolean : IF Exadata-aware profile exists TRUE is returned,
  --              otherwise FALSE.
  -----------------------------------------------------------------------------
  FUNCTION is_exadata_profile(tid number)
  return BOOLEAN;

  ----------------------------- is_session_monitored -------------------------
  -- NAME:
  --     is_session_monitored
  --
  -- DESCRIPTION:
  --     This function checks whether there is an active database operation
  --     that is monitoring a given session.
  --
  -- PARAMETERS:
  --     session_id (IN) - ID of the session
  --
  -- RETURN:
  --     TRUE if there is an active DBOP in status EXECUTING or QUEUED for that
  --     session, FALSE otherwise.
  --
  -----------------------------------------------------------------------------
  FUNCTION is_session_monitored(session_id IN NUMBER)
  RETURN BOOLEAN;


  ----------------------------- get_ash_sampling_info -------------------------
  -- NAME:
  --     get_ash_sampling_info
  --
  -- DESCRIPTION:
  --     This procedure is used to retrieve the oldest sample time as well as
  --     the sampling interval from ash
  --
  -- PARAMETERS:
  --     inst_id_low         (IN)  - instance low id
  --     inst_id_high        (IN)  - instance high id
  --     ash_oldest_sample   (OUT) - oldest sample date
  --     ash_sample_interval (OUT) - sampling interval
  -----------------------------------------------------------------------------
  PROCEDURE get_ash_sampling_info(
    inst_id_low         IN  NUMBER,
    inst_id_high        IN  NUMBER,
    ash_oldest_sample   OUT DATE,
    ash_sample_interval OUT NUMBER);

  ------------------------------- get_full_sqltext ---------------------------
  -- NAME:
  --     get_full_sqltext
  --
  -- DESCRIPTION:
  --     This procedures retrieves the full text of a given SQL from
  --     the cursor cache.
  --
  -- RETURNS:
  --     NONE
  -----------------------------------------------------------------------------
  PROCEDURE get_full_sqltext(
    sql_id       IN VARCHAR2,
    inst_id_low  IN NUMBER,
    inst_id_high IN NUMBER,
    full_sqltext IN OUT NOCOPY CLOB);

  ------------------------------ running_lrg_mode -----------------------------
  -- NAME:
  --     running_lrg_mode: check whether we are running in QA lrg mode
  --
  -- DESCRIPTION:
  --     This function checks whether the report is produced while running
  --     in lrg mode
  --
  -- PARAMETERS:
  --     MONE
  --
  -- RETURN:
  --     TRUE if running in lrg mode, otherwise FALSE.
  -----------------------------------------------------------------------------
  FUNCTION running_lrg_mode
  RETURN BOOLEAN;

END dbms_sqltune_util1;
/

