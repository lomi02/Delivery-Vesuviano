create PACKAGE dbms_type_utility AS

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);
  --
  PROCEDURE none;


END dbms_type_utility;
/

