create PACKAGE BODY dbms_type_utility wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
6c ae
FvTokws2nbPKVnKn+Xe/pkvy6gEwg5m49TOf9b9cuJu/9MNaoZdiSpYmVlrwlmL6R/pWJsO4
dIsGBp7nm7+fMr2ywFylTv7HXKU2GELFMJICVMdSrb5FEpI3UythnkBnvApPmUbDuFKbskoo
9HS48CiyCNIIdPSgyaamuAh2Pw==
/

