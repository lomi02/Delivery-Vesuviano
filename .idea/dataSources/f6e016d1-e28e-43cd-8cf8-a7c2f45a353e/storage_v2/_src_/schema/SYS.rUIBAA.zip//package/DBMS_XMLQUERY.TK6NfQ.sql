create PACKAGE DBMS_XMLQUERY AUTHID CURRENT_USER AS
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- types
  SUBTYPE ctxType IS NUMBER;                                 /* context type */
  SUBTYPE ctxHandle IS NUMBER;

  DEFAULT_ROWSETTAG   CONSTANT VARCHAR2(6) := 'ROWSET';         /* rowsettag */
  DEFAULT_ERRORTAG    CONSTANT VARCHAR2(5) := 'ERROR';          /* error tag */
  DEFAULT_ROWIDATTR   CONSTANT VARCHAR2(3) := 'NUM';          /* Row ID attr */
  DEFAULT_ROWTAG      CONSTANT VARCHAR2(3) := 'ROW';               /* rowtag */
  DEFAULT_DATE_FORMAT CONSTANT VARCHAR2(21):= 'MM/dd/yyyy HH:mm:ss';

  ALL_ROWS            CONSTANT NUMBER      := -1;      /* NO MAX, render all */

  NONE                CONSTANT NUMBER      := 0;                  /* NO META */
  DTD                 CONSTANT NUMBER      := 1;               /* META = DTD */
  SCHEMA              CONSTANT NUMBER      := 2;            /* META = SCHEMA */

  LOWER_CASE          CONSTANT NUMBER      := 1;               /* LOWER case */
  UPPER_CASE          CONSTANT NUMBER      := 2;               /* UPPER case */

  -- used to signal that the DB encoding is to be used
  DB_ENCODING          CONSTANT VARCHAR2(1) := '_';

  ----------------------------- misc functions ------------------------------
  PROCEDURE getVersion;

  -------------------- constructor/destructor functions ---------------------
  FUNCTION newContext(sqlQuery IN VARCHAR2) RETURN ctxType;
  FUNCTION newContext(sqlQuery IN CLOB) RETURN ctxType;
  PROCEDURE closeContext(ctxHdl IN ctxType);

  -------------------- parameters to the XML generation engine ----------------
  PROCEDURE setRowsetTag(ctxHdl IN ctxType, tag IN VARCHAR2);
  PROCEDURE setRowTag(ctxHdl IN ctxType, tag IN VARCHAR2);
  PROCEDURE setErrorTag(ctxHdl IN ctxType, tag IN VARCHAR2);

  PROCEDURE setRowIdAttrName(ctxHdl IN ctxType, attrName IN VARCHAR2);
  PROCEDURE setRowIdAttrValue(ctxHdl IN ctxType, colName IN VARCHAR2);
  PROCEDURE setCollIdAttrName(ctxHdl IN ctxType, attrName IN VARCHAR2);
  PROCEDURE useTypeForCollElemTag(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE useNullAttributeIndicator(ctxHdl IN ctxType, flag IN BOOLEAN := true);

  PROCEDURE setSQLToXMLNameEscaping(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE setTagCase(ctxHdl IN ctxType, tCase IN NUMBER);
  PROCEDURE setDateFormat(ctxHdl IN ctxType, mask IN VARCHAR2);

  PROCEDURE setMaxRows (ctxHdl IN ctxType, rows IN NUMBER);
  PROCEDURE setSkipRows(ctxHdl IN ctxType, rows IN NUMBER);

  PROCEDURE setStylesheetHeader(ctxHdl IN ctxType, uri IN VARCHAR2, type IN VARCHAR2 := 'text/xsl');
  PROCEDURE setXSLT(ctxHdl IN ctxType,uri IN VARCHAR2,ref IN VARCHAR2 := null);
  PROCEDURE setXSLT(ctxHdl IN ctxType, stylesheet IN CLOB, ref IN VARCHAR2 := null);
  PROCEDURE setXSLTParam(ctxHdl IN ctxType,name IN VARCHAR2,value IN VARCHAR2);
  PROCEDURE removeXSLTParam(ctxHdl IN ctxType, name IN VARCHAR2);

  PROCEDURE setStrictLegalXMLCharCheck(ctxHdl IN ctxType, flag IN BOOLEAN := true);

  PROCEDURE setEncodingTag(ctxHdl IN ctxType, enc IN VARCHAR2 := DB_ENCODING);

  PROCEDURE setBindValue(ctxHdl IN ctxType, bindName IN VARCHAR2, bindValue IN VARCHAR2);
  PROCEDURE clearBindValues(ctxHdl IN ctxType);

  PROCEDURE setMetaHeader(ctxHdl IN ctxType, header IN CLOB := null);
  PROCEDURE setDataHeader(ctxHdl IN ctxType, header IN CLOB := null, tag IN VARCHAR2 := null);

  PROCEDURE setRaiseException(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE setRaiseNoRowsException(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE propagateOriginalException(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE getExceptionContent(ctxHdl IN ctxType, errNo OUT NUMBER, errMsg OUT VARCHAR2);

  ------------------- generation ----------------------------------------------
  FUNCTION  getDTD(ctxHdl IN ctxType, withVer IN BOOLEAN := false) RETURN CLOB;
  PROCEDURE getDTD(ctxHdl IN ctxType, xDoc IN CLOB, withVer IN BOOLEAN := false);

  FUNCTION  getXML(ctxHdl IN ctxType, metaType IN NUMBER := NONE) RETURN CLOB;
  PROCEDURE getXML(ctxHdl IN ctxType, xDoc IN CLOB, metaType IN NUMBER := NONE);
  FUNCTION  getXML(sqlQuery IN VARCHAR2, metaType IN NUMBER := NONE) RETURN CLOB;
  FUNCTION  getXML(sqlQuery IN CLOB, metaType IN NUMBER := NONE) RETURN CLOB;

  PROCEDURE resetResultSet(ctxHdl IN ctxType);
  FUNCTION  getNumRowsProcessed(ctxHdl IN ctxType) RETURN NUMBER;

  -------private method declarations------------------------------------------
  -- we must do this as a bug workaround; otherwise we get ora-600 [kgmexchi11]
  PROCEDURE p_useTypeForCollElemTag(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_useNullAttrInd(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setSQLToXMLNameEsc(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setStylesheetHeader(ctxHdl IN ctxType, uri IN VARCHAR2, type IN VARCHAR2);
  PROCEDURE p_setXSLT(ctxHdl IN ctxType, uri IN VARCHAR2, ref IN VARCHAR2);
  PROCEDURE p_setXSLT(ctxHdl IN ctxType, stylesheet IN CLOB, ref IN VARCHAR2);
  PROCEDURE p_setStrictLegalXMLCharCheck(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setEncodingTag(ctxHdl IN ctxType, enc IN VARCHAR2);
  PROCEDURE p_setMetaHeader(ctxHdl IN ctxType, header IN CLOB);
  PROCEDURE p_setDataHeader(ctxHdl IN ctxType, header IN CLOB,tag IN VARCHAR2);
  PROCEDURE p_setRaiseException(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setRaiseNoRowsExc(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_propOrigExc(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_getDTD(ctxHdl IN ctxType, xDoc IN CLOB, withVer IN NUMBER);
  PROCEDURE p_getXML(ctxHdl IN ctxType, xDoc IN CLOB, metaType IN NUMBER);

END dbms_xmlquery;
/

