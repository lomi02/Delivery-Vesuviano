create package body     diana is

  function  a_ACTUAL(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,1);
  end;

  function  a_ALIGNM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,2);
  end;

  function  a_BINARY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,3);
  end;

  function  a_BLOCK_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,4);
  end;

  function  a_CLUSTE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,5);
  end;

  function  a_CONNEC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,6);
  end;

  function  a_CONSTD(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,7);
  end;

  function  a_CONSTT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,8);
  end;

  function  a_CONTEX(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,9);
  end;

  function  a_D_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,10);
  end;

  function  a_D_CHAR(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,11);
  end;

  function  a_D_R_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,12);
  end;

  function  a_D_R_VO(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,13);
  end;

  function  a_EXCEPT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,14);
  end;

  function  a_EXP(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,15);
  end;

  function  a_EXP1(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,16);
  end;

  function  a_EXP2(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,17);
  end;

  function  a_EXP_VO(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,18);
  end;

  function  a_FORM_D(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,19);
  end;

  function  a_HAVING(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,20);
  end;

  function  a_HEADER(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,21);
  end;

  function  a_ID(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,22);
  end;

  function  a_INDICA(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,23);
  end;

  function  a_ITERAT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,24);
  end;

  function  a_MEMBER(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,25);
  end;

  function  a_NAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,26);
  end;

  function  a_NAME_V(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,27);
  end;

  function  a_NOT_NU(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,28);
  end;

  function  a_OBJECT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,29);
  end;

  function  a_P_IFC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,30);
  end;

  function  a_PACKAG(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,31);
  end;

  function  a_RANGE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,32);
  end;

  function  a_SPACE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,33);
  end;

  function  a_STM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,34);
  end;

  function  a_SUBPRO(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,35);
  end;

  function  a_SUBUNI(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,36);
  end;

  function  a_TRANS(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,37);
  end;

  function  a_TYPE_R(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,38);
  end;

  function  a_TYPE_S(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,39);
  end;

  function  a_UNIT_B(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,40);
  end;

  function  a_UP(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,41);
  end;

  function  a_WHERE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,42);
  end;

  function  as_ALTER(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,43);
  end;

  function  as_APPLY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,44);
  end;

  function  as_CHOIC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,45);
  end;

  function  as_COMP_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,46);
  end;

  function  as_DECL1(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,47);
  end;

  function  as_DECL2(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,48);
  end;

  function  as_DSCRM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,49);
  end;

  function  as_DSCRT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,50);
  end;

  function  as_EXP(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,51);
  end;

  function  as_FROM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,52);
  end;

  function  as_GROUP(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,53);
  end;

  function  as_ID(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,54);
  end;

  function  as_INTO_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,55);
  end;

  function  as_ITEM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,56);
  end;

  function  as_LIST(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,57);
  end;

  function  as_NAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,58);
  end;

  function  as_ORDER(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,59);
  end;

  function  as_P_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,60);
  end;

  function  as_P_ASS(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,61);
  end;

  function  as_PRAGM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,62);
  end;

  function  as_SET_C(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,63);
  end;

  function  as_STM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,64);
  end;

  function  c_ENTRY_(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,65);
  end;

  function  c_FIXUP(node pidl.ptnod) return pidl.ptr_t is
  begin
    return pidl.ptg_pt(node,66);
  end;

  function  c_FRAME_(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,67);
  end;

  function  c_LABEL(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,68);
  end;

  function  c_OFFSET(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,69);
  end;

  function  c_VAR(node pidl.ptnod) return pidl.ptr_t is
  begin
    return pidl.ptg_pt(node,70);
  end;

  function  l_DEFAUL(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,71);
  end;

  function  l_INDREP(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,72);
  end;

  function  l_NUMREP(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,73);
  end;

  function  l_Q_HINT(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,74);
  end;

  function  l_SYMREP(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,75);
  end;

  function  s_ADDRES(node pidl.ptnod) return pidl.sb4 is
  begin
    return pidl.ptg_s4(node,76);
  end;

  function  s_ADEFN(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,77);
  end;

  function  s_BASE_T(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,78);
  end;

  function  s_BLOCK(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,79);
  end;

  function  s_BODY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,80);
  end;

  function  s_COMP_S(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,81);
  end;

  function  s_CONSTR(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,82);
  end;

  function  s_DEFN_PRIVATE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,83);
  end;

  function  s_DISCRI(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,84);
  end;

  function  s_EXCEPT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,85);
  end;

  function  s_EXP_TY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,86);
  end;

  function  s_FIRST(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,87);
  end;

  function  s_FRAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,88);
  end;

  function  s_IN_OUT(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,89);
  end;

  function  s_INIT_E(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,90);
  end;

  function  s_INTERF(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,91);
  end;

  function  s_LAYER(node pidl.ptnod) return pidl.sb4 is
  begin
    return pidl.ptg_s4(node,92);
  end;

  function  s_LOCATI(node pidl.ptnod) return pidl.sb4 is
  begin
    return pidl.ptg_s4(node,93);
  end;

  function  s_NORMARGLIST(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,94);
  end;

  function  s_NOT_NU(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,95);
  end;

  function  s_OBJ_DE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,96);
  end;

  function  s_OBJ_TY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,97);
  end;

  function  s_OPERAT(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,98);
  end;

  function  s_PACKIN(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,99);
  end;

  function  s_POS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,100);
  end;

  function  s_RECORD(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,101);
  end;

  function  s_REP(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,102);
  end;

  function  s_SCOPE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,103);
  end;

  function  s_SIZE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,104);
  end;

  function  s_SPEC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,105);
  end;

  function  s_STM(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,106);
  end;

  function  s_STUB(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,107);
  end;

  function  s_T_SPEC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,108);
  end;

  function  s_T_STRU(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,109);
  end;

  function  s_VALUE(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,110);
  end;

  function  ss_BINDS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,111);
  end;

  function  ss_BUCKE(node pidl.ptnod) return pidl.ptr_t is
  begin
    return pidl.ptg_pt(node,112);
  end;

  function  ss_EXLST(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,113);
  end;

  function  ss_SQL(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,114);
  end;

  function  a_CALL(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,115);
  end;

  function  a_CHARSET(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,116);
  end;

  function  a_CS(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,117);
  end;

  function  a_EXT_TY(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,118);
  end;

  function  a_FILE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,119);
  end;

  function  a_FLAGS(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,120);
  end;

  function  a_LANG(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,121);
  end;

  function  a_LIB(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,122);
  end;

  function  a_METH_FLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,123);
  end;

  function  a_PARTN(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,124);
  end;

  function  a_REFIN(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,125);
  end;

  function  a_RTNING(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,126);
  end;

  function  a_STYLE(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,127);
  end;

  function  a_TFLAG(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,128);
  end;

  function  a_UNUSED(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,129);
  end;

  function  as_PARMS(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,130);
  end;

  function  l_RESTRICT_REFERENCES(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,131);
  end;

  function  s_CHARSET_EXPR(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,132);
  end;

  function  s_CHARSET_FORM(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,133);
  end;

  function  s_CHARSET_VALUE(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,134);
  end;

  function  s_FLAGS(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,135);
  end;

  function  s_LIB_FLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,136);
  end;

  function  ss_PRAGM_L(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,137);
  end;

  function  a_AUTHID(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,138);
  end;

  function  a_BIND(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,139);
  end;

  function  a_OPAQUE_SIZE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,140);
  end;

  function  a_OPAQUE_USELIB(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,141);
  end;

  function  a_SCHEMA(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,142);
  end;

  function  a_STM_STRING(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,143);
  end;

  function  a_SUPERTYPE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,144);
  end;

  function  as_USING_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,145);
  end;

  function  s_INTRO_VERSION(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,146);
  end;

  function  a_LIMIT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,147);
  end;

  function  a_PERCENT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,148);
  end;

  function  a_SAMPLE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,149);
  end;

  function  a_AGENT(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,150);
  end;

  function  a_AGENT_INDEX(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,151);
  end;

  function  a_AGENT_NAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,152);
  end;

  function  a_ALTERACT(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,153);
  end;

  function  a_BITFLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,154);
  end;

  function  a_EXTERNAL(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,155);
  end;

  function  a_EXTERNAL_CLASS(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,156);
  end;

  function  a_HANDLE(node pidl.ptnod) return pidl.ptr_t is
  begin
    return pidl.ptg_pt(node,157);
  end;

  function  a_IDENTIFIER(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,158);
  end;

  function  a_KIND(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,159);
  end;

  function  a_LIBAGENT_NAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,160);
  end;

  function  a_NUM_INH_ATTR(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,161);
  end;

  function  a_ORIGINAL(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,162);
  end;

  function  a_PARALLEL_SPEC(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,163);
  end;

  function  a_PARTITIONING(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,164);
  end;

  function  a_STREAMING(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,165);
  end;

  function  a_TYPE_BODY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,166);
  end;

  function  as_ALTERS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,167);
  end;

  function  as_ALTS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,168);
  end;

  function  as_ALTTYPS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,169);
  end;

  function  as_HIDDEN(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,170);
  end;

  function  c_ENTRY_PT(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,171);
  end;

  function  c_VT_INDEX(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,172);
  end;

  function  l_TYPENAME(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,173);
  end;

  function  s_CMP_TY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,174);
  end;

  function  s_CURRENT_OF(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,175);
  end;

  function  s_DECL(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,176);
  end;

  function  s_LENGTH_SEMANTICS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,177);
  end;

  function  s_STMT_FLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,178);
  end;

  function  s_VTFLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,179);
  end;

  function  ss_FUNCTIONS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,180);
  end;

  function  ss_INTO(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,181);
  end;

  function  ss_LOCALS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,182);
  end;

  function  ss_TABLES(node pidl.ptnod) return pidl.ptr_t is
  begin
    return pidl.ptg_pt(node,183);
  end;

  function  ss_VTABLE(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,184);
  end;

  function  a_BEGCOL(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,185);
  end;

  function  a_BEGLIN(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,186);
  end;

  function  a_ENDCOL(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,187);
  end;

  function  a_ENDLIN(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,188);
  end;

  function  s_BLKFLG(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,189);
  end;

  function  s_INDCOL(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,190);
  end;

  function  a_IDENTITY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,191);
  end;

  function  a_SECURITY(node pidl.ptnod) return pidl.ub2 is
  begin
    return pidl.ptg_u2(node,192);
  end;

  function  as_RELIES_ON(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,193);
  end;

  function  as_RESULTS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,194);
  end;

  function  s_DEP_NUM(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,195);
  end;

  function  s_FG_POS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,196);
  end;

  function  s_FG_REFS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,197);
  end;

  function  s_FG_SIG(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,198);
  end;

  function  s_ITEMS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,199);
  end;

  function  s_NAME(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,200);
  end;

  function  s_OBJN(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,201);
  end;

  function  s_PLSC_SIG(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,202);
  end;

  function  s_TYP(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,203);
  end;

  function  ss_PLSCOPE(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,204);
  end;

  function  a_CRED(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,205);
  end;

  function  a_DIR(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,206);
  end;

  function  as_OIDTYPS(node pidl.ptnod) return pidl.ptseqnd is
  begin
    return pidl.ptgsnd(node,207);
  end;

  function  as_WHTLST(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,208);
  end;

  function  d_WHTLST_KIND(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,209);
  end;

  function  d_WHTLST_NAME(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,210);
  end;

  function  d_WHTLST_SCHEMA(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,211);
  end;

  function  s_ALS(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,212);
  end;

  function  s_TOID(node pidl.ptnod) return varchar2 is
  begin
    return pidl.ptg_tx(node,213);
  end;

  function  a_BITFLAGS2(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,214);
  end;

  function  a_EXT_FLAGS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,215);
  end;

  function  a_ON_ERR(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,216);
  end;

  function  a_D_NEW_(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,217);
  end;

  function  a_FMT(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,218);
  end;

  function  a_ID2(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,219);
  end;

  function  a_INDEX(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,220);
  end;

  function  a_KEY(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,221);
  end;

  function  a_MUTABLE(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,222);
  end;

  function  a_REPEAT(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,223);
  end;

  function  a_REVERS(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,224);
  end;

  function  a_SEQUENCE(node pidl.ptnod) return pidl.ub4 is
  begin
    return pidl.ptg_u4(node,225);
  end;

  function  a_STEP(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,226);
  end;

  function  a_WHEN(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,227);
  end;

  function  a_WHILE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,228);
  end;

  function  s_END_LBL(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,229);
  end;

  function  s_INDEX_TYPE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,230);
  end;

  function  s_VALUE_TYPE(node pidl.ptnod) return pidl.ptnod is
  begin
    return pidl.ptg_nd(node,231);
  end;


end diana;
/

