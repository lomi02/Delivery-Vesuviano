create PACKAGE sdo_rdf_exp_imp AUTHID CURRENT_USER AS

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE system_callout (
    prepost        IN    PLS_INTEGER,
    version        IN    VARCHAR2
  );

  --********************************************************--
  -- Called for each registered instance during export
  -- Return action='EXPORT' for 12.1 target
  -- Need to skip or return pre-created Views for
  -- older targets for downgrade to work properly
  PROCEDURE instance_export_action (
          obj_name      IN   VARCHAR2,
          obj_schema    IN   VARCHAR2,
          obj_type      IN   NUMBER,
          tgt_version   IN   VARCHAR2,
          action        OUT  VARCHAR2,
          alt_name      OUT  VARCHAR2,
          where_clause  OUT  VARCHAR2
  );
  -- Set action='EXPORT' for everything because pre-12.1 downgrade
  -- is not supported with this interface

  --*******************************************************--
  -- Called for each registered instance during import
  PROCEDURE instance_callout_imp (
             obj_name   IN   VARCHAR2,
             obj_schema IN   VARCHAR2,
             obj_type   IN   NUMBER,
             prepost    IN   PLS_INTEGER,
             action     OUT  VARCHAR2,
             alt_name   OUT  VARCHAR2
  );
  -- For prepost == 0
  --  * set alt_name for Views
  --  * set action='SKIP' (to prevent replacing existing data)
  --    or NOOP for tables
  --
  -- For prepost > 0
  --  * NOOP


  --******************************************************--
  -- Can do all fix up processing here when prepost=1
  PROCEDURE system_callout_imp (
             prepost    IN   PLS_INTEGER
  );
  -- For prepost == 0
  --  * NOOP
  --
  -- For prepost > 0
  --  * Fix/upgrade/index imported tables
  --  * Update sequences
  --  * Update RDF Parameter, note missing components
  --      * WM may not be installed on target system, need to
  --        fix this post-import
  --  * (re)create all views in semantic network
  --  * (re)create all views in optional components
  --  * (re)create all LINK$ views and triggers
  --  * Grant privileges on LINK$ views

END sdo_rdf_exp_imp;
/

