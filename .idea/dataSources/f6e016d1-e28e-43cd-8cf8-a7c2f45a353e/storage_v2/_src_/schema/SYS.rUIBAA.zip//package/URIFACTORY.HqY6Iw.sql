create package UriFactory authid current_user as

  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- returns the correct uritype
  function getUri(url IN varchar2) RETURN UriType;
  function unescapeUri(escapedurl IN varchar2) RETURN varchar2;
  function escapeUri(unescapedurl IN varchar2) RETURN varchar2;

  -- register a url handler..
  procedure registerUrlHandler(prefix in varchar2, schemaname in varchar2,
    typename in varchar2, ignorePrefixCase in boolean := true,
    stripprefix in boolean := true);

 procedure UnRegisterUrlHandler(prefix in varchar2);

end;
/

