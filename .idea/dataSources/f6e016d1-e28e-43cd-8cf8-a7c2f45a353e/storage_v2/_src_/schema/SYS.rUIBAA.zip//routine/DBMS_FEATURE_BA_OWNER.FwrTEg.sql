create PROCEDURE dbms_feature_ba_owner
      (feature_boolean OUT number,
       aux_count       OUT number,
       info            OUT clob)
AS
   owner     VARCHAR2(100);

BEGIN

   EXECUTE IMMEDIATE
   'BEGIN ' ||
   'SELECT dbms_rai_owner INTO :owner FROM DUAL; ' ||
   'EXCEPTION ' ||
   '   WHEN OTHERS THEN ' ||
   '   :owner := NULL; ' ||
   'END;' USING OUT owner;

   IF (owner IS NOT NULL) THEN
      feature_boolean := 1;
   ELSE
      feature_boolean := 0;
   END IF;

   aux_count := NULL;
   info := NULL;

END dbms_feature_ba_owner;
/

