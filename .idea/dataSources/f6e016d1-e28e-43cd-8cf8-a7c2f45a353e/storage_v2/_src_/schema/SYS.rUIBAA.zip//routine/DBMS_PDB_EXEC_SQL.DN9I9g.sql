create procedure dbms_pdb_exec_sql (sql_stmt varchar2)
  authid current_user as
begin
  dbms_pdb.exec_as_oracle_script(sql_stmt);
end;
/

