create function     KCISYS_BITMAPAGG(input AnyData)
return BLOB aggregate using sys.BitmapAggImp;
/

