create procedure     subptxt2(name varchar2, subname varchar2, usr varchar2,
                             dbname varchar2, dbowner varchar2,
                             txt in out varchar2) is
status diutil.ub4;

begin -- main
    diutil.subptxt(name, subname, usr, dbname, dbowner, txt, status);
    if (status <> diutil.s_ok) then
        if (status = diutil.s_subpNotFound) then
            txt := '$$$ s_subpNotFound';
        elsif (status = diutil.s_stubTooLong) then
            txt := '$$$ s_stubTooLong';
        elsif (status = diutil.s_logic) then
            txt := '$$$ s_logic';
        elsif (status = diutil.s_notInPackage) then
            txt := '$$$ s_notInPackage';
        else txt := '$$$ s_other';
        end if;
    end if;
end subptxt2;
/

