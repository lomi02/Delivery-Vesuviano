create type       wm$ed_undo_code_node_type                                                                        authid definer
         as object (index_type   integer,
                    index_field  integer,
                    sql_str      clob)
/

