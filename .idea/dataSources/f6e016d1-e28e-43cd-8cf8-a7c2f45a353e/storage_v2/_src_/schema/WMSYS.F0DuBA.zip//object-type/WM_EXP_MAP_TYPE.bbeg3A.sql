create type       wm$exp_map_type authid definer
         as object (code     integer,
                    nfield1  number,
                    nfield2  number,
                    nfield3  number,
                    vfield1  varchar2(128),
                    vfield2  varchar2(128),
                    vfield3  clob)
/

