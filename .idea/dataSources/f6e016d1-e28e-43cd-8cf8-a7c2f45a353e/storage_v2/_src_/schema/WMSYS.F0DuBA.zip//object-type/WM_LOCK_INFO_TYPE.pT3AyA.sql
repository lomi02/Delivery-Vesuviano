create type       wm$lock_info_type                                                                        authid definer
         as object (table_owner  varchar2(128),
                    table_name   varchar2(128),
                    info         varchar2(100))
/

