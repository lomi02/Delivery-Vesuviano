create view ALL_REMOVED_WORKSPACES as
select owner, workspace_name, workspace_id, parent_workspace_name, parent_workspace_id,
        createtime, retiretime, description, mp_root_id mp_root_workspace_id, decode(rwt.isRefreshed, 1, 'YES', 'NO') continually_refreshed
 from wmsys.wm$removed_workspaces_table rwt
 where exists (select 1 from wmsys.user_wm_privs where privilege = 'WM_ADMIN' or privilege like '%ANY%')
union
 select owner, workspace_name, workspace_id, parent_workspace_name, parent_workspace_id,
        createtime, retiretime, description, mp_root_id mp_root_workspace_id, decode(rwt.isRefreshed, 1, 'YES', 'NO') continually_refreshed
 from wmsys.wm$removed_workspaces_table rwt,
      (select distinct workspace from wmsys.user_wm_privs) u
 where rwt.workspace_name = u.workspace
union
 select owner, workspace_name, workspace_id, parent_workspace_name, parent_workspace_id,
        createtime, retiretime, description, mp_root_id mp_root_workspace_id, decode(rwt.isRefreshed, 1, 'YES', 'NO') continually_refreshed
 from wmsys.wm$removed_workspaces_table rwt
 where rwt.owner = sys_context('userenv', 'current_user')
WITH READ ONLY
/

