create view CDB_WM_SYS_PRIVS as
SELECT k."GRANTEE",k."PRIVILEGE",k."GRANTOR",k."GRANTABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("WMSYS"."DBA_WM_SYS_PRIVS") k
/

comment on table CDB_WM_SYS_PRIVS is ' in all containers'
/

comment on column CDB_WM_SYS_PRIVS.CON_ID is 'container id'
/

