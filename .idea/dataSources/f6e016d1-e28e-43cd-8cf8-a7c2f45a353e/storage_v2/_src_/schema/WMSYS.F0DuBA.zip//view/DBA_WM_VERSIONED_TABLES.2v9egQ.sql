create view DBA_WM_VERSIONED_TABLES as
select /*+ LEADING(t) */ t.table_name,
       t.owner,
       t.disabling_ver state,
       t.hist history,
       decode(t.notification, 0, 'NO', 1, 'YES') notification,
       substr(t.notifyWorkspaces, 2, length(notifyworkspaces)-2) notifyworkspaces,
       wmsys.owm_dynsql_access.AreThereConflicts(u.owner, u.view_name, t.vtid) conflict,
       wmsys.owm_dynsql_access.AreThereDiffs(u.owner, u.view_name, t.vtid) diff,
       decode(t.validtime, 0, 'NO', 1, 'YES') validtime
from wmsys.wm$versioned_tables t, dba_views u
where t.owner = u.owner and
      t.table_name = u.view_name
WITH READ ONLY
/

