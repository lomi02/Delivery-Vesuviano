create view USER_MP_GRAPH_WORKSPACES as
select mpg.mp_leaf_workspace, mpg.mp_graph_workspace graph_workspace,
       decode(mpg.mp_graph_flag, 'R', 'ROOT_WORKSPACE', 'I', 'INTERMEDIATE_WORKSPACE', 'L', 'LEAF_WORKSPACE') graph_flag
from wmsys.wm$mp_graph_workspaces_table mpg, wmsys.wm$workspaces_table$i wt
where wt.owner = sys_context('userenv', 'current_user') and
      mpg.mp_leaf_workspace = wt.workspace
WITH READ ONLY
/

