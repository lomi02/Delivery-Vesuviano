create trigger WM$CP_I_TRIG
    instead of insert
    on WM$COLUMN_PROPS
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$column_props$f(:new.identity_type) ;

  update wmsys.wm$versioned_tables$
  set wm$flag = wmsys.ltUtil.bitor(wmsys.ltUtil.bitclear(wm$flag, 98304), flag_v)
  where vtid# = vtid ;
end;
/

