create view WM_COMPRESS_BATCH_SIZES as
select /*+ RULE */ vt.owner, vt.table_name,
       (case dt.data_type
        when 'CHAR'      then (case when nvl(dt.num_buckets, 0) in (0,1) then 'TABLE' else 'TABLE/PRIMARY_KEY_RANGE' end)
        when 'VARCHAR2'  then (case when nvl(dt.num_buckets, 0) in (0,1) then 'TABLE' else 'TABLE/PRIMARY_KEY_RANGE' end)
        when 'NUMBER'    then (case when nvl(dt.num_buckets, 0) in (0)   then 'TABLE' else 'TABLE/PRIMARY_KEY_RANGE' end)
        when 'DATE'      then (case when nvl(dt.num_buckets, 0) in (0)   then 'TABLE' else 'TABLE/PRIMARY_KEY_RANGE' end)
        when 'TIMESTAMP' then (case when nvl(dt.num_buckets, 0) in (0)   then 'TABLE' else 'TABLE/PRIMARY_KEY_RANGE' end)
        else 'TABLE'
        end) batch_size,
       (case dt.data_type
        when 'CHAR'      then (case when nvl(dt.num_buckets, 0) in (0,1) then 1 else dt.num_buckets end)
        when 'VARCHAR2'  then (case when nvl(dt.num_buckets, 0) in (0,1) then 1 else dt.num_buckets end)
        when 'NUMBER'    then (case      nvl(dt.num_buckets, 0) when 0 then 1 when 1 then to_number(wmsys.owm_dynsql_access.GetSystemParameter('NUMBER_OF_COMPRESS_BATCHES')) else dt.num_buckets end)
        when 'DATE'      then (case      nvl(dt.num_buckets, 0) when 0 then 1 when 1 then to_number(wmsys.owm_dynsql_access.GetSystemParameter('NUMBER_OF_COMPRESS_BATCHES')) else dt.num_buckets end)
        when 'TIMESTAMP' then (case      nvl(dt.num_buckets, 0) when 0 then 1 when 1 then to_number(wmsys.owm_dynsql_access.GetSystemParameter('NUMBER_OF_COMPRESS_BATCHES')) else dt.num_buckets end)
        else 1
        end) num_batches
from wmsys.wm$versioned_tables vt, dba_ind_columns di, dba_tab_cols dt
where di.table_owner = vt.owner and
      di.table_name = vt.table_name || '_LT' and
      di.index_name = vt.table_name || '_PKI$' and
      di.column_position = 1 and
      dt.owner = vt.owner and
      dt.table_name = vt.table_name || '_LT' and
      dt.column_name = di.column_name and
      dt.user_generated = 'YES'
WITH READ ONLY
/

