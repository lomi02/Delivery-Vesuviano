create view WM$CONF2_HIERARCHY_VIEW as
select vht.version, vht.workspace#
 from wmsys.wm$version_hierarchy_table$ vht
 where vht.workspace# = sys_context('lt_ctx', 'parent_conflict_state_id')
union all
 select vht.version, vht.workspace#
 from wmsys.wm$version_table$ vt, wmsys.wm$version_hierarchy_table$ vht
 where vt.workspace# = sys_context('lt_ctx', 'parent_conflict_state_id') and
       vht.workspace# = vt.anc_workspace# and
       vht.version <= vt.anc_version
WITH READ ONLY
/

