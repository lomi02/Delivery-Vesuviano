create view WM$CONF_BASE_HIERARCHY_VIEW as
select vht.version
 from wmsys.wm$version_hierarchy_table$ vht
 where vht.workspace# = sys_context('lt_ctx', 'confbasever_id') and
       vht.version <= sys_context('lt_ctx', 'confbasever')
union all
 select vht.version
 from wmsys.wm$version_table$ vt, wmsys.wm$version_hierarchy_table$ vht
 where vt.workspace# = sys_context('lt_ctx', 'confbasever_id') and
       vht.workspace# = vt.anc_workspace# and
       vht.version <= vt.anc_version
WITH READ ONLY
/

