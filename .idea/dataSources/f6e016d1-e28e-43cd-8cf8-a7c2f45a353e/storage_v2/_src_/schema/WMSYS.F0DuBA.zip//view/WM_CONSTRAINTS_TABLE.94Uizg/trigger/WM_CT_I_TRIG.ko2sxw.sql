create trigger WM$CT_I_TRIG
    instead of insert
    on WM$CONSTRAINTS_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$constraints_table$f(:new.constraint_type, :new.status, :new.index_type) ;

  insert into wmsys.wm$constraints_table$(vtid#, constraint_name, search_condition, index_owner, index_name, aliasedcolumns, numindexcols, wm$flag, owner)
  values (vtid, :new.constraint_name, :new.search_condition, :new.index_owner, :new.index_name, :new.aliasedcolumns, :new.numindexcols, flag_v, :new.owner) ;
end;
/

