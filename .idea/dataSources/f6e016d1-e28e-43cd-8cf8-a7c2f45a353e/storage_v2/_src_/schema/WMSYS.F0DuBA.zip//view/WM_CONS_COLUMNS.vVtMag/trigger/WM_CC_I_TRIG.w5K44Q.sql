create trigger WM$CC_I_TRIG
    instead of insert
    on WM$CONS_COLUMNS
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  insert into wmsys.wm$cons_columns$(vtid#, constraint_name, column_name, position)
  values (vtid, :new.constraint_name, :new.column_name, :new.position) ;
end;
/

