create view WM$CURCONFLICT_PARVERS_VIEW as
select mt.version parent_vers, mt.vtid# vtid
from wmsys.wm$modified_tables$ mt
where mt.workspace# = sys_context('lt_ctx', 'conflict_state_id')
WITH READ ONLY
/

