create view WM$CURRENT_CONS_VERSIONS_VIEW as
select version
 from wmsys.wm$current_child_versions_view
union all
 select parent_vers
 from wmsys.wm$current_parvers_view
 where workspace = sys_context('lt_ctx', 'state') or
       nvl(sys_context('lt_ctx', 'rowlock_status'), 'X') <> 'F' or
       nvl(sys_context('lt_ctx', 'flip_version'), 'N') <> 'Y' or
       exists(select 1
              from wmsys.wm$mp_graph_workspaces_table
              where mp_graph_workspace = workspace and
                    mp_graph_flag <> 'R')
union all
 select version
 from wmsys.wm$mp_graph_cons_versions
union all
 select version
 from wmsys.wm$version_hierarchy_table
 where workspace in (select workspace
                     from wmsys.wm$version_table
                     where anc_workspace = sys_context('lt_ctx', 'state')) and
       nvl(sys_context('lt_ctx', 'rowlock_status'), 'X') = 'F' and
       nvl(sys_context('lt_ctx', 'flip_version'), 'N') = 'Y'
WITH READ ONLY
/

