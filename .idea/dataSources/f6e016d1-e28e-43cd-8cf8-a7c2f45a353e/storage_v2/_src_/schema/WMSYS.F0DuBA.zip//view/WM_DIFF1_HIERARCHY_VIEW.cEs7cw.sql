create view WM$DIFF1_HIERARCHY_VIEW as
select version
 from wmsys.wm$version_hierarchy_table$
 where workspace# = sys_context('lt_ctx', 'diffWspc1_id') and
       version <= decode(sys_context('lt_ctx', 'diffver1'),
                         -1, (select current_version
                              from wmsys.wm$workspaces_table$
                              where workspace_lock_id = sys_context('lt_ctx', 'diffWspc1_id')),
                         sys_context('lt_ctx', 'diffver1'))
union all
 select version
 from wmsys.wm$version_table$ vt, wmsys.wm$version_hierarchy_table$ vht
 where vt.workspace# = sys_context('lt_ctx', 'diffWspc1_id') and
       vt.anc_workspace# = vht.workspace# and
       vht.version <= vt.anc_version
WITH READ ONLY
/

