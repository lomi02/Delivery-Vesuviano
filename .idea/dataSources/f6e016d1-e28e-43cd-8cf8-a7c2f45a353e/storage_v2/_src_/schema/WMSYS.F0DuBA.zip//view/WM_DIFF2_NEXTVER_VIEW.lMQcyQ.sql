create view WM$DIFF2_NEXTVER_VIEW as
select next_vers
from wmsys.wm$nextver_table$
where version in (select version from wmsys.wm$diff2_hierarchy_view)
WITH READ ONLY
/

