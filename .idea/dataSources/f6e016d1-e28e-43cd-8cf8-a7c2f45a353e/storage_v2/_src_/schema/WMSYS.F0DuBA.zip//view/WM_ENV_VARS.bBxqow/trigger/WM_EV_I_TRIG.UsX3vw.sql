create trigger WM$EV_I_TRIG
    instead of insert
    on WM$ENV_VARS
    for each row
declare
  flag_v integer := 0;
begin
  flag_v := wmsys.owm_dml_pkg.wm$env_vars$f(:new.hidden) ;

  insert into wmsys.wm$env_vars$(name, value, wm$flag)
  values (:new.name, :new.value, flag_v) ;
end;
/

