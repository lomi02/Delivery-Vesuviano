create view WM_EVENTS_INFO as
select event_name, capture
from wmsys.wm$events_info
WITH READ ONLY
/

