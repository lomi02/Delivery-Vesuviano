create trigger WM$EI_U_TRIG
    instead of update
    on WM$EVENTS_INFO
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
begin
  if (updating('CAPTURE')) then
    flag_v := wmsys.owm_dml_pkg.wm$events_info$f(:new.capture) ;
    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null)) then
           null ;
         end if;

         update wmsys.wm$events_info$
         set ' || substr(sqlstr, 2) || '
         where event_name=:2;
       end;' using flag_v, :old.event_name ;
  end if ;
end;
/

