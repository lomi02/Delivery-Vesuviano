create view WM$INSTEADOF_TRIGS_TABLE as
select vt.owner table_owner, vt.table_name,
       'WMSYS.WM$' || vt.vtid || '$INSERT$' insert_trigger_name,
       'WMSYS.WM$' || vt.vtid || '$UPDATE$' update_trigger_name,
       'WMSYS.WM$' || vt.vtid || '$DELETE$' delete_trigger_name
from wmsys.wm$versioned_tables vt
/

