create view WM$METADATA_MAP as
select code, nfield1, nfield2, nfield3, vfield1, vfield2, vfield3, wm_version, wm_nextver, wm_delstatus, wm_ltlock, wm_createtime, wm_retiretime, wm_validfrom, wm_validtill
from table(wmsys.lt_export_pkg.export_metadata_view_func())
WITH READ ONLY
/

