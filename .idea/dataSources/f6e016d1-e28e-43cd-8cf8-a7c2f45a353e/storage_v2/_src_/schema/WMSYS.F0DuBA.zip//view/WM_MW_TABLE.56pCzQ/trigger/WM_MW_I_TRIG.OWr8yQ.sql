create trigger WM$MW_I_TRIG
    instead of insert
    on WM$MW_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  insert into wmsys.wm$mw_table$(workspace#)
  values (ws#) ;
end;
/

