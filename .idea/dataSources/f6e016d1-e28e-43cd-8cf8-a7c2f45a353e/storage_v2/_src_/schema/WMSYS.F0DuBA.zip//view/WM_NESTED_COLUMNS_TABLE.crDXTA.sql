create view WM$NESTED_COLUMNS_TABLE as
select vt.owner,
       vt.table_name,
       nct.column_name,
       nct.position,
       nct.type_owner,
       nct.type_name,
       nct.nt_owner,
       nct.nt_name,
       nct.nt_store
from wmsys.wm$nested_columns_table$ nct, wmsys.wm$versioned_tables$ vt
where nct.vtid# = vt.vtid#
/

