create trigger WM$NT_I_TRIG
    instead of insert
    on WM$NEXTVER_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  insert into wmsys.wm$nextver_table$(version, workspace#, next_vers, split)
  values (:new.version, ws#, :new.next_vers, :new.split) ;
end;
/

