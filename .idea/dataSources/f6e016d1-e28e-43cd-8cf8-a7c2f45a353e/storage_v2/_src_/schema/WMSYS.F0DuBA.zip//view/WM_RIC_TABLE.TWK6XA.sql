create view WM$RIC_TABLE as
select vt1.owner ct_owner,
       vt1.table_name ct_name,
       vt2.owner pt_owner,
       vt2.table_name pt_name,
       rt.ric_name,
       rt.ct_cols,
       rt.pt_cols,
       rt.pt_unique_const_name,
       decode(bitand(rt.wm$flag, 3), 0, 'C', 1, 'N', 2, 'R') my_mode,
       decode(bitand(rt.wm$flag, 4), 0, 'DISABLED', 4, 'ENABLED') status
from wmsys.wm$ric_table$ rt, wmsys.wm$versioned_tables$ vt1, wmsys.wm$versioned_tables$ vt2
where bitand(rt.wm$flag, 8) = 0 and
      rt.ct_vtid# = vt1.vtid# and
      rt.pt_vtid# = vt2.vtid#
/

