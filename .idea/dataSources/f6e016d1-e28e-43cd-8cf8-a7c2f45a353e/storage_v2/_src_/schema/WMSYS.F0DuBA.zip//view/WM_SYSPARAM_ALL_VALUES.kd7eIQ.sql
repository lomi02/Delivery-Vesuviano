create view WM$SYSPARAM_ALL_VALUES as
select sav.name, sav.value, decode(bitand(sav.wm$flag, 1), 0, 'NO', 1, 'YES') isdefault, decode(bitand(sav.wm$flag, 2), 0, 0, 2, 1) hidden
from wmsys.wm$sysparam_all_values$ sav
/

