create view WM$TABLE_PARVERS_VIEW as
select vtid# vtid, mt.version parent_vers
 from wmsys.wm$modified_tables$ mt
 where mt.workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId) and
       mt.version <= decode(sys_context('lt_ctx', 'version'),
                            -1, (select current_version
                                 from wmsys.wm$workspaces_table$
                                 where workspace_lock_id = sys_context('lt_ctx', 'state_id')),
                            null, (select current_version
                                   from wmsys.wm$workspaces_table$
                                   where workspace_lock_id = wmsys.ltUtil.getDefaultWorkspaceId),
                            sys_context('lt_ctx', 'version'))
union all
 select vtid#, mt.version
 from wmsys.wm$version_table$ vt, wmsys.wm$modified_tables$ mt
 where vt.workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId) and
       vt.anc_workspace# = mt.workspace# and
       mt.version <= vt.anc_version
WITH READ ONLY
/

