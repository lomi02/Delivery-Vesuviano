create trigger WM$UI_I_TRIG
    instead of insert
    on WM$UDTRIG_INFO
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.table_owner_name, :new.table_name) ;
  trig_t integer ;
  u_flag boolean ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$udtrig_info$f(:new.trig_flag, :new.status, :new.internal_type, :new.event_flag) ;

  insert into wmsys.wm$udtrig_info$(trig_owner_name, trig_name, vtid#, proc#, when_clause, description, trig_code, wm$flag)
  values (:new.trig_owner_name, :new.trig_name, vtid, regexp_substr(:new.trig_procedure, '[[:digit:]]+$'),
          :new.when_clause, :new.description, :new.trig_code, flag_v) ;
end;
/

