create trigger WM$VTH_NT_I_TRIG
    instead of insert
    on WM$VERSIONED_TABLES$H
    for each row
begin
  insert into table(select undo_code from wmsys.wm$versioned_tables$ where owner=:parent.owner and table_name=:parent.table_name)
  values(:new.index_type, :new.index_field, :new.sql_str) ;
end;
/

