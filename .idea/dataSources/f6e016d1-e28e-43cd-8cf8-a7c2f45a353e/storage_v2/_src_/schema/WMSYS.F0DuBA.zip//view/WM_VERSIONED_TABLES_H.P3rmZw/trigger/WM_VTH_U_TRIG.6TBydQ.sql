create trigger WM$VTH_U_TRIG
    instead of update
    on WM$VERSIONED_TABLES$H
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
begin
  if (updating('DISABLING_VER') or updating('HIST') or updating('VALIDTIME') or
      updating('BL_SAVEPOINT') or updating('BL_CHECK_FOR_DUPLICATES') or updating('BL_SINGLE_TRANSACTION')) then
    flag_v := wmsys.owm_dml_pkg.wm$versioned_tables$f(:new.disabling_ver, :new.hist, :new.validtime, :new.bl_savepoint,
                                                      :new.bl_check_for_duplicates, :new.bl_single_transaction, :new.identity_type) ;

    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (updating('RICWEIGHT')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' ricweight=:2' ;
  end if;

  if (updating('PKEY_COLS')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' pkey_cols=:3' ;
  end if;

  if (updating('UNDO_CODE')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' undo_code=:4' ;
  end if;

  if (updating('BL_VERSION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' bl_version=:5' ;
  end if;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null or :4 is null or :5 is null or :6 is null or :7 is null)) then
           null ;
         end if;

         update wmsys.wm$versioned_tables$
         set ' || substr(sqlstr, 2) || '
         where owner=:6 and table_name=:7;
       end;' using flag_v, :new.ricweight, :new.pkey_cols, :new.undo_code, :new.bl_version, :old.owner, :old.table_name ;
  end if ;
end;
/

