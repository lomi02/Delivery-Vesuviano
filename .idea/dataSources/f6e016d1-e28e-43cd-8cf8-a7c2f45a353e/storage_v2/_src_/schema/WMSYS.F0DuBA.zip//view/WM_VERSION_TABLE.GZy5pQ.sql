create view WM$VERSION_TABLE as
select wt1.workspace, wt2.workspace anc_workspace, vt.anc_version, vt.anc_depth, vt.refcount
from wmsys.wm$version_table$ vt, wmsys.wm$workspaces_table$i wt1, wmsys.wm$workspaces_table$i wt2
where vt.workspace# = wt1.workspace_lock_id and
      vt.anc_workspace# = wt2.workspace_lock_id
/

