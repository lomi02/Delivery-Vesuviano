create trigger WM$VET_I_TRIG
    instead of insert
    on WM$VT_ERRORS_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$vt_errors_table$f(:new.status) ;

  insert into wmsys.wm$vt_errors_table$(vtid#, index_type, index_field, error_msg, wm$flag)
  values (vtid, :new.index_type, :new.index_field, :new.error_msg, flag_v) ;
end;
/

