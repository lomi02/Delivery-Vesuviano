create trigger WM$WT_I_TRIG
    instead of insert
    on WM$WORKSPACES_TABLE$D
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.parent_workspace) ;


  last_change     timestamp with time zone := :new.last_change ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$workspaces_table$f(:new.freeze_status, :new.freeze_mode, :new.wm_lockmode,
                                                    :new.isrefreshed, :new.session_duration, :new.cr_status, :new.keep) ;

  if (last_change is null) then
    last_change := systimestamp ;
  end if ;

  insert into wmsys.wm$workspaces_table$(workspace, parent_workspace#, current_version, parent_version, post_version,
                                         owner, createtime, description, workspace_lock_id, freeze_writer, freeze_owner,
                                         sync_parver, last_change, depth, mp_root, wm$flag)
  values (:new.workspace, ws#, :new.current_version, :new.parent_version, :new.post_version, :new.owner, :new.createtime,
          :new.description, :new.workspace_lock_id, :new.freeze_writer, :new.freeze_owner,
          :new.sync_parver, last_change, :new.depth, :new.mp_root, flag_v) ;
end;
/

