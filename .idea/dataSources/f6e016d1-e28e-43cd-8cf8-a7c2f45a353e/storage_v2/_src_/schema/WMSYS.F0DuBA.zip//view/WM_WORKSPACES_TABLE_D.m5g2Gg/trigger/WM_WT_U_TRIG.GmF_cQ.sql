create trigger WM$WT_U_TRIG
    instead of update
    on WM$WORKSPACES_TABLE$D
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
begin
  if (updating('FREEZE_STATUS') or updating('FREEZE_MODE') or updating('WM_LOCKMODE') or
      updating('ISREFRESHED') or updating('SESSION_DURATION') or updating('CR_STATUS') or updating('KEEP')) then
    flag_v := wmsys.owm_dml_pkg.wm$workspaces_table$f(:new.freeze_status, :new.freeze_mode, :new.wm_lockmode,
                                                      :new.isrefreshed, :new.session_duration, :new.cr_status, :new.keep) ;
    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (updating('WORKSPACE')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' workspace=:2' ;
  end if;

  if (updating('CURRENT_VERSION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' current_version=:3' ;
  end if;

  if (updating('PARENT_VERSION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' parent_version=:4' ;
  end if;

  if (updating('POST_VERSION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' post_version=:5' ;
  end if;

  if (updating('DESCRIPTION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' description=:6' ;
  end if;

  if (updating('FREEZE_WRITER')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' freeze_writer=:7' ;
  end if;

  if (updating('FREEZE_OWNER')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' freeze_owner=:8' ;
  end if;

  if (updating('SYNC_PARVER')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' sync_parver=:9' ;
  end if;

  if (updating('LAST_CHANGE')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' last_change=:10' ;
  end if;

  if (updating('DEPTH')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' depth=:11' ;
  end if;

  if (updating('MP_ROOT')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' mp_root=:12' ;
  end if;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null or :4 is null or :5 is null or :6 is null or
                      :7 is null or :8 is null or :9 is null or :10 is null or :11 is null or :12 is null or :13 is null)) then
           null ;
         end if;

         update wmsys.wm$workspaces_table$
         set ' || substr(sqlstr, 2) || '
         where workspace_lock_id=:13;
       end;' using flag_v, :new.workspace, :new.current_version, :new.parent_version, :new.post_version, :new.description, :new.freeze_writer,
                   :new.freeze_owner, :new.sync_parver, :new.last_change, :new.depth, :new.mp_root, :old.workspace_lock_id ;
  end if ;
end;
/

