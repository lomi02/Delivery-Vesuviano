create view WM$WORKSPACE_PRIV_TABLE as
select wpt.grantee,
       wt.workspace,
       wpt.grantor,
       decode(bitand(wpt.wm$flag, 31), 0, 'U',
                                       1, 'A', 2, 'M', 3, 'R', 4, 'D', 5, 'C', 6, 'F', 13, 'G',
                                       7, 'AA', 8, 'MA', 9, 'RA', 10, 'DA', 11, 'CA', 12, 'FA', 14, 'GA',
                                       15, 'W') priv,
       decode(bitand(wpt.wm$flag, 32), 0, 0, 32, 1) admin
from wmsys.wm$workspace_priv_table$ wpt, wmsys.wm$workspaces_table$i wt
where wpt.workspace# = wt.workspace_lock_id(+)
/

