create trigger WM$WST_I_TRIG
    instead of insert
    on WM$WORKSPACE_SAVEPOINTS_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$workspace_savepoints_t$f(:new.is_implicit) ;

  insert into wmsys.wm$workspace_savepoints_table$(workspace#, savepoint, version, owner, createtime, description, wm$flag)
  values (ws#, :new.savepoint, :new.version, :new.owner, :new.createtime, :new.description, flag_v) ;
end;
/

