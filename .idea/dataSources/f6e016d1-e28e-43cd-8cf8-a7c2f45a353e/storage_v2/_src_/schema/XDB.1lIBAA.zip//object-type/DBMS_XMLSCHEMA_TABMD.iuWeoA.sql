create TYPE     DBMS_XMLSCHEMA_TABMD FORCE as OBJECT (
        schema_name  varchar2(700),
	element_name varchar2(128),
	table_name   varchar2(128),
	table_oid    raw(16)
);
/

