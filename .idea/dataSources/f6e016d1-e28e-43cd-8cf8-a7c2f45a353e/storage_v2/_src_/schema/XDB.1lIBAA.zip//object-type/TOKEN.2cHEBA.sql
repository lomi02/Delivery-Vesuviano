create type     token force as object (qnameid raw(8),
                                                  localname varchar(2000),
                                                  nmspcid raw(8))
NOT PERSISTABLE
/

