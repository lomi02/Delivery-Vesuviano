create type body     XMLIdxStatsMethods
is
  static function ODCIGetInterfaces(ilist OUT sys.ODCIObjectList)
    return number is
  begin
    ilist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCISTATS2'));
    return ODCICONST.SUCCESS;
  end ODCIGetInterfaces;
end;
/

