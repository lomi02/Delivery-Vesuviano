create PACKAGE     dbms_xdb_config AUTHID CURRENT_USER IS

------------
-- CONSTANTS
--
------------
-- Constant number for 1st argument of setListenerEndPoint
XDB_ENDPOINT_HTTP  CONSTANT NUMBER := 1;
XDB_ENDPOINT_HTTP2 CONSTANT NUMBER := 2;
-- Permit https instead of http2, bug 17213197
XDB_ENDPOINT_HTTPS CONSTANT NUMBER := 2;
XDB_ENDPOINT_RHTTP CONSTANT NUMBER := 3;
XDB_ENDPOINT_RHTTPS CONSTANT NUMBER := 4;

-- Constant number for 4th argument of setListenerEndPoint
XDB_PROTOCOL_TCP   CONSTANT NUMBER := 1;
XDB_PROTOCOL_TCPS  CONSTANT NUMBER := 2;

-- Constant number for 1st argument of xdb_validate_port
-- Constant for service id, compatible with xdb.xdb$cdbports
XDB_SERVICE_FTP   CONSTANT NUMBER := 1;
XDB_SERVICE_HTTP  CONSTANT NUMBER := 2;
XDB_SERVICE_HTTP2 CONSTANT NUMBER := 3;
-- Following is not used, reserve the value anyway.
XDB_SERVICE_NFS   CONSTANT NUMBER := 4;
XDB_SERVICE_RHTTP CONSTANT NUMBER := 5;
XDB_SERVICE_RHTTPS CONSTANT NUMBER := 6;

ON_DENY_NEXT_CUSTOM   CONSTANT NUMBER := 1;
ON_DENY_BASIC         CONSTANT NUMBER := 2;

---------------------------------------------
-- PROCEDURE - usedport
--     return the protocol port numbers of all pdbs
-- PARAMETERS -
---------------------------------------------
FUNCTION usedport RETURN sys.xmltype;

---------------------------------------------
-- PROCEDURE - setFTPPort
--     sets the FTP port to new value
-- PARAMETERS -
--     new_port
--         value that the ftp port will be set to
---------------------------------------------

PROCEDURE setFTPPort(new_port IN NUMBER);

---------------------------------------------
-- FUNCTION - getFTPPort
--     gets the current value of FTP port
-- PARAMETERS -
--     none
-- RETURNS
--     ftp_port
--         current value of ftp-port
---------------------------------------------

FUNCTION getFTPPort RETURN NUMBER;

---------------------------------------------
-- PROCEDURE - setHTTPPort
--     sets the HTTP port to new value
-- PARAMETERS -
--     new_port
--         value that the http port will be set to
---------------------------------------------

PROCEDURE setHTTPPort(new_port IN NUMBER);

---------------------------------------------
-- PROCEDURE - setHTTPsPort
--     sets the HTTPs port (with SSL) to new value
--
-- PARAMETERS -
--     new_port
--         value that the https port will be set to.
--
-- NOTE
--     The HTTPS port will be set using the second
--     HTTP end point
---------------------------------------------

PROCEDURE setHTTPsPort(new_port IN NUMBER);

---------------------------------------------
-- PROCEDURE - setRemoteHTTPPort
--     sets the Remote HTTP port to new value
-- PARAMETERS -
--     new_port
--         value that the remote http port will be set to
---------------------------------------------

PROCEDURE setRemoteHTTPPort(new_port IN NUMBER);

---------------------------------------------
-- PROCEDURE - setRemoteHTTPSPort
--     sets the Remote HTTP port (with SSL) to new value
-- PARAMETERS -
--     new_port
--         value that the remote http port will be set to
---------------------------------------------

PROCEDURE setRemoteHTTPSPort(new_port IN NUMBER);

---------------------------------------------
-- FUNCTION - getHTTPPort
--     gets the current value of HTTP port
-- PARAMETERS -
--     none
-- RETURNS
--     http_port
--         current value of http-port
---------------------------------------------

FUNCTION getHTTPPort RETURN NUMBER;

---------------------------------------------
-- FUNCTION - getHTTPsPort
--     gets the current value of HTTPs port
-- PARAMETERS -
--     none
-- RETURNS
--     https_port
--         current value of https-port. Return NULL
--         if none has been configured
---------------------------------------------

FUNCTION getHTTPsPort RETURN NUMBER;

---------------------------------------------
-- FUNCTION - getRemoteHTTPPort
--     gets the current value of remote HTTP port
-- PARAMETERS -
--     none
-- RETURNS
--     remote_http_port
--         current value of remote-http-port
---------------------------------------------

FUNCTION getRemoteHTTPPort RETURN NUMBER;

---------------------------------------------
-- FUNCTION - getRemoteHTTPSPort
--     gets the current value of remote HTTPs (with SSL) port
-- PARAMETERS -
--     none
-- RETURNS
--     remote_https_port
--         current value of remote-https-port
---------------------------------------------

FUNCTION getRemoteHTTPSPort RETURN NUMBER;

---------------------------------------------
-- PROCEDURE setListenerEndPoint(endpoint IN number, host IN varchar2,
--                               port IN number, protocol IN number);

-- This procedure sets the parameters of a listener end point corresponding
-- to the XML DB HTTP server. Both HTTP and HTTP2 end points can be set by
-- invoking this procedure.

--   (a) endpoint - The end point to be set. Its value can be
--       XDB_ENDPOINT_HTTP or XDB_ENDPOINT_HTTP2.
--   (b) host - The interface on which the listener end point is to listen.
--       Its value can be 'localhost,' null, or a hostname. If its value is
--       'localhost,' then the listener end point is permitted to only listen
--       on the localhost interface. If its value is null or hostname, then
--       the listener end point is permitted to listen on both localhost and
--       non-localhost interfaces.
--   (c) port - The port on which the listener end point is to listen.
--   (d) protocol - The transport protocol that the listener end point is to
--       accept. Its value can be XDB_PROTOCOL_TCP or XDB_PROTOCOL_TCPS.
---------------------------------------------

PROCEDURE setListenerEndPoint(endpoint IN number, host IN varchar2,
                              port IN number, protocol IN number);

---------------------------------------------
--  PROCEDURE getListenerEndPoint(endpoint IN NUMBER, host OUT VARCHAR2,
--                                port OUT NUMBER, protocol OUT NUMBER);

-- This procedure retrieves the parameters of a listener end point
-- corresponding to the XML DB HTTP server. The parameters of both HTTP
-- and HTTP2 end points can be retrieved by invoking this procedure.

--  (a) endpoint - The end point whose parameters are to be retrieved. Its
--      value can be XDB_ENDPOINT_HTTP or XDB_ENDPOINT_HTTP2.
--  (b) host - The interface on which the listener end point listens.
--  (c) port - The port on which the listener end point listens.
--  (d) protocol - The transport protocol accepted by the listener end point.
---------------------------------------------

PROCEDURE getListenerEndPoint(endpoint IN NUMBER, host OUT VARCHAR2,
                              port OUT NUMBER, protocol OUT NUMBER);

---------------------------------------------
-- PROCEDURE setListenerLocalAccess(l_access boolean);
-- This procedure restricts all listener end points of the XML DB HTTP server
-- to listen only on the localhost interface (when l_access is TRUE) or
-- allows all listener end points of the XML DB HTTP server to listen on
-- both localhost and non-localhost interfaces (when l_access is FALSE).

--  (a) l_access - TRUE or FALSE. See description of procedure above.
---------------------------------------------
PROCEDURE setListenerLocalAccess(l_access boolean);

---------------------------------------------
-- PROCEDURE - refresh
--     Refreshes the session configuration with the latest configuration
---------------------------------------------
PROCEDURE cfg_refresh;

---------------------------------------------
-- FUNCTION - get
--     retrieves the xdb configuration
-- RETURNS -
--     XMLType for xdb configuration
---------------------------------------------
FUNCTION cfg_get RETURN sys.xmltype;

---------------------------------------------
-- PROCEDURE - update
--     Updates the xdb configuration with the input xmltype document
-- PARAMETERS -
--  xdbconfig
---     XMLType for xdb configuration
--------------------------------------------
PROCEDURE cfg_update(xdbconfig IN sys.xmltype);

-----------------------------------------------------------
-- XDB Config Update APIs
-- PROCEDURE ADDMIMEMAPPING         Add a mime mapping
-- PROCEDURE DELETEMIMEMAPPING      Delete a mime mapping
-- PROCEDURE ADDXMLEXTENSION        Add an xml extension
-- PROCEDURE DELETEXMLEXTENSION     Delete an xml extension
-- PROCEDURE ADDSERVLETMAPPING      Add a servlet mapping
-- PROCEDURE DELETESERVLETMAPPING   Delete a servlet mapping
-- PROCEDURE ADDSCHEMALOCMAPPING    Add a schema location mapping
-- PROCEDURE DELETESCHEMALOCMAPPING Delete a schema location mapping
-- PROCEDURE ADDSERVLET             Add a servlet
-- PROCEDURE DELETESERVLET          Delete a servlet
-- PROCEDURE ADDSERVLETSECROLE      Add a security role ref to a servlet
-- PROCEDURE DELETESERVLETSECROLE   Delete a security role ref from a servlet
-----------------------------------------------------------

procedure ADDMIMEMAPPING (
	extension IN VARCHAR2,
	mimetype  IN VARCHAR2
);

procedure DELETEMIMEMAPPING (
	extension IN VARCHAR2
);

procedure ADDXMLEXTENSION (
	extension IN VARCHAR2
);

procedure DELETEXMLEXTENSION (
	extension IN VARCHAR2
);

procedure ADDSERVLETMAPPING (
 	pattern IN VARCHAR2,
 	name    IN VARCHAR2
);

procedure DELETESERVLETMAPPING (
 	name IN VARCHAR2
);

procedure ADDSERVLET (
	name     IN VARCHAR2,
	language IN VARCHAR2,
	dispname IN VARCHAR2,
	icon     IN VARCHAR2 := NULL,
	descript IN VARCHAR2 := NULL,
	class    IN VARCHAR2 := NULL,
	jspfile  IN VARCHAR2 := NULL,
	plsql    IN VARCHAR2 := NULL,
	schema   IN VARCHAR2 := NULL
);

procedure DELETESERVLET (
 	name IN VARCHAR2
);

procedure ADDSERVLETSECROLE (
 	servname IN VARCHAR2,
 	rolename IN VARCHAR2,
 	rolelink IN VARCHAR2,
 	descript IN VARCHAR2 := NULL
);

procedure DELETESERVLETSECROLE (
	servname IN VARCHAR2,
	rolename IN VARCHAR2
);

procedure ADDSCHEMALOCMAPPING (
	namespace IN VARCHAR2,
	element   IN VARCHAR2,
	schemaURL IN VARCHAR2
);

procedure DELETESCHEMALOCMAPPING (
	schemaURL IN VARCHAR2
);

---------------------------------------------
-- PROCEDURE - addAuthenticationMapping
--     Adds a mapping from the authentication method name to a
--      URL pattern (in xdb$onfig).
-- PARAMETERS -
--     pattern - URL pattern
--     name    - authentication method name
---------------------------------------------
procedure addAuthenticationMapping(pattern IN VARCHAR2,
                                   name IN VARCHAR2,
                                   user_prefix IN VARCHAR2 := NULL,
                                   on_deny IN NUMBER := NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(addAuthenticationMapping, UNSUPPORTED_WITH_COMMIT);

---------------------------------------------
-- PROCEDURE - deleteAuthenticationMapping
--     Deletes a mapping from the authentication method name to a
--      URL pattern (from xdb$onfig).
-- PARAMETERS -
--     pattern - URL pattern
--     name    - authentication method name
---------------------------------------------
procedure deleteAuthenticationMapping(pattern IN VARCHAR2,
                                      name IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(deleteAuthenticationMapping, UNSUPPORTED_WITH_COMMIT);

---------------------------------------------
-- PROCEDURE - addAuthenticationMethod
--     Adds to xdb$config a custom authentication method entry.
-- PARAMETERS -
--     name    - authentication method name (the name the
--               custom authentication routine will be known to XDB)
--     description - some note on the authentication method
--     implement_schema - the owner of the routine that implements
--                        the authentication
--     implement_method - the name of the routine that implements
--                        the authentication
--     language         - the language in which the implementation
--                        routine is written (currently only PL/SQL)
---------------------------------------------
procedure addAuthenticationMethod(name IN VARCHAR2,
                                  description IN VARCHAR2,
                                  implement_schema IN VARCHAR2,
                                  implement_method IN VARCHAR2,
                                  language  IN VARCHAR2 := 'PL/SQL');
PRAGMA SUPPLEMENTAL_LOG_DATA(addAuthenticationMethod, UNSUPPORTED_WITH_COMMIT);

---------------------------------------------
-- PROCEDURE - deleteAuthenticationMethod
--    Deletes from  xdb$config a custom authentication method entry.
-- PARAMETERS -
--     name    - authentication method name (the name the
--               custom authentication routine will be known to XDB)
---------------------------------------------
procedure deleteAuthenticationMethod(name IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(deleteAuthenticationMethod, UNSUPPORTED_WITH_COMMIT);

procedure addTrustScheme(name IN VARCHAR2,
                         description IN VARCHAR2,
                         session_user IN VARCHAR2,
                         parsing_schema IN VARCHAR2,
                         system_level IN BOOLEAN := TRUE,
                         require_parsing_schema IN BOOLEAN := TRUE,
                         allow_registration IN BOOLEAN := TRUE);
PRAGMA SUPPLEMENTAL_LOG_DATA(addTrustScheme, UNSUPPORTED_WITH_COMMIT);

procedure deleteTrustScheme(name IN VARCHAR2,
                            system_level IN BOOLEAN := TRUE);
PRAGMA SUPPLEMENTAL_LOG_DATA(deleteTrustScheme, UNSUPPORTED_WITH_COMMIT);

procedure addTrustMapping(pattern IN VARCHAR2,
                          auth_name IN VARCHAR2,
                          trust_name IN VARCHAR2,
                          user_prefix IN VARCHAR2 := NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(addTrustMapping, UNSUPPORTED_WITH_COMMIT);

procedure deleteTrustMapping(pattern IN VARCHAR2,
                             name IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(deleteTrustMapping, UNSUPPORTED_WITH_COMMIT);

procedure enableCustomAuthentication;
PRAGMA SUPPLEMENTAL_LOG_DATA(enableCustomAuthentication, UNSUPPORTED_WITH_COMMIT);

procedure enableCustomTrust;
PRAGMA SUPPLEMENTAL_LOG_DATA(enableCustomTrust, UNSUPPORTED_WITH_COMMIT);

procedure setDynamicGroupStore(is_dynamic IN BOOLEAN := TRUE);
PRAGMA SUPPLEMENTAL_LOG_DATA(setDynamicGroupStore, UNSUPPORTED_WITH_COMMIT);

procedure enableDigestAuthentication;
PRAGMA SUPPLEMENTAL_LOG_DATA(enableDigestAuthentication, UNSUPPORTED_WITH_COMMIT);

function getHttpConfigRealm
  return VARCHAR2;

procedure setHttpConfigRealm(realm IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(setHttpConfigRealm, UNSUPPORTED_WITH_COMMIT);

-------------------------------------------------------------------------------
-- FUNCTION - IsGlobalPortEnabled
--  Returns the flag that determines if a servlet will permit/disable global
--  port messages.  If not defined the default value is returned, which is
--  FALSE for the root and TRUE for pdbs.
--  New feature in 12.2
-------------------------------------------------------------------------------
function IsGlobalPortEnabled
  return BOOLEAN;
PRAGMA SUPPLEMENTAL_LOG_DATA(IsGlobalPortEnabled, UNSUPPORTED_WITH_COMMIT);

-----------------------------------------------------------
-- PROCEDURE - SetGlobalPortEnabled
--  sets/clears flag in servlet that will permit/disable global port messages
--  from the root's port to executing the servlet in a target pdb
--  New feature in 12.2
--
-- PARAMETERS -
--  isenabled(IN) - Accepted values: TRUE to permit, FALSE to disable
-----------------------------------------------------------
procedure  SetGlobalPortEnabled(isenabled IN BOOLEAN := TRUE);
PRAGMA SUPPLEMENTAL_LOG_DATA(SetGlobalPortEnabled, UNSUPPORTED_WITH_COMMIT);

-----------------------------------------------------------
-- PROCEDURE - ClearHttpDigests
--  Clears the MD5 digests stored in sys.user$.  Before 12.2.0.1 they were
--  generated for each user, now they can be but by default are not.  This
--  procedure is intended to be used by a DBA after upgrade to clear out
--  old digests so they cannot be a security risk.
--  New feature in 12.2.0.1
--
-- PARAMETERS -
--  none
-----------------------------------------------------------
procedure ClearHttpDigests;
PRAGMA SUPPLEMENTAL_LOG_DATA(ClearHttpDigests, UNSUPPORTED_WITH_COMMIT);


-----------------------------------------------------------
-- PROCEDURE - addDefaultTypeMappings
--  creats a default-type-mappings entry in xdbconfig.
--  Default is pre-11.2
--
-- PARAMETERS -
--  version (IN) - Accepted values: "pre-11.2" or "post-11.2"
--                 Default is pre-11.2
-----------------------------------------------------------
PROCEDURE addDefaultTypeMappings ( version IN VARCHAR2 := 'pre-11.2');


-----------------------------------------------------------
-- PROCEDURE - deleteDefaultTypeMappings
--  deletes the default type mappings from xdbconfig.
--
-- PARAMETERS -
-----------------------------------------------------------
PROCEDURE deleteDefaultTypeMappings;

-----------------------------------------------------------
-- PROCEDURE - setDefaultTypeMappings
--  sets the value of default-type-mappings in xdbconfig
--
-- PARAMETERS -
--  type (IN) - Accepted values: "pre-11.2" or "post-11.2"
-----------------------------------------------------------
PROCEDURE setDefaultTypeMappings ( version IN VARCHAR2 );


-------------------------------------------------------------------------------
-- PROCEDURE - addHttpExpireMapping
--    Adds to xdb$config a mapping of the URL pattern to an
--     expiration date. This will control the Expire headers
--     for URLs matching the pattern.
-- PARAMETERS -
--     pattern  -- URL pattern (only * accepted as wildcards)
--     expire   -- expiration directive, follows the ExpireDefault
--                 in Apache's mod_expires, i.e.,
--                 base [plus] (num type)*
--                 -- base: now | modification
--                 -- type: year|years|month|months|week|weeks|day|days|
--                          minute|minutess|second|seconds
-- EXAMPLE
--  dbms_xdb.addHttpExpireMapping('/public/test1/*', 'now plus 4 weeks');
--  dbms_xdb.addHttpExpireMapping('/public/test2/*',
--                                'modification plus 1 day 30 seconds');
-------------------------------------------------------------------------------
procedure addHttpExpireMapping(pattern IN VARCHAR2,
                               expire IN VARCHAR2);

-------------------------------------------------------------------------------
-- PROCEDURE - deleteHttpExpireMapping
--    Deletes from xdb$config all mappings of the URL pattern to an
--     expiration date.
-- PARAMETERS -
--     pattern  -- URL pattern (only * accepted as wildcards)
-------------------------------------------------------------------------------
procedure deleteHttpExpireMapping(pattern IN VARCHAR2);

-------------------------------------------------------------------------------
-- FUNCTION - getHTTPRequestHeader
--    If called during an HTTP request serviced by XDB, it returns the values
--    of the passed header. It returns NULL in case the header is not present
--    in the request, or for AUTHENTICATION, for security reasons.
--    Expected to be used by routines that implement custom authentication.
-------------------------------------------------------------------------------
function getHTTPRequestHeader(header_name IN VARCHAR2)
  return VARCHAR2;

end dbms_xdb_config;
/

