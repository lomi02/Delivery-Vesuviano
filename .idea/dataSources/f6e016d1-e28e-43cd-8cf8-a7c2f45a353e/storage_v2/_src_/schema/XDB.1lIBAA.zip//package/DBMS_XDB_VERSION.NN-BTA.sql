create package     DBMS_XDB_VERSION authid current_user as

  SUBTYPE resid_type is RAW(16);
  TYPE resid_list_type is VARRAY(1000) of RAW(16);

  PROCEDURE makeversioned_int(pathname IN VARCHAR2, resid OUT resid_type);
  PRAGMA SUPPLEMENTAL_LOG_DATA(makeversioned_int, AUTO);

  FUNCTION makeversioned(pathname VARCHAR2) RETURN resid_type;

  PROCEDURE checkout(pathname VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(checkout, AUTO);

  PROCEDURE checkin_int(pathname IN VARCHAR2, resid OUT resid_type);
  PRAGMA SUPPLEMENTAL_LOG_DATA(checkin_int, AUTO);

  FUNCTION checkin(pathname VARCHAR2) RETURN resid_type;

  PROCEDURE uncheckout_int(pathname IN VARCHAR2, resid OUT resid_type);
  PRAGMA SUPPLEMENTAL_LOG_DATA(uncheckout_int, AUTO);

  FUNCTION uncheckout(pathname VARCHAR2) RETURN resid_type;

  FUNCTION ischeckedout(pathname VARCHAR2) RETURN BOOLEAN;
  FUNCTION GetPredecessors(pathname VARCHAR2) RETURN resid_list_type;
  FUNCTION GetPredsByResId(resid resid_type) RETURN resid_list_type;
  FUNCTION GetSuccessors(pathname VARCHAR2) RETURN resid_list_type;
  FUNCTION GetSuccsByResId(resid resid_type) RETURN resid_list_type;
  FUNCTION GetResourceByResId(resid resid_type) RETURN XMLType;
  FUNCTION GetContentsBlobByResId(resid resid_type) RETURN BLOB;
  FUNCTION GetContentsClobByResId(resid resid_type) RETURN CLOB;
  FUNCTION GetContentsXmlByResId(resid resid_type) RETURN XMLType;

end DBMS_XDB_VERSION;
/

