create package     dbms_xmltranslations
authid current_user is

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

function translatexml (
    doc  in xmltype,
    lang in varchar2
) return xmltype;

function getbasedocument (
    doc  in xmltype
) return xmltype;

function updatetranslation (
    doc   in xmltype,
    xpath in varchar2,
    lang  in varchar2,
    value in varchar2,
    namespace in varchar2 := null
) return xmltype;

function setsourcelang (
    doc   in xmltype,
    xpath in varchar2,
    lang  in varchar2,
    namespace in varchar2 := null
) return xmltype;

function extractxliff (
    doc   in xmltype,
    xpath in varchar2,
    namespace in varchar2 := null
) return xmltype;

function extractxliff (
    abspath in varchar2,
    xpath   in varchar2,
    namespace in varchar2 := null
) return xmltype;

function mergexliff (
    doc   in xmltype,
    xliff in xmltype
) return xmltype;

procedure mergexliff (
    xliff in xmltype
);

procedure enableTranslation;
procedure disableTranslation;

end dbms_xmltranslations;
/

