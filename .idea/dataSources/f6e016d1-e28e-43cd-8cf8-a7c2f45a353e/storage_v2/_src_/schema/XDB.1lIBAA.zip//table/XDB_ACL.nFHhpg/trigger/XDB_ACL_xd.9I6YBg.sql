create trigger "XDB$ACL$xd"
    after update or delete
    on XDB$ACL
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$ACL', :old.sys_nc_oid$, '1550D05C5DC547B08AFD39755CB5D0F1' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$ACL', :old.sys_nc_oid$, '1550D05C5DC547B08AFD39755CB5D0F1', user ); END IF; END;
/

