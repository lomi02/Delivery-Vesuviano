create trigger "XDB$CONFIG$xd"
    after update or delete
    on XDB$CONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$CONFIG', :old.sys_nc_oid$, '11803F37444C4D9AA25CEC3F1C9B68E4' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$CONFIG', :old.sys_nc_oid$, '11803F37444C4D9AA25CEC3F1C9B68E4', user ); END IF; END;
/

