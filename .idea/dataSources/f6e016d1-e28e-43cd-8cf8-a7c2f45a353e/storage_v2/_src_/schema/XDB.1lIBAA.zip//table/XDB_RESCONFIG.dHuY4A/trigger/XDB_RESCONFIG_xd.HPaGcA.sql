create trigger "XDB$RESCONFIG$xd"
    after update or delete
    on XDB$RESCONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'D23EF6936471493A9892D9B176AF131D' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'D23EF6936471493A9892D9B176AF131D', user ); END IF; END;
/

