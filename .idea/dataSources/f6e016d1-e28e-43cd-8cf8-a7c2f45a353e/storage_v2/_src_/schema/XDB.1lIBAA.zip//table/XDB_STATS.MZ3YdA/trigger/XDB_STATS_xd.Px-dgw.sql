create trigger "XDB$STATS$xd"
    after update or delete
    on XDB$STATS
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, '1425D0709FE946B1A068BAAD858E0AD9' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, '1425D0709FE946B1A068BAAD858E0AD9', user ); END IF; END;
/

